-- SandIAM installation lifecycle for the release package.
-- Admin controller permission inventory; validated against migration 021 during generation.
-- Fail before the first menu write when this is not a fresh SandIAM target.
DO $sand_iam_fresh_install$
BEGIN
    IF EXISTS (
        SELECT 1
        FROM pg_class relation
        JOIN pg_namespace namespace ON namespace.oid = relation.relnamespace
        WHERE namespace.nspname = current_schema()
          AND (
              relation.relname LIKE 'sand\_iam\_%' ESCAPE '\'
              OR relation.relname LIKE 'idx\_sand\_iam\_%' ESCAPE '\'
              OR relation.relname LIKE 'uk\_sand\_iam\_%' ESCAPE '\'
              OR relation.relname LIKE 'uq\_sand\_iam\_%' ESCAPE '\'
              OR relation.relname LIKE 'ux\_sand\_iam\_%' ESCAPE '\'
          )
    ) OR EXISTS (
        SELECT 1
        FROM pg_type type_entry
        JOIN pg_namespace namespace ON namespace.oid = type_entry.typnamespace
        WHERE namespace.nspname = current_schema()
          AND type_entry.typname LIKE 'sand\_iam\_%' ESCAPE '\'
    ) THEN
        RAISE EXCEPTION 'SandIAM fresh install refuses existing sand_iam_* objects in schema %', current_schema();
    END IF;

    IF to_regclass(format('%I.sand_system_menu', current_schema())) IS NULL
       OR to_regclass(format('%I.sand_system_role_menu', current_schema())) IS NULL THEN
        RAISE EXCEPTION 'SandIAM fresh install requires the SandAdmin menu and role-menu tables';
    END IF;

    IF EXISTS (
        SELECT 1 FROM sand_system_menu
        WHERE code = 'SandIAM'
           OR code LIKE 'SandIAM%'
           OR code LIKE 'sand\_iam:%' ESCAPE '\'
           OR slug LIKE 'sand\_iam:%' ESCAPE '\'
           OR path = '/sand-iam'
           OR path LIKE '/sand-iam/%'
    ) THEN
        RAISE EXCEPTION 'SandIAM fresh install refuses existing menu codes, permission slugs, or routes';
    END IF;
END
$sand_iam_fresh_install$;
-- 'sand_iam:acceptance_fixture:cleanup'
-- 'sand_iam:acceptance_fixture:read'
-- 'sand_iam:admin_application_grant:disable'
-- 'sand_iam:admin_application_grant:index'
-- 'sand_iam:admin_application_grant:read'
-- 'sand_iam:admin_application_grant:save'
-- 'sand_iam:admin_application_grant:update'
-- 'sand_iam:admin_organization_grant:disable'
-- 'sand_iam:admin_organization_grant:index'
-- 'sand_iam:admin_organization_grant:read'
-- 'sand_iam:admin_organization_grant:save'
-- 'sand_iam:admin_organization_grant:update'
-- 'sand_iam:api_resource:disable'
-- 'sand_iam:api_resource:index'
-- 'sand_iam:api_resource:read'
-- 'sand_iam:api_resource:save'
-- 'sand_iam:api_resource:update'
-- 'sand_iam:api_route_binding:disable'
-- 'sand_iam:api_route_binding:index'
-- 'sand_iam:api_route_binding:read'
-- 'sand_iam:api_route_binding:save'
-- 'sand_iam:api_route_binding:update'
-- 'sand_iam:application:disable'
-- 'sand_iam:application:index'
-- 'sand_iam:application:read'
-- 'sand_iam:application:save'
-- 'sand_iam:application:update'
-- 'sand_iam:application_experience:disable'
-- 'sand_iam:application_experience:index'
-- 'sand_iam:application_experience:read'
-- 'sand_iam:application_experience:save'
-- 'sand_iam:application_experience:update'
-- 'sand_iam:application_network_policy:disable'
-- 'sand_iam:application_network_policy:index'
-- 'sand_iam:application_network_policy:read'
-- 'sand_iam:application_network_policy:save'
-- 'sand_iam:application_network_policy:update'
-- 'sand_iam:audit:export'
-- 'sand_iam:audit:index'
-- 'sand_iam:audit:read'
-- 'sand_iam:audit_retention_policy:disable'
-- 'sand_iam:audit_retention_policy:index'
-- 'sand_iam:audit_retention_policy:read'
-- 'sand_iam:audit_retention_policy:save'
-- 'sand_iam:audit_retention_policy:update'
-- 'sand_iam:auth_policy:disable'
-- 'sand_iam:auth_policy:index'
-- 'sand_iam:auth_policy:read'
-- 'sand_iam:auth_policy:save'
-- 'sand_iam:auth_policy:update'
-- 'sand_iam:cas_service:disable'
-- 'sand_iam:cas_service:index'
-- 'sand_iam:cas_service:read'
-- 'sand_iam:cas_service:save'
-- 'sand_iam:cas_service:update'
-- 'sand_iam:client:disable'
-- 'sand_iam:client:index'
-- 'sand_iam:client:read'
-- 'sand_iam:client:save'
-- 'sand_iam:client:update'
-- 'sand_iam:credential:index'
-- 'sand_iam:credential:issue'
-- 'sand_iam:credential:read'
-- 'sand_iam:credential:revoke'
-- 'sand_iam:credential:rotate'
-- 'sand_iam:developer:events'
-- 'sand_iam:developer:openapi'
-- 'sand_iam:environment:disable'
-- 'sand_iam:environment:index'
-- 'sand_iam:environment:read'
-- 'sand_iam:environment:save'
-- 'sand_iam:environment:update'
-- 'sand_iam:federation:configure'
-- 'sand_iam:federation:create'
-- 'sand_iam:federation:mount'
-- 'sand_iam:federation:sync'
-- 'sand_iam:grant:index'
-- 'sand_iam:grant:read'
-- 'sand_iam:grant:revoke'
-- 'sand_iam:grant:save'
-- 'sand_iam:grant:update'
-- 'sand_iam:identity:delete'
-- 'sand_iam:identity:disable'
-- 'sand_iam:identity:enable'
-- 'sand_iam:identity:index'
-- 'sand_iam:identity:read'
-- 'sand_iam:identity:restore'
-- 'sand_iam:identity:save'
-- 'sand_iam:identity:update'
-- 'sand_iam:identity_binding:disable'
-- 'sand_iam:identity_binding:index'
-- 'sand_iam:identity_binding:read'
-- 'sand_iam:identity_binding:save'
-- 'sand_iam:identity_binding:update'
-- 'sand_iam:identity_export:masked'
-- 'sand_iam:identity_export:sensitive'
-- 'sand_iam:identity_group:disable'
-- 'sand_iam:identity_group:index'
-- 'sand_iam:identity_group:read'
-- 'sand_iam:identity_group:save'
-- 'sand_iam:identity_group:update'
-- 'sand_iam:identity_group_member:add'
-- 'sand_iam:identity_group_member:index'
-- 'sand_iam:identity_group_member:remove'
-- 'sand_iam:identity_group_role:grant'
-- 'sand_iam:identity_group_role:index'
-- 'sand_iam:identity_group_role:revoke'
-- 'sand_iam:identity_import:confirm'
-- 'sand_iam:identity_import:index'
-- 'sand_iam:identity_import:preview'
-- 'sand_iam:identity_import:read'
-- 'sand_iam:identity_invitation:index'
-- 'sand_iam:identity_invitation:read'
-- 'sand_iam:identity_invitation:resend'
-- 'sand_iam:identity_invitation:revoke'
-- 'sand_iam:identity_invitation:send'
-- 'sand_iam:identity_provider:disable'
-- 'sand_iam:identity_provider:index'
-- 'sand_iam:identity_provider:read'
-- 'sand_iam:identity_provider:save'
-- 'sand_iam:identity_provider:update'
-- 'sand_iam:identity_role:grant'
-- 'sand_iam:identity_role:index'
-- 'sand_iam:identity_role:revoke'
-- 'sand_iam:identity_user_type:grant'
-- 'sand_iam:identity_user_type:index'
-- 'sand_iam:identity_user_type:revoke'
-- 'sand_iam:initialization:apply'
-- 'sand_iam:initialization:disable'
-- 'sand_iam:initialization:export'
-- 'sand_iam:initialization:index'
-- 'sand_iam:initialization:preview'
-- 'sand_iam:initialization:read'
-- 'sand_iam:initialization:rollback'
-- 'sand_iam:initialization:save'
-- 'sand_iam:initialization:update'
-- 'sand_iam:message_provider:configure'
-- 'sand_iam:message_provider:disable'
-- 'sand_iam:message_provider:index'
-- 'sand_iam:message_provider:read'
-- 'sand_iam:message_provider:save'
-- 'sand_iam:message_provider:test'
-- 'sand_iam:message_provider:update'
-- 'sand_iam:message_provider_mount:disable'
-- 'sand_iam:message_provider_mount:index'
-- 'sand_iam:message_provider_mount:save'
-- 'sand_iam:oauth_client:disable'
-- 'sand_iam:oauth_client:index'
-- 'sand_iam:oauth_client:read'
-- 'sand_iam:oauth_client:rotate'
-- 'sand_iam:oauth_client:save'
-- 'sand_iam:oauth_client:update'
-- 'sand_iam:oauth_registration_token:index'
-- 'sand_iam:oauth_registration_token:issue'
-- 'sand_iam:oauth_registration_token:revoke'
-- 'sand_iam:onboarding:apply'
-- 'sand_iam:onboarding:preview'
-- 'sand_iam:organization:disable'
-- 'sand_iam:organization:index'
-- 'sand_iam:organization:read'
-- 'sand_iam:organization:save'
-- 'sand_iam:organization:update'
-- 'sand_iam:policy:disable'
-- 'sand_iam:policy:index'
-- 'sand_iam:policy:publish'
-- 'sand_iam:policy:read'
-- 'sand_iam:policy:revoke'
-- 'sand_iam:policy:save'
-- 'sand_iam:policy:update'
-- 'sand_iam:radius_nas:configure'
-- 'sand_iam:radius_nas:disable'
-- 'sand_iam:radius_nas:index'
-- 'sand_iam:radius_nas:read'
-- 'sand_iam:radius_nas:save'
-- 'sand_iam:radius_nas:update'
-- 'sand_iam:resource:disable'
-- 'sand_iam:resource:index'
-- 'sand_iam:resource:read'
-- 'sand_iam:resource:save'
-- 'sand_iam:resource:update'
-- 'sand_iam:role:disable'
-- 'sand_iam:role:index'
-- 'sand_iam:role:read'
-- 'sand_iam:role:save'
-- 'sand_iam:role:update'
-- 'sand_iam:security_alert:index'
-- 'sand_iam:security_alert:read'
-- 'sand_iam:security_alert:resolve'
-- 'sand_iam:service:disable'
-- 'sand_iam:service:index'
-- 'sand_iam:service:read'
-- 'sand_iam:service:save'
-- 'sand_iam:service:update'
-- 'sand_iam:service_action:disable'
-- 'sand_iam:service_action:index'
-- 'sand_iam:service_action:read'
-- 'sand_iam:service_action:save'
-- 'sand_iam:service_action:update'
-- 'sand_iam:sync_connector:configure'
-- 'sand_iam:sync_connector:disable'
-- 'sand_iam:sync_connector:index'
-- 'sand_iam:sync_connector:read'
-- 'sand_iam:sync_connector:save'
-- 'sand_iam:sync_connector:test'
-- 'sand_iam:sync_connector:update'
-- 'sand_iam:sync_run:index'
-- 'sand_iam:sync_run:run'
-- 'sand_iam:user_type:disable'
-- 'sand_iam:user_type:index'
-- 'sand_iam:user_type:read'
-- 'sand_iam:user_type:save'
-- 'sand_iam:user_type:update'
-- 'sand_iam:webhook:disable'
-- 'sand_iam:webhook:index'
-- 'sand_iam:webhook:read'
-- 'sand_iam:webhook:save'
-- 'sand_iam:webhook:update'
-- 'sand_iam:webhook_delivery:index'
-- 'sand_iam:webhook_delivery:read'
-- 'sand_iam:webhook_delivery:retry'
-- SandIAM current PostgreSQL installation base. Migration source range is 001–033;
-- this generated menu payload is rebuilt from the authoritative lifecycle sources.

-- SandIAM 管理入口与既有权限码。按 code / slug 幂等更新，保留已存在的菜单 ID 与角色绑定。
INSERT INTO "sand_system_menu"
    ("parent_id","name","code","slug","type","path","component","icon","sort","status","create_time","update_time")
SELECT 0,'SandIAM 身份与访问','SandIAM','',1,'/sand-iam','','ri:shield-user-line',98,1,NOW(),NOW()
WHERE NOT EXISTS (SELECT 1 FROM "sand_system_menu" WHERE "code" = 'SandIAM');

UPDATE "sand_system_menu"
SET "name" = 'SandIAM 身份与访问',
    "path" = '/sand-iam',
    "icon" = 'ri:shield-user-line',
    "sort" = 98,
    "status" = 1,
    "update_time" = NOW()
WHERE "code" = 'SandIAM';

WITH menu_def("code","name","path","component","sort","is_hidden") AS (
    VALUES
        ('SandIAMOverview','管理总览','overview','/plugin/sand-iam/index/index',100,2),
        ('SandIAMConnection','客户与应用接入','connection','/plugin/sand-iam/connection/index',99,2),
        ('SandIAMPeopleAccess','应用用户与权限','people-access','/plugin/sand-iam/people-access/index',98,2),
        ('SandIAMAuditTroubleshooting','审计与排错','audit-troubleshooting','/plugin/sand-iam/audit-troubleshooting/index',97,2),
        ('SandIAMApiGovernance','接口与访问控制','api-governance','/plugin/sand-iam/api-governance/index',96,2),
        ('SandIAMAuthSession','认证与会话','auth-session','/plugin/sand-iam/auth-session/index',95,2),
        ('SandIAMEventNotification','事件通知','event-notification','/plugin/sand-iam/event-notification/index',94,2),
        ('SandIAMGettingStarted','第一次使用','getting-started','/plugin/sand-iam/getting-started/index',93,1),
        ('SandIAMOrganization','客户主体（组织）','organization','/plugin/sand-iam/organization/index',89,1),
        ('SandIAMApplication','接入应用','application','/plugin/sand-iam/application/index',88,1),
        ('SandIAMEnvironment','应用环境','environment','/plugin/sand-iam/environment/index',87,1),
        ('SandIAMWorkload','服务调用身份','workload-client','/plugin/sand-iam/workload-client/index',86,1),
        ('SandIAMGrant','服务授权','service-grant','/plugin/sand-iam/service-grant/index',85,1),
        ('SandIAMCredential','调用凭证','credential','/plugin/sand-iam/credential/index',84,1),
        ('SandIAMService','平台服务','service','/plugin/sand-iam/service/index',83,1),
        ('SandIAMServiceAction','服务动作','action','/plugin/sand-iam/action/index',82,1),
        ('SandIAMIdentityProvider','身份源','identity-provider','/plugin/sand-iam/identity-provider/index',81,1),
        ('SandIAMIdentity','应用用户身份','identity','/plugin/sand-iam/identity/index',80,1),
        ('SandIAMIdentityBinding','身份绑定','identity-binding','/plugin/sand-iam/identity-binding/index',79,1),
        ('SandIAMUserType','用户类型','user-type','/plugin/sand-iam/user-type/index',78,1),
        ('SandIAMRole','角色','role','/plugin/sand-iam/role/index',77,1),
        ('SandIAMIdentityUserType','身份用户类型','identity-user-type','/plugin/sand-iam/identity-user-type/index',76,1),
        ('SandIAMIdentityRole','身份角色','identity-role','/plugin/sand-iam/identity-role/index',75,1),
        ('SandIAMResource','业务资源','resource','/plugin/sand-iam/resource/index',74,1),
        ('SandIAMPolicy','授权策略','policy','/plugin/sand-iam/policy/index',73,1),
        ('SandIAMAdminScope','管理范围','admin-scope','/plugin/sand-iam/admin-scope/index',72,1),
        ('SandIAMAdminOrganizationGrant','客户主体管理委派','admin-organization-grant','/plugin/sand-iam/admin-organization-grant/index',72,1),
        ('SandIAMAudit','访问审计','audit','/plugin/sand-iam/audit/index',71,1),
        ('SandIAMApplicationBusinessAction','应用业务动作','application-business-action','/plugin/sand-iam/application-business-action/index',70,2),
        ('SandIAMApiResource','接口目录','api-resource','/plugin/sand-iam/api-resource/index',69,2),
        ('SandIAMApiRouteBinding','路由绑定','api-route-binding','/plugin/sand-iam/api-route-binding/index',68,2),
        ('SandIAMRouteManifest','路由清单','route-manifest','/plugin/sand-iam/route-manifest/index',67,2),
        ('SandIAMPolicySimulate','策略模拟','policy-simulate','/plugin/sand-iam/policy-simulate/index',66,2),
        ('SandIAMAuthPolicy','认证设置','auth-policy','/plugin/sand-iam/auth-policy/index',65,1),
        ('SandIAMApplicationExperience','登录外观','application-experience','/plugin/sand-iam/application-experience/index',64,1),
        ('SandIAMMessageProvider','消息服务','message-provider','/plugin/sand-iam/message-provider/index',63,1),
        ('SandIAMFederationConfig','联合配置','federation-config','/plugin/sand-iam/federation-config/index',62,1),
        ('SandIAMScimTokens','SCIM 令牌','scim-tokens','/plugin/sand-iam/scim-tokens/index',61,1),
        ('SandIAMRadiusNas','RADIUS 网络设备','radius-nas','/plugin/sand-iam/radius-nas/index',60,1),
        ('SandIAMOAuthClient','OAuth 客户端','oauth-client','/plugin/sand-iam/oauth-client/index',59,1),
        ('SandIAMOAuthRegistrationToken','动态注册令牌','oauth-registration-token','/plugin/sand-iam/oauth-registration-token/index',58,1),
        ('SandIAMCasService','CAS 接入服务','cas-service','/plugin/sand-iam/cas-service/index',57,1),
        ('SandIAMDeveloperDocs','开发者接入','developer-docs','/plugin/sand-iam/developer-docs/index',56,1),
        ('SandIAMAdminApplicationGrant','应用管理员委派','admin-application-grant','/plugin/sand-iam/admin-application-grant/index',55,1),
        ('SandIAMIdentityGroup','用户组','identity-group','/plugin/sand-iam/identity-group/index',54,1),
        ('SandIAMIdentityInvitation','用户邀请','identity-invitation','/plugin/sand-iam/identity-invitation/index',53,1),
        ('SandIAMIdentityImport','用户导入导出','identity-import','/plugin/sand-iam/identity-import/index',52,1),
        ('SandIAMSyncConnector','用户同步','sync-connector','/plugin/sand-iam/sync-connector/index',51,1),
        ('SandIAMWebhook','事件通知地址','webhook','/plugin/sand-iam/webhook/index',50,1),
        ('SandIAMWebhookDelivery','投递记录','webhook-delivery','/plugin/sand-iam/webhook-delivery/index',49,1),
        ('SandIAMApplicationNetworkPolicy','应用网络规则','application-network-policy','/plugin/sand-iam/application-network-policy/index',48,1),
        ('SandIAMSecurityAlert','安全告警','security-alert','/plugin/sand-iam/security-alert/index',47,1),
        ('SandIAMAuditRetentionPolicy','审计保留策略','audit-retention-policy','/plugin/sand-iam/audit-retention-policy/index',46,1),
        ('SandIAMInitialization','初始化配置','initialization','/plugin/sand-iam/initialization/index',45,1)
    ), route_menu("code") AS (
    VALUES
        ('SandIAMConnection'),
        ('SandIAMPeopleAccess'),
        ('SandIAMAuthSession'),
        ('SandIAMAuditTroubleshooting'),
        ('SandIAMApiGovernance'),
        ('SandIAMAdminScope'),
        ('SandIAMEventNotification'),
        ('SandIAMGettingStarted'),
        ('SandIAMApplicationBusinessAction'),
        ('SandIAMApiResource'),
        ('SandIAMApiRouteBinding'),
        ('SandIAMRouteManifest'),
        ('SandIAMPolicySimulate'),
        ('SandIAMAuthPolicy'),
        ('SandIAMApplicationExperience'),
        ('SandIAMMessageProvider'),
        ('SandIAMFederationConfig'),
        ('SandIAMScimTokens'),
        ('SandIAMRadiusNas'),
        ('SandIAMOAuthClient'),
        ('SandIAMOAuthRegistrationToken'),
        ('SandIAMCasService'),
        ('SandIAMDeveloperDocs'),
        ('SandIAMAdminApplicationGrant'),
        ('SandIAMIdentityGroup'),
        ('SandIAMIdentityInvitation'),
        ('SandIAMIdentityImport'),
        ('SandIAMSyncConnector'),
        ('SandIAMWebhook'),
        ('SandIAMWebhookDelivery'),
        ('SandIAMApplicationNetworkPolicy'),
        ('SandIAMSecurityAlert'),
        ('SandIAMAuditRetentionPolicy'),
        ('SandIAMInitialization')
), canonical_route("id","code") AS (
    SELECT DISTINCT ON (candidate."code") candidate."id", candidate."code"
    FROM "sand_system_menu" candidate
    JOIN route_menu ON route_menu."code" = candidate."code"
    CROSS JOIN LATERAL (
        SELECT "id" FROM "sand_system_menu" WHERE "code" = 'SandIAM' ORDER BY "id" LIMIT 1
    ) root
    ORDER BY candidate."code",
             CASE WHEN candidate."parent_id" = root."id" AND candidate."type" = 2 THEN 0 ELSE 1 END,
             candidate."id"
)
UPDATE "sand_system_menu" menu
SET "parent_id" = CASE WHEN route_menu."code" IS NULL THEN menu."parent_id" ELSE root."id" END,
    "type" = CASE WHEN route_menu."code" IS NULL THEN menu."type" ELSE 2 END,
    "name" = menu_def."name",
    "path" = menu_def."path",
    "component" = menu_def."component",
    "sort" = menu_def."sort",
    "is_hidden" = menu_def."is_hidden",
    "status" = 1,
    "update_time" = NOW()
FROM menu_def
LEFT JOIN route_menu ON route_menu."code" = menu_def."code"
CROSS JOIN LATERAL (
    SELECT "id" FROM "sand_system_menu" WHERE "code" = 'SandIAM' ORDER BY "id" LIMIT 1
) root
LEFT JOIN canonical_route ON canonical_route."code" = menu_def."code"
WHERE menu."code" = menu_def."code"
  AND (route_menu."code" IS NULL OR menu."id" = canonical_route."id");

WITH menu_def("code","name","path","component","sort","is_hidden") AS (
    VALUES
        ('SandIAMOverview','管理总览','overview','/plugin/sand-iam/index/index',100,2),
        ('SandIAMConnection','客户与应用接入','connection','/plugin/sand-iam/connection/index',99,2),
        ('SandIAMPeopleAccess','应用用户与权限','people-access','/plugin/sand-iam/people-access/index',98,2),
        ('SandIAMAuditTroubleshooting','审计与排错','audit-troubleshooting','/plugin/sand-iam/audit-troubleshooting/index',97,2),
        ('SandIAMApiGovernance','接口与访问控制','api-governance','/plugin/sand-iam/api-governance/index',96,2),
        ('SandIAMAuthSession','认证与会话','auth-session','/plugin/sand-iam/auth-session/index',95,2),
        ('SandIAMEventNotification','事件通知','event-notification','/plugin/sand-iam/event-notification/index',94,2),
        ('SandIAMGettingStarted','第一次使用','getting-started','/plugin/sand-iam/getting-started/index',93,1),
        ('SandIAMOrganization','客户主体（组织）','organization','/plugin/sand-iam/organization/index',89,1),
        ('SandIAMApplication','接入应用','application','/plugin/sand-iam/application/index',88,1),
        ('SandIAMEnvironment','应用环境','environment','/plugin/sand-iam/environment/index',87,1),
        ('SandIAMWorkload','服务调用身份','workload-client','/plugin/sand-iam/workload-client/index',86,1),
        ('SandIAMGrant','服务授权','service-grant','/plugin/sand-iam/service-grant/index',85,1),
        ('SandIAMCredential','调用凭证','credential','/plugin/sand-iam/credential/index',84,1),
        ('SandIAMService','平台服务','service','/plugin/sand-iam/service/index',83,1),
        ('SandIAMServiceAction','服务动作','action','/plugin/sand-iam/action/index',82,1),
        ('SandIAMIdentityProvider','身份源','identity-provider','/plugin/sand-iam/identity-provider/index',81,1),
        ('SandIAMIdentity','应用用户身份','identity','/plugin/sand-iam/identity/index',80,1),
        ('SandIAMIdentityBinding','身份绑定','identity-binding','/plugin/sand-iam/identity-binding/index',79,1),
        ('SandIAMUserType','用户类型','user-type','/plugin/sand-iam/user-type/index',78,1),
        ('SandIAMRole','角色','role','/plugin/sand-iam/role/index',77,1),
        ('SandIAMIdentityUserType','身份用户类型','identity-user-type','/plugin/sand-iam/identity-user-type/index',76,1),
        ('SandIAMIdentityRole','身份角色','identity-role','/plugin/sand-iam/identity-role/index',75,1),
        ('SandIAMResource','业务资源','resource','/plugin/sand-iam/resource/index',74,1),
        ('SandIAMPolicy','授权策略','policy','/plugin/sand-iam/policy/index',73,1),
        ('SandIAMAdminScope','管理范围','admin-scope','/plugin/sand-iam/admin-scope/index',72,1),
        ('SandIAMAdminOrganizationGrant','客户主体管理委派','admin-organization-grant','/plugin/sand-iam/admin-organization-grant/index',72,1),
        ('SandIAMAudit','访问审计','audit','/plugin/sand-iam/audit/index',71,1),
        ('SandIAMApplicationBusinessAction','应用业务动作','application-business-action','/plugin/sand-iam/application-business-action/index',70,2),
        ('SandIAMApiResource','接口目录','api-resource','/plugin/sand-iam/api-resource/index',69,2),
        ('SandIAMApiRouteBinding','路由绑定','api-route-binding','/plugin/sand-iam/api-route-binding/index',68,2),
        ('SandIAMRouteManifest','路由清单','route-manifest','/plugin/sand-iam/route-manifest/index',67,2),
        ('SandIAMPolicySimulate','策略模拟','policy-simulate','/plugin/sand-iam/policy-simulate/index',66,2),
        ('SandIAMAuthPolicy','认证设置','auth-policy','/plugin/sand-iam/auth-policy/index',65,1),
        ('SandIAMApplicationExperience','登录外观','application-experience','/plugin/sand-iam/application-experience/index',64,1),
        ('SandIAMMessageProvider','消息服务','message-provider','/plugin/sand-iam/message-provider/index',63,1),
        ('SandIAMFederationConfig','联合配置','federation-config','/plugin/sand-iam/federation-config/index',62,1),
        ('SandIAMScimTokens','SCIM 令牌','scim-tokens','/plugin/sand-iam/scim-tokens/index',61,1),
        ('SandIAMRadiusNas','RADIUS 网络设备','radius-nas','/plugin/sand-iam/radius-nas/index',60,1),
        ('SandIAMOAuthClient','OAuth 客户端','oauth-client','/plugin/sand-iam/oauth-client/index',59,1),
        ('SandIAMOAuthRegistrationToken','动态注册令牌','oauth-registration-token','/plugin/sand-iam/oauth-registration-token/index',58,1),
        ('SandIAMCasService','CAS 接入服务','cas-service','/plugin/sand-iam/cas-service/index',57,1),
        ('SandIAMDeveloperDocs','开发者接入','developer-docs','/plugin/sand-iam/developer-docs/index',56,1),
        ('SandIAMAdminApplicationGrant','应用管理员委派','admin-application-grant','/plugin/sand-iam/admin-application-grant/index',55,1),
        ('SandIAMIdentityGroup','用户组','identity-group','/plugin/sand-iam/identity-group/index',54,1),
        ('SandIAMIdentityInvitation','用户邀请','identity-invitation','/plugin/sand-iam/identity-invitation/index',53,1),
        ('SandIAMIdentityImport','用户导入导出','identity-import','/plugin/sand-iam/identity-import/index',52,1),
        ('SandIAMSyncConnector','用户同步','sync-connector','/plugin/sand-iam/sync-connector/index',51,1),
        ('SandIAMWebhook','事件通知地址','webhook','/plugin/sand-iam/webhook/index',50,1),
        ('SandIAMWebhookDelivery','投递记录','webhook-delivery','/plugin/sand-iam/webhook-delivery/index',49,1),
        ('SandIAMApplicationNetworkPolicy','应用网络规则','application-network-policy','/plugin/sand-iam/application-network-policy/index',48,1),
        ('SandIAMSecurityAlert','安全告警','security-alert','/plugin/sand-iam/security-alert/index',47,1),
        ('SandIAMAuditRetentionPolicy','审计保留策略','audit-retention-policy','/plugin/sand-iam/audit-retention-policy/index',46,1),
        ('SandIAMInitialization','初始化配置','initialization','/plugin/sand-iam/initialization/index',45,1)
)
INSERT INTO "sand_system_menu"
    ("parent_id","name","code","slug","type","path","component","icon","sort","is_hidden","status","create_time","update_time")
SELECT root."id", menu_def."name", menu_def."code", '', 2, menu_def."path", menu_def."component", '', menu_def."sort", menu_def."is_hidden", 1, NOW(), NOW()
FROM menu_def
JOIN LATERAL (
    SELECT "id" FROM "sand_system_menu" WHERE "code" = 'SandIAM' ORDER BY "id" LIMIT 1
) root ON TRUE
WHERE NOT EXISTS (
    SELECT 1 FROM "sand_system_menu" existing WHERE existing."code" = menu_def."code"
);

-- 已有受限角色保留原实体权限时，同时补上新的任务路径入口；这里只补导航，不授予接口权限。
WITH path_entity("path_code","entity_code") AS (
    VALUES
        ('SandIAMConnection','SandIAMOrganization'),
        ('SandIAMConnection','SandIAMApplication'),
        ('SandIAMConnection','SandIAMEnvironment'),
        ('SandIAMConnection','SandIAMWorkload'),
        ('SandIAMConnection','SandIAMGrant'),
        ('SandIAMConnection','SandIAMCredential'),
        ('SandIAMConnection','SandIAMService'),
        ('SandIAMConnection','SandIAMServiceAction'),
        ('SandIAMPeopleAccess','SandIAMIdentityProvider'),
        ('SandIAMPeopleAccess','SandIAMIdentity'),
        ('SandIAMPeopleAccess','SandIAMIdentityBinding'),
        ('SandIAMPeopleAccess','SandIAMUserType'),
        ('SandIAMPeopleAccess','SandIAMRole'),
        ('SandIAMPeopleAccess','SandIAMIdentityUserType'),
        ('SandIAMPeopleAccess','SandIAMIdentityRole'),
        ('SandIAMPeopleAccess','SandIAMResource'),
        ('SandIAMPeopleAccess','SandIAMPolicy'),
        ('SandIAMPeopleAccess','SandIAMAdminScope'),
        ('SandIAMPeopleAccess','SandIAMAdminOrganizationGrant'),
        ('SandIAMAuditTroubleshooting','SandIAMAudit'),
        ('SandIAMAuditTroubleshooting','SandIAMGrant'),
        ('SandIAMAuditTroubleshooting','SandIAMCredential'),
        ('SandIAMApiGovernance','SandIAMApiResource'),
        ('SandIAMApiGovernance','SandIAMApiRouteBinding'),
        ('SandIAMApiGovernance','SandIAMPolicy'),
        ('SandIAMApiGovernance','SandIAMConnection'),
        ('SandIAMApplicationBusinessAction','SandIAMApiResource'),
        ('SandIAMApiResource','SandIAMApiResource'),
        ('SandIAMApiRouteBinding','SandIAMApiRouteBinding'),
        ('SandIAMRouteManifest','SandIAMConnection'),
        ('SandIAMPolicySimulate','SandIAMPolicy')
), route_menu("code") AS (
    SELECT menu."code"
    FROM "sand_system_menu" menu
    JOIN "sand_system_menu" root ON root."id" = menu."parent_id"
    WHERE root."code" = 'SandIAM'
      AND menu."type" = 2
), sandiam_role("role_id","entity_code") AS (
    SELECT DISTINCT role_menu."role_id", entity."code"
    FROM "sand_system_role_menu" role_menu
    JOIN "sand_system_menu" assigned ON assigned."id" = role_menu."menu_id"
    JOIN "sand_system_menu" entity
      ON entity."id" = assigned."id" OR entity."id" = assigned."parent_id"
    JOIN "sand_system_menu" root
      ON root."id" = entity."parent_id" AND root."code" = 'SandIAM'
    WHERE entity."code" <> 'SandIAMOverview'
      AND NOT EXISTS (
          SELECT 1 FROM route_menu WHERE route_menu."code" = entity."code"
      )
), route_menu_anchor("anchor_code","route_code") AS (
    VALUES
        ('SandIAMConnection','SandIAMApiGovernance'),
        ('SandIAMConnection','SandIAMRouteManifest'),
        ('SandIAMPolicy','SandIAMApiGovernance'),
        ('SandIAMPolicy','SandIAMPolicySimulate')
), route_permission_anchor("anchor_slug","route_code") AS (
    VALUES
        ('sand_iam:organization:index','SandIAMConnection'),
        ('sand_iam:identity:index','SandIAMPeopleAccess'),
        ('sand_iam:auth_policy:index','SandIAMAuthSession'),
        ('sand_iam:audit:index','SandIAMAuditTroubleshooting'),
        ('sand_iam:api_resource:index','SandIAMApiGovernance'),
        ('sand_iam:api_resource:index','SandIAMApplicationBusinessAction'),
        ('sand_iam:api_resource:index','SandIAMApiResource'),
        ('sand_iam:api_route_binding:index','SandIAMApiGovernance'),
        ('sand_iam:api_route_binding:index','SandIAMApiRouteBinding'),
        ('sand_iam:onboarding:preview','SandIAMRouteManifest'),
        ('sand_iam:policy:index','SandIAMPolicySimulate'),
        ('sand_iam:auth_policy:index','SandIAMAuthPolicy'),
        ('sand_iam:application_experience:index','SandIAMApplicationExperience'),
        ('sand_iam:message_provider:index','SandIAMMessageProvider'),
        ('sand_iam:federation:configure','SandIAMFederationConfig'),
        ('sand_iam:scim:token_index','SandIAMScimTokens'),
        ('sand_iam:radius_nas:index','SandIAMRadiusNas'),
        ('sand_iam:oauth_client:index','SandIAMOAuthClient'),
        ('sand_iam:oauth_registration_token:index','SandIAMOAuthRegistrationToken'),
        ('sand_iam:cas_service:index','SandIAMCasService'),
        ('sand_iam:developer:openapi','SandIAMDeveloperDocs'),
        ('sand_iam:admin_organization_grant:index','SandIAMAdminScope'),
        ('sand_iam:admin_application_grant:index','SandIAMAdminScope'),
        ('sand_iam:admin_application_grant:index','SandIAMAdminApplicationGrant'),
        ('sand_iam:identity_group:index','SandIAMIdentityGroup'),
        ('sand_iam:identity_invitation:index','SandIAMIdentityInvitation'),
        ('sand_iam:identity_import:index','SandIAMIdentityImport'),
        ('sand_iam:sync_connector:index','SandIAMSyncConnector'),
        ('sand_iam:webhook:index','SandIAMEventNotification'),
        ('sand_iam:webhook:index','SandIAMWebhook'),
        ('sand_iam:webhook_delivery:index','SandIAMWebhookDelivery'),
        ('sand_iam:application_network_policy:index','SandIAMApplicationNetworkPolicy'),
        ('sand_iam:security_alert:index','SandIAMSecurityAlert'),
        ('sand_iam:audit_retention_policy:index','SandIAMAuditRetentionPolicy'),
        ('sand_iam:initialization:index','SandIAMInitialization')
), sandiam_root("id") AS (
    SELECT "id"
    FROM "sand_system_menu"
    WHERE "code" = 'SandIAM'
    ORDER BY "id"
    LIMIT 1
), route_target("code","menu_id") AS (
    SELECT menu."code", menu."id"
    FROM "sand_system_menu" menu
    JOIN sandiam_root ON menu."parent_id" = sandiam_root."id"
    JOIN route_menu ON route_menu."code" = menu."code"
    WHERE menu."type" = 2
      AND NOT EXISTS (
          SELECT 1
          FROM "sand_system_menu" duplicate_route
          WHERE duplicate_route."code" = menu."code"
            AND duplicate_route."parent_id" = menu."parent_id"
            AND duplicate_route."type" = 2
            AND duplicate_route."id" <> menu."id"
      )
), route_anchor_required("role_id","menu_id") AS (
    -- Keep route inheritance exact: navigation/entity menu anchors use code,
    -- while hidden machine-action leaves use their stable permission slug.
    SELECT DISTINCT role_menu."role_id", route_target."menu_id"
    FROM "sand_system_role_menu" role_menu
    JOIN "sand_system_menu" anchor ON anchor."id" = role_menu."menu_id"
    JOIN route_menu_anchor ON route_menu_anchor."anchor_code" = anchor."code"
    JOIN route_target ON route_target."code" = route_menu_anchor."route_code"
    UNION
    SELECT DISTINCT role_menu."role_id", route_target."menu_id"
    FROM "sand_system_role_menu" role_menu
    JOIN "sand_system_menu" permission ON permission."id" = role_menu."menu_id"
    JOIN route_permission_anchor ON route_permission_anchor."anchor_slug" = permission."slug"
    JOIN route_target ON route_target."code" = route_permission_anchor."route_code"
), route_role("role_id") AS (
    SELECT DISTINCT "role_id" FROM route_anchor_required
), overview_access_role("role_id") AS (
    SELECT "role_id" FROM sandiam_role
    UNION
    SELECT "role_id" FROM route_role
    UNION
    SELECT role_menu."role_id"
    FROM "sand_system_role_menu" role_menu
    JOIN "sand_system_menu" overview ON overview."id" = role_menu."menu_id"
    WHERE overview."code" = 'SandIAMOverview'
), required_menu("role_id","menu_id") AS (
    SELECT DISTINCT sandiam_role."role_id", menu."id"
    FROM sandiam_role
    JOIN "sand_system_menu" menu ON menu."code" IN ('SandIAM','SandIAMOverview')
    UNION
    SELECT DISTINCT route_role."role_id", menu."id"
    FROM route_role
    JOIN "sand_system_menu" menu ON menu."code" IN ('SandIAM','SandIAMOverview')
    UNION
    SELECT DISTINCT overview_access_role."role_id", menu."id"
    FROM overview_access_role
    JOIN "sand_system_menu" menu ON menu."code" = 'SandIAMGettingStarted'
    UNION
    SELECT DISTINCT sandiam_role."role_id", menu."id"
    FROM sandiam_role
    JOIN path_entity ON path_entity."entity_code" = sandiam_role."entity_code"
    JOIN "sand_system_menu" menu ON menu."code" = path_entity."path_code"
    LEFT JOIN route_menu ON route_menu."code" = path_entity."path_code"
    WHERE route_menu."code" IS NULL
    UNION
    SELECT "role_id", "menu_id"
    FROM route_anchor_required
)
INSERT INTO "sand_system_role_menu" ("role_id","menu_id")
SELECT required_menu."role_id", required_menu."menu_id"
FROM required_menu
WHERE NOT EXISTS (
    SELECT 1 FROM "sand_system_role_menu" existing
    WHERE existing."role_id" = required_menu."role_id"
      AND existing."menu_id" = required_menu."menu_id"
);

-- The host does not enforce this pair as a unique constraint. Keep one row
-- per relationship so a previous lifecycle run cannot retain true duplicates.
DELETE FROM "sand_system_role_menu" duplicate
USING "sand_system_role_menu" retained, "sand_system_menu" menu
WHERE duplicate."role_id" = retained."role_id"
  AND duplicate."menu_id" = retained."menu_id"
  AND menu."id" = duplicate."menu_id"
  AND (
      menu."code" = 'SandIAM'
      OR menu."code" LIKE 'SandIAM%'
      OR menu."code" LIKE 'sand\_iam:%' ESCAPE '\'
  )
  AND duplicate.ctid > retained.ctid;

WITH permission_def("parent_code","name","slug","sort") AS (
    VALUES
        ('SandIAMOrganization','列表','sand_iam:organization:index',100),
        ('SandIAMOrganization','读取','sand_iam:organization:read',99),
        ('SandIAMOrganization','保存','sand_iam:organization:save',98),
        ('SandIAMOrganization','更新','sand_iam:organization:update',97),
        ('SandIAMOrganization','停用','sand_iam:organization:disable',96),
        ('SandIAMApplication','列表','sand_iam:application:index',100),
        ('SandIAMApplication','读取','sand_iam:application:read',99),
        ('SandIAMApplication','保存','sand_iam:application:save',98),
        ('SandIAMApplication','更新','sand_iam:application:update',97),
        ('SandIAMApplication','停用','sand_iam:application:disable',96),
        ('SandIAMEnvironment','列表','sand_iam:environment:index',100),
        ('SandIAMEnvironment','读取','sand_iam:environment:read',99),
        ('SandIAMEnvironment','保存','sand_iam:environment:save',98),
        ('SandIAMEnvironment','更新','sand_iam:environment:update',97),
        ('SandIAMEnvironment','停用','sand_iam:environment:disable',96),
        ('SandIAMWorkload','列表','sand_iam:client:index',100),
        ('SandIAMWorkload','读取','sand_iam:client:read',99),
        ('SandIAMWorkload','保存','sand_iam:client:save',98),
        ('SandIAMWorkload','更新','sand_iam:client:update',97),
        ('SandIAMWorkload','停用','sand_iam:client:disable',96),
        ('SandIAMGrant','列表','sand_iam:grant:index',100),
        ('SandIAMGrant','读取','sand_iam:grant:read',99),
        ('SandIAMGrant','保存','sand_iam:grant:save',98),
        ('SandIAMGrant','更新','sand_iam:grant:update',97),
        ('SandIAMGrant','撤销','sand_iam:grant:revoke',96),
        ('SandIAMCredential','列表','sand_iam:credential:index',100),
        ('SandIAMCredential','读取','sand_iam:credential:read',99),
        ('SandIAMCredential','签发','sand_iam:credential:issue',98),
        ('SandIAMCredential','轮换','sand_iam:credential:rotate',97),
        ('SandIAMCredential','撤销','sand_iam:credential:revoke',96),
        ('SandIAMService','列表','sand_iam:service:index',100),
        ('SandIAMService','读取','sand_iam:service:read',99),
        ('SandIAMService','保存','sand_iam:service:save',98),
        ('SandIAMService','更新','sand_iam:service:update',97),
        ('SandIAMService','停用','sand_iam:service:disable',96),
        ('SandIAMServiceAction','列表','sand_iam:service_action:index',100),
        ('SandIAMServiceAction','读取','sand_iam:service_action:read',99),
        ('SandIAMServiceAction','保存','sand_iam:service_action:save',98),
        ('SandIAMServiceAction','更新','sand_iam:service_action:update',97),
        ('SandIAMServiceAction','停用','sand_iam:service_action:disable',96),
        ('SandIAMIdentityProvider','列表','sand_iam:identity_provider:index',100),
        ('SandIAMIdentityProvider','读取','sand_iam:identity_provider:read',99),
        ('SandIAMIdentityProvider','保存','sand_iam:identity_provider:save',98),
        ('SandIAMIdentityProvider','更新','sand_iam:identity_provider:update',97),
        ('SandIAMIdentityProvider','停用','sand_iam:identity_provider:disable',96),
        ('SandIAMIdentity','列表','sand_iam:identity:index',100),
        ('SandIAMIdentity','读取','sand_iam:identity:read',99),
        ('SandIAMIdentity','保存','sand_iam:identity:save',98),
        ('SandIAMIdentity','更新','sand_iam:identity:update',97),
        ('SandIAMIdentity','停用','sand_iam:identity:disable',96),
        ('SandIAMIdentityBinding','列表','sand_iam:identity_binding:index',100),
        ('SandIAMIdentityBinding','读取','sand_iam:identity_binding:read',99),
        ('SandIAMIdentityBinding','保存','sand_iam:identity_binding:save',98),
        ('SandIAMIdentityBinding','更新','sand_iam:identity_binding:update',97),
        ('SandIAMIdentityBinding','停用','sand_iam:identity_binding:disable',96),
        ('SandIAMUserType','列表','sand_iam:user_type:index',100),
        ('SandIAMUserType','读取','sand_iam:user_type:read',99),
        ('SandIAMUserType','保存','sand_iam:user_type:save',98),
        ('SandIAMUserType','更新','sand_iam:user_type:update',97),
        ('SandIAMUserType','停用','sand_iam:user_type:disable',96),
        ('SandIAMRole','列表','sand_iam:role:index',100),
        ('SandIAMRole','读取','sand_iam:role:read',99),
        ('SandIAMRole','保存','sand_iam:role:save',98),
        ('SandIAMRole','更新','sand_iam:role:update',97),
        ('SandIAMRole','停用','sand_iam:role:disable',96),
        ('SandIAMIdentityUserType','列表','sand_iam:identity_user_type:index',100),
        ('SandIAMIdentityUserType','授予','sand_iam:identity_user_type:grant',99),
        ('SandIAMIdentityUserType','撤销','sand_iam:identity_user_type:revoke',98),
        ('SandIAMIdentityRole','列表','sand_iam:identity_role:index',100),
        ('SandIAMIdentityRole','授予','sand_iam:identity_role:grant',99),
        ('SandIAMIdentityRole','撤销','sand_iam:identity_role:revoke',98),
        ('SandIAMResource','列表','sand_iam:resource:index',100),
        ('SandIAMResource','读取','sand_iam:resource:read',99),
        ('SandIAMResource','保存','sand_iam:resource:save',98),
        ('SandIAMResource','更新','sand_iam:resource:update',97),
        ('SandIAMResource','停用','sand_iam:resource:disable',96),
        ('SandIAMPolicy','列表','sand_iam:policy:index',100),
        ('SandIAMPolicy','读取','sand_iam:policy:read',99),
        ('SandIAMPolicy','保存','sand_iam:policy:save',98),
        ('SandIAMPolicy','更新','sand_iam:policy:update',97),
        ('SandIAMPolicy','停用','sand_iam:policy:disable',96),
        ('SandIAMPolicy','发布','sand_iam:policy:publish',95),
        ('SandIAMPolicy','撤销','sand_iam:policy:revoke',94),
        ('SandIAMAdminOrganizationGrant','列表','sand_iam:admin_organization_grant:index',100),
        ('SandIAMAdminOrganizationGrant','读取','sand_iam:admin_organization_grant:read',99),
        ('SandIAMAdminOrganizationGrant','保存','sand_iam:admin_organization_grant:save',98),
        ('SandIAMAdminOrganizationGrant','更新','sand_iam:admin_organization_grant:update',97),
        ('SandIAMAdminOrganizationGrant','停用','sand_iam:admin_organization_grant:disable',96),
        ('SandIAMAudit','列表','sand_iam:audit:index',100),
        ('SandIAMIdentity','认证策略列表','sand_iam:auth_policy:index',95),
        ('SandIAMIdentity','认证策略读取','sand_iam:auth_policy:read',94),
        ('SandIAMIdentity','认证策略保存','sand_iam:auth_policy:save',93),
        ('SandIAMIdentity','认证策略更新','sand_iam:auth_policy:update',92),
        ('SandIAMIdentity','认证策略停用','sand_iam:auth_policy:disable',91),
        ('SandIAMAudit','读取','sand_iam:audit:read',99)
)
INSERT INTO "sand_system_menu"
    ("parent_id","name","code","slug","type","path","component","icon","sort","status","create_time","update_time")
SELECT parent."id", permission_def."name", '', permission_def."slug", 3, '', '', '', permission_def."sort", 1, NOW(), NOW()
FROM permission_def
JOIN "sand_system_menu" parent ON parent."code" = permission_def."parent_code"
WHERE NOT EXISTS (
    SELECT 1 FROM "sand_system_menu" existing WHERE existing."slug" = permission_def."slug"
);

-- Authoritative source for a fresh package installation.
-- This script owns only sand_iam_* objects.
BEGIN;

CREATE TABLE IF NOT EXISTS sand_iam_organization (
    id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    code varchar(64) NOT NULL,
    name varchar(128) NOT NULL,
    status smallint NOT NULL DEFAULT 1 CHECK (status IN (1, 2)),
    created_by bigint NULL,
    updated_by bigint NULL,
    create_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    delete_time timestamp(0) without time zone NULL,
    CONSTRAINT uk_sand_iam_organization_code UNIQUE (code)
);

CREATE TABLE IF NOT EXISTS sand_iam_application (
    id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    organization_id bigint NOT NULL REFERENCES sand_iam_organization(id) ON DELETE RESTRICT,
    code varchar(64) NOT NULL,
    name varchar(128) NOT NULL,
    status smallint NOT NULL DEFAULT 1 CHECK (status IN (1, 2)),
    created_by bigint NULL,
    updated_by bigint NULL,
    create_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    delete_time timestamp(0) without time zone NULL,
    CONSTRAINT uk_sand_iam_application_organization_code UNIQUE (organization_id, code)
);
CREATE INDEX IF NOT EXISTS idx_sand_iam_application_organization_id ON sand_iam_application (organization_id);

CREATE TABLE IF NOT EXISTS sand_iam_environment (
    id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    application_id bigint NOT NULL REFERENCES sand_iam_application(id) ON DELETE RESTRICT,
    code varchar(64) NOT NULL,
    name varchar(128) NOT NULL,
    status smallint NOT NULL DEFAULT 1 CHECK (status IN (1, 2)),
    created_by bigint NULL,
    updated_by bigint NULL,
    create_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    delete_time timestamp(0) without time zone NULL,
    CONSTRAINT uk_sand_iam_environment_application_code UNIQUE (application_id, code)
);
CREATE INDEX IF NOT EXISTS idx_sand_iam_environment_application_id ON sand_iam_environment (application_id);

CREATE TABLE IF NOT EXISTS sand_iam_workload_client (
    id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    environment_id bigint NOT NULL REFERENCES sand_iam_environment(id) ON DELETE RESTRICT,
    code varchar(64) NOT NULL,
    name varchar(128) NOT NULL,
    audience varchar(128) NOT NULL,
    status smallint NOT NULL DEFAULT 1 CHECK (status IN (1, 2)),
    created_by bigint NULL,
    updated_by bigint NULL,
    create_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    delete_time timestamp(0) without time zone NULL,
    CONSTRAINT uk_sand_iam_workload_client_environment_code UNIQUE (environment_id, code)
);
CREATE INDEX IF NOT EXISTS idx_sand_iam_workload_client_environment_id ON sand_iam_workload_client (environment_id);

CREATE TABLE IF NOT EXISTS sand_iam_credential (
    id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    workload_client_id bigint NOT NULL REFERENCES sand_iam_workload_client(id) ON DELETE RESTRICT,
    name varchar(128) NOT NULL,
    key_prefix varchar(32) NOT NULL,
    secret_hash varchar(255) NOT NULL,
    expire_time timestamp(0) without time zone NULL,
    revoked_time timestamp(0) without time zone NULL,
    status smallint NOT NULL DEFAULT 1 CHECK (status IN (1, 2)),
    created_by bigint NULL,
    updated_by bigint NULL,
    create_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    delete_time timestamp(0) without time zone NULL,
    CONSTRAINT uk_sand_iam_credential_key_prefix UNIQUE (key_prefix),
    CONSTRAINT uk_sand_iam_credential_secret_hash UNIQUE (secret_hash)
);
CREATE INDEX IF NOT EXISTS idx_sand_iam_credential_client_active ON sand_iam_credential (workload_client_id, status, expire_time);

CREATE TABLE IF NOT EXISTS sand_iam_service (
    id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    code varchar(64) NOT NULL,
    name varchar(128) NOT NULL,
    status smallint NOT NULL DEFAULT 1 CHECK (status IN (1, 2)),
    created_by bigint NULL,
    updated_by bigint NULL,
    create_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    delete_time timestamp(0) without time zone NULL,
    CONSTRAINT uk_sand_iam_service_code UNIQUE (code)
);

CREATE TABLE IF NOT EXISTS sand_iam_service_action (
    id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    service_id bigint NOT NULL REFERENCES sand_iam_service(id) ON DELETE RESTRICT,
    code varchar(96) NOT NULL,
    name varchar(128) NOT NULL,
    status smallint NOT NULL DEFAULT 1 CHECK (status IN (1, 2)),
    created_by bigint NULL,
    updated_by bigint NULL,
    create_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    delete_time timestamp(0) without time zone NULL,
    CONSTRAINT uk_sand_iam_service_action_service_code UNIQUE (service_id, code)
);
CREATE INDEX IF NOT EXISTS idx_sand_iam_service_action_service_id ON sand_iam_service_action (service_id);

CREATE TABLE IF NOT EXISTS sand_iam_service_grant (
    id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    workload_client_id bigint NOT NULL REFERENCES sand_iam_workload_client(id) ON DELETE RESTRICT,
    service_action_id bigint NOT NULL REFERENCES sand_iam_service_action(id) ON DELETE RESTRICT,
    audience varchar(128) NOT NULL,
    quota_policy jsonb NOT NULL DEFAULT '{}'::jsonb,
    data_class varchar(32) NULL DEFAULT 'internal',
    network_policy jsonb NOT NULL DEFAULT '{}'::jsonb,
    expire_time timestamp(0) without time zone NULL,
    revoked_time timestamp(0) without time zone NULL,
    status smallint NOT NULL DEFAULT 1 CHECK (status IN (1, 2)),
    created_by bigint NULL,
    updated_by bigint NULL,
    create_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    delete_time timestamp(0) without time zone NULL,
    CONSTRAINT uk_sand_iam_service_grant_client_action_audience UNIQUE (workload_client_id, service_action_id, audience)
);
CREATE INDEX IF NOT EXISTS idx_sand_iam_service_grant_action_active ON sand_iam_service_grant (service_action_id, status, expire_time);

CREATE TABLE IF NOT EXISTS sand_iam_identity (
    id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    application_id bigint NOT NULL REFERENCES sand_iam_application(id) ON DELETE RESTRICT,
    code varchar(64) NOT NULL,
    display_name varchar(128) NOT NULL,
    status smallint NOT NULL DEFAULT 1 CHECK (status IN (1, 2)),
    created_by bigint NULL,
    updated_by bigint NULL,
    create_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    delete_time timestamp(0) without time zone NULL,
    CONSTRAINT uk_sand_iam_identity_application_code UNIQUE (application_id, code),
    CONSTRAINT uk_sand_iam_identity_id_application UNIQUE (id, application_id)
);
CREATE INDEX IF NOT EXISTS idx_sand_iam_identity_application_id ON sand_iam_identity (application_id);

CREATE TABLE IF NOT EXISTS sand_iam_identity_provider (
    id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    application_id bigint NOT NULL REFERENCES sand_iam_application(id) ON DELETE RESTRICT,
    code varchar(64) NOT NULL,
    name varchar(128) NOT NULL,
    status smallint NOT NULL DEFAULT 1 CHECK (status IN (1, 2)),
    created_by bigint NULL,
    updated_by bigint NULL,
    create_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    delete_time timestamp(0) without time zone NULL,
    CONSTRAINT uk_sand_iam_identity_provider_application_code UNIQUE (application_id, code),
    CONSTRAINT uk_sand_iam_identity_provider_id_application UNIQUE (id, application_id)
);
CREATE INDEX IF NOT EXISTS idx_sand_iam_identity_provider_application_id ON sand_iam_identity_provider (application_id);

CREATE TABLE IF NOT EXISTS sand_iam_identity_binding (
    id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    application_id bigint NOT NULL,
    identity_id bigint NOT NULL,
    identity_provider_id bigint NOT NULL,
    subject varchar(191) NOT NULL,
    status smallint NOT NULL DEFAULT 1 CHECK (status IN (1, 2)),
    created_by bigint NULL,
    updated_by bigint NULL,
    create_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    delete_time timestamp(0) without time zone NULL,
    CONSTRAINT uk_sand_iam_identity_binding_provider_subject UNIQUE (identity_provider_id, subject),
    CONSTRAINT fk_sand_iam_identity_binding_identity_application FOREIGN KEY (identity_id, application_id) REFERENCES sand_iam_identity(id, application_id) ON DELETE RESTRICT,
    CONSTRAINT fk_sand_iam_identity_binding_provider_application FOREIGN KEY (identity_provider_id, application_id) REFERENCES sand_iam_identity_provider(id, application_id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS idx_sand_iam_identity_binding_identity_id ON sand_iam_identity_binding (identity_id);
CREATE INDEX IF NOT EXISTS idx_sand_iam_identity_binding_provider_id ON sand_iam_identity_binding (identity_provider_id);
CREATE INDEX IF NOT EXISTS idx_sand_iam_identity_binding_application_id ON sand_iam_identity_binding (application_id);

CREATE TABLE IF NOT EXISTS sand_iam_user_type (
    id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    application_id bigint NOT NULL REFERENCES sand_iam_application(id) ON DELETE RESTRICT,
    code varchar(64) NOT NULL,
    name varchar(128) NOT NULL,
    status smallint NOT NULL DEFAULT 1 CHECK (status IN (1, 2)),
    created_by bigint NULL,
    updated_by bigint NULL,
    create_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    delete_time timestamp(0) without time zone NULL,
    CONSTRAINT uk_sand_iam_user_type_application_code UNIQUE (application_id, code)
);

CREATE TABLE IF NOT EXISTS sand_iam_identity_user_type (
    id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    identity_id bigint NOT NULL REFERENCES sand_iam_identity(id) ON DELETE RESTRICT,
    user_type_id bigint NOT NULL REFERENCES sand_iam_user_type(id) ON DELETE RESTRICT,
    status smallint NOT NULL DEFAULT 1 CHECK (status IN (1, 2)),
    created_by bigint NULL,
    updated_by bigint NULL,
    create_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    delete_time timestamp(0) without time zone NULL,
    CONSTRAINT uk_sand_iam_identity_user_type_identity_type UNIQUE (identity_id, user_type_id)
);
CREATE INDEX IF NOT EXISTS idx_sand_iam_identity_user_type_type_id ON sand_iam_identity_user_type (user_type_id);

CREATE TABLE IF NOT EXISTS sand_iam_role (
    id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    application_id bigint NOT NULL REFERENCES sand_iam_application(id) ON DELETE RESTRICT,
    code varchar(64) NOT NULL,
    name varchar(128) NOT NULL,
    status smallint NOT NULL DEFAULT 1 CHECK (status IN (1, 2)),
    created_by bigint NULL,
    updated_by bigint NULL,
    create_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    delete_time timestamp(0) without time zone NULL,
    CONSTRAINT uk_sand_iam_role_application_code UNIQUE (application_id, code)
);

CREATE TABLE IF NOT EXISTS sand_iam_identity_role (
    id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    identity_id bigint NOT NULL REFERENCES sand_iam_identity(id) ON DELETE RESTRICT,
    role_id bigint NOT NULL REFERENCES sand_iam_role(id) ON DELETE RESTRICT,
    status smallint NOT NULL DEFAULT 1 CHECK (status IN (1, 2)),
    created_by bigint NULL,
    updated_by bigint NULL,
    create_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    delete_time timestamp(0) without time zone NULL,
    CONSTRAINT uk_sand_iam_identity_role_identity_role UNIQUE (identity_id, role_id)
);
CREATE INDEX IF NOT EXISTS idx_sand_iam_identity_role_role_id ON sand_iam_identity_role (role_id);

CREATE TABLE IF NOT EXISTS sand_iam_resource (
    id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    application_id bigint NOT NULL REFERENCES sand_iam_application(id) ON DELETE RESTRICT,
    code varchar(64) NOT NULL,
    name varchar(128) NOT NULL,
    owner_field varchar(64) NULL,
    organization_field varchar(64) NULL,
    status smallint NOT NULL DEFAULT 1 CHECK (status IN (1, 2)),
    created_by bigint NULL,
    updated_by bigint NULL,
    create_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    delete_time timestamp(0) without time zone NULL,
    CONSTRAINT uk_sand_iam_resource_application_code UNIQUE (application_id, code)
);
CREATE INDEX IF NOT EXISTS idx_sand_iam_resource_application_id ON sand_iam_resource (application_id);

CREATE TABLE IF NOT EXISTS sand_iam_policy (
    id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    application_id bigint NOT NULL REFERENCES sand_iam_application(id) ON DELETE RESTRICT,
    resource_id bigint NOT NULL REFERENCES sand_iam_resource(id) ON DELETE RESTRICT,
    role_id bigint NULL REFERENCES sand_iam_role(id) ON DELETE RESTRICT,
    identity_id bigint NULL REFERENCES sand_iam_identity(id) ON DELETE RESTRICT,
    action varchar(64) NOT NULL,
    effect varchar(8) NOT NULL,
    condition jsonb NOT NULL DEFAULT '{}'::jsonb,
    scope jsonb NOT NULL DEFAULT '{}'::jsonb,
    priority integer NOT NULL DEFAULT 100,
    state varchar(16) NOT NULL DEFAULT 'draft',
    status smallint NOT NULL DEFAULT 1 CHECK (status IN (1, 2)),
    created_by bigint NULL,
    updated_by bigint NULL,
    create_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    delete_time timestamp(0) without time zone NULL,
    CONSTRAINT ck_sand_iam_policy_subject CHECK ((role_id IS NOT NULL AND identity_id IS NULL) OR (role_id IS NULL AND identity_id IS NOT NULL)),
    CONSTRAINT ck_sand_iam_policy_effect CHECK (effect IN ('allow', 'deny')),
    CONSTRAINT ck_sand_iam_policy_state CHECK (state IN ('draft', 'published', 'revoked'))
);
CREATE INDEX IF NOT EXISTS idx_sand_iam_policy_resource_action_state ON sand_iam_policy (resource_id, action, state, status, priority);
CREATE INDEX IF NOT EXISTS idx_sand_iam_policy_role_id ON sand_iam_policy (role_id) WHERE role_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_sand_iam_policy_identity_id ON sand_iam_policy (identity_id) WHERE identity_id IS NOT NULL;

CREATE TABLE IF NOT EXISTS sand_iam_admin_organization_grant (
    id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    admin_user_id bigint NOT NULL,
    organization_id bigint NOT NULL REFERENCES sand_iam_organization(id) ON DELETE RESTRICT,
    status smallint NOT NULL DEFAULT 1 CHECK (status IN (1, 2)),
    created_by bigint NULL,
    updated_by bigint NULL,
    create_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    delete_time timestamp(0) without time zone NULL,
    CONSTRAINT uk_sand_iam_admin_organization_grant_admin_organization UNIQUE (admin_user_id, organization_id)
);
CREATE INDEX IF NOT EXISTS idx_sand_iam_admin_organization_grant_organization_active ON sand_iam_admin_organization_grant (organization_id, status);

CREATE TABLE IF NOT EXISTS sand_iam_audit_log (
    id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    actor_type varchar(32) NOT NULL,
    actor_ref varchar(128) NOT NULL,
    organization_id bigint NULL REFERENCES sand_iam_organization(id) ON DELETE RESTRICT,
    application_id bigint NULL REFERENCES sand_iam_application(id) ON DELETE RESTRICT,
    action varchar(96) NOT NULL,
    resource_type varchar(64) NOT NULL,
    resource_id bigint NULL,
    outcome varchar(16) NOT NULL CHECK (outcome IN ('allowed', 'denied', 'succeeded', 'failed')),
    request_id varchar(96) NOT NULL,
    context jsonb NOT NULL DEFAULT '{}'::jsonb,
    create_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uk_sand_iam_audit_log_request_action UNIQUE (request_id, action)
);
CREATE INDEX IF NOT EXISTS idx_sand_iam_audit_log_application_time ON sand_iam_audit_log (application_id, create_time);
CREATE INDEX IF NOT EXISTS idx_sand_iam_audit_log_action_outcome_time ON sand_iam_audit_log (action, outcome, create_time);

CREATE TABLE IF NOT EXISTS sand_iam_identity_auth (
    id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    application_id bigint NOT NULL,
    identity_id bigint NOT NULL,
    username varchar(64) NOT NULL,
    email varchar(320) NULL,
    phone varchar(16) NULL,
    password_hash varchar(255) NOT NULL,
    password_changed_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    email_verified_time timestamp(0) without time zone NULL,
    phone_verified_time timestamp(0) without time zone NULL,
    last_login_time timestamp(0) without time zone NULL,
    failed_login_count integer NOT NULL DEFAULT 0 CHECK (failed_login_count >= 0),
    locked_until timestamp(0) without time zone NULL,
    status smallint NOT NULL DEFAULT 1 CHECK (status IN (1, 2)),
    created_by bigint NULL,
    updated_by bigint NULL,
    create_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    delete_time timestamp(0) without time zone NULL,
    CONSTRAINT uk_sand_iam_identity_auth_identity UNIQUE (identity_id),
    CONSTRAINT uk_sand_iam_identity_auth_identity_application UNIQUE (identity_id, application_id),
    CONSTRAINT uk_sand_iam_identity_auth_application_username UNIQUE (application_id, username),
    CONSTRAINT fk_sand_iam_identity_auth_identity_application FOREIGN KEY (identity_id, application_id) REFERENCES sand_iam_identity(id, application_id) ON DELETE RESTRICT
);
CREATE UNIQUE INDEX IF NOT EXISTS uk_sand_iam_identity_auth_application_email ON sand_iam_identity_auth (application_id, email) WHERE email IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS uk_sand_iam_identity_auth_application_phone ON sand_iam_identity_auth (application_id, phone) WHERE phone IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_sand_iam_identity_auth_application_active ON sand_iam_identity_auth (application_id, status);

CREATE TABLE IF NOT EXISTS sand_iam_auth_session (
    id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    application_id bigint NOT NULL,
    identity_id bigint NOT NULL,
    access_token_hash char(64) NOT NULL,
    refresh_token_hash char(64) NOT NULL,
    previous_refresh_token_hash char(64) NULL,
    access_expire_time timestamp(0) without time zone NOT NULL,
    refresh_expire_time timestamp(0) without time zone NOT NULL,
    last_used_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    revoked_time timestamp(0) without time zone NULL,
    ip_hash char(64) NOT NULL,
    user_agent varchar(255) NOT NULL DEFAULT '',
    status smallint NOT NULL DEFAULT 1 CHECK (status IN (1, 2)),
    created_by bigint NULL,
    updated_by bigint NULL,
    create_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    delete_time timestamp(0) without time zone NULL,
    CONSTRAINT uk_sand_iam_auth_session_access_token_hash UNIQUE (access_token_hash),
    CONSTRAINT uk_sand_iam_auth_session_refresh_token_hash UNIQUE (refresh_token_hash),
    CONSTRAINT uk_sand_iam_auth_session_previous_refresh_token_hash UNIQUE (previous_refresh_token_hash),
    CONSTRAINT fk_sand_iam_auth_session_identity_application FOREIGN KEY (identity_id, application_id) REFERENCES sand_iam_identity(id, application_id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS idx_sand_iam_auth_session_identity_active ON sand_iam_auth_session (application_id, identity_id, status, refresh_expire_time);

CREATE TABLE IF NOT EXISTS sand_iam_auth_verification (
    id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    application_id bigint NOT NULL,
    identity_id bigint NOT NULL,
    purpose varchar(32) NOT NULL CHECK (purpose IN ('email_verify', 'phone_verify', 'password_reset')),
    channel varchar(16) NOT NULL CHECK (channel IN ('email', 'phone')),
    destination_hash char(64) NOT NULL,
    code_hash char(64) NOT NULL,
    expire_time timestamp(0) without time zone NOT NULL,
    consumed_time timestamp(0) without time zone NULL,
    attempt_count integer NOT NULL DEFAULT 0 CHECK (attempt_count >= 0),
    status smallint NOT NULL DEFAULT 1 CHECK (status IN (1, 2)),
    created_by bigint NULL,
    updated_by bigint NULL,
    create_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    delete_time timestamp(0) without time zone NULL,
    CONSTRAINT fk_sand_iam_auth_verification_identity_application FOREIGN KEY (identity_id, application_id) REFERENCES sand_iam_identity(id, application_id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS idx_sand_iam_auth_verification_active ON sand_iam_auth_verification (application_id, identity_id, purpose, channel, status, expire_time);

CREATE TABLE IF NOT EXISTS sand_iam_auth_rate_limit (
    id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    application_id bigint NOT NULL REFERENCES sand_iam_application(id) ON DELETE RESTRICT,
    action varchar(32) NOT NULL,
    subject_hash char(64) NOT NULL,
    window_start timestamp(0) without time zone NOT NULL,
    attempt_count integer NOT NULL DEFAULT 0 CHECK (attempt_count >= 0),
    create_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    delete_time timestamp(0) without time zone NULL,
    CONSTRAINT uk_sand_iam_auth_rate_limit_application_action_subject UNIQUE (application_id, action, subject_hash)
);

ALTER TABLE sand_iam_identity_auth ADD COLUMN IF NOT EXISTS pepper_version varchar(32) NOT NULL DEFAULT 'v1';
ALTER TABLE sand_iam_auth_session ADD COLUMN IF NOT EXISTS pepper_version varchar(32) NOT NULL DEFAULT 'v1';
ALTER TABLE sand_iam_auth_verification ADD COLUMN IF NOT EXISTS pepper_version varchar(32) NOT NULL DEFAULT 'v1';
CREATE TABLE IF NOT EXISTS sand_iam_auth_refresh_token (
    id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    session_id bigint NOT NULL REFERENCES sand_iam_auth_session(id) ON DELETE RESTRICT,
    token_hash char(64) NOT NULL, pepper_version varchar(32) NOT NULL,
    expire_time timestamp(0) without time zone NOT NULL, used_time timestamp(0) without time zone NULL, revoked_time timestamp(0) without time zone NULL,
    status smallint NOT NULL DEFAULT 1 CHECK (status IN (1, 2)), create_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP, update_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    delete_time timestamp(0) without time zone NULL,
    CONSTRAINT uk_sand_iam_auth_refresh_token_hash UNIQUE (token_hash)
);
ALTER TABLE sand_iam_auth_rate_limit ADD COLUMN IF NOT EXISTS delete_time timestamp(0) without time zone NULL;
ALTER TABLE sand_iam_auth_refresh_token ADD COLUMN IF NOT EXISTS delete_time timestamp(0) without time zone NULL;
CREATE INDEX IF NOT EXISTS idx_sand_iam_auth_refresh_token_session_active ON sand_iam_auth_refresh_token (session_id, status, expire_time);
CREATE TABLE IF NOT EXISTS sand_iam_auth_policy (
    id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY, application_id bigint NOT NULL REFERENCES sand_iam_application(id) ON DELETE RESTRICT,
    password_min_length integer NOT NULL DEFAULT 12 CHECK (password_min_length BETWEEN 12 AND 128), password_max_length integer NOT NULL DEFAULT 128 CHECK (password_max_length BETWEEN 12 AND 128),
    require_uppercase smallint NOT NULL DEFAULT 1 CHECK (require_uppercase IN (1, 2)), require_lowercase smallint NOT NULL DEFAULT 1 CHECK (require_lowercase IN (1, 2)), require_digit smallint NOT NULL DEFAULT 1 CHECK (require_digit IN (1, 2)), require_symbol smallint NOT NULL DEFAULT 1 CHECK (require_symbol IN (1, 2)),
    require_email_verification smallint NOT NULL DEFAULT 2 CHECK (require_email_verification IN (1, 2)), require_phone_verification smallint NOT NULL DEFAULT 2 CHECK (require_phone_verification IN (1, 2)),
    access_token_ttl_seconds integer NOT NULL DEFAULT 900 CHECK (access_token_ttl_seconds BETWEEN 60 AND 3600), refresh_token_ttl_seconds integer NOT NULL DEFAULT 2592000 CHECK (refresh_token_ttl_seconds BETWEEN 300 AND 7776000), verification_ttl_seconds integer NOT NULL DEFAULT 600 CHECK (verification_ttl_seconds BETWEEN 60 AND 3600),
    max_login_failures integer NOT NULL DEFAULT 5 CHECK (max_login_failures BETWEEN 3 AND 20), lock_seconds integer NOT NULL DEFAULT 900 CHECK (lock_seconds BETWEEN 60 AND 86400), rate_limit_per_minute integer NOT NULL DEFAULT 10 CHECK (rate_limit_per_minute BETWEEN 1 AND 1000),
    status smallint NOT NULL DEFAULT 1 CHECK (status IN (1, 2)), created_by bigint NULL, updated_by bigint NULL, create_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP, update_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP, delete_time timestamp(0) without time zone NULL,
    CONSTRAINT uk_sand_iam_auth_policy_application UNIQUE (application_id), CONSTRAINT ck_sand_iam_auth_policy_password_range CHECK (password_min_length <= password_max_length)
);
ALTER TABLE sand_iam_auth_policy ADD COLUMN IF NOT EXISTS registration_enabled smallint NOT NULL DEFAULT 2 CHECK (registration_enabled IN (1, 2));
WITH oauth_parent AS (
    SELECT id FROM sand_system_menu WHERE code = 'SandIAMPeopleAccess' ORDER BY id LIMIT 1
), oauth_permission(name, code, slug, sort) AS (
    VALUES
      ('OAuth客户端查看','sand_iam:oauth_client:index','oauth-client-index',901),
      ('OAuth客户端读取','sand_iam:oauth_client:read','oauth-client-read',902),
      ('OAuth客户端创建','sand_iam:oauth_client:save','oauth-client-save',903),
      ('OAuth客户端更新','sand_iam:oauth_client:update','oauth-client-update',904),
      ('OAuth客户端停用','sand_iam:oauth_client:disable','oauth-client-disable',905),
      ('OAuth客户端轮换密钥','sand_iam:oauth_client:rotate','oauth-client-rotate',906)
)
INSERT INTO sand_system_menu (parent_id,name,code,slug,type,path,component,icon,sort,is_hidden,status,create_time,update_time)
SELECT oauth_parent.id, oauth_permission.name, oauth_permission.code, oauth_permission.slug, 3, '', '', '', oauth_permission.sort, 1, 1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP
FROM oauth_parent CROSS JOIN oauth_permission
WHERE NOT EXISTS (SELECT 1 FROM sand_system_menu known WHERE known.code = oauth_permission.code);

INSERT INTO sand_system_role_menu (role_id,menu_id)
SELECT DISTINCT inherited.role_id, permission.id
FROM sand_system_role_menu inherited
JOIN sand_system_menu parent ON parent.id = inherited.menu_id AND parent.code = 'SandIAMPeopleAccess'
JOIN sand_system_menu permission ON permission.code IN (
  'sand_iam:oauth_client:index','sand_iam:oauth_client:read','sand_iam:oauth_client:save',
  'sand_iam:oauth_client:update','sand_iam:oauth_client:disable','sand_iam:oauth_client:rotate'
)
WHERE NOT EXISTS (
    SELECT 1
    FROM sand_system_role_menu existing
    WHERE existing.role_id = inherited.role_id
      AND existing.menu_id = permission.id
);

COMMIT;

-- IAM-T02-004 BEGIN: keep this marker for the isolated 003 -> current upgrade test.
BEGIN;
ALTER TABLE sand_iam_auth_policy ADD COLUMN IF NOT EXISTS webauthn_rp_id varchar(255) NULL, ADD COLUMN IF NOT EXISTS webauthn_allowed_origins jsonb NOT NULL DEFAULT '[]'::jsonb, ADD COLUMN IF NOT EXISTS webauthn_user_verification varchar(16) NOT NULL DEFAULT 'required';
DO $$ BEGIN ALTER TABLE sand_iam_auth_policy ADD CONSTRAINT ck_sand_iam_auth_policy_webauthn_uv CHECK (webauthn_user_verification IN ('required', 'preferred', 'discouraged')); EXCEPTION WHEN duplicate_object OR duplicate_table THEN NULL; END $$;
DO $$ BEGIN ALTER TABLE sand_iam_identity ADD CONSTRAINT uk_sand_iam_identity_id_application UNIQUE (id, application_id); EXCEPTION WHEN duplicate_object OR duplicate_table THEN NULL; END $$;
CREATE TABLE IF NOT EXISTS sand_iam_mfa_factor (
    id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    application_id bigint NOT NULL REFERENCES sand_iam_application(id) ON DELETE RESTRICT,
    identity_id bigint NOT NULL,
    type varchar(16) NOT NULL CHECK (type = 'totp'),
    name varchar(128) NOT NULL,
    encrypted_secret text NULL,
    encryption_version varchar(32) NULL,
    last_used_counter bigint NULL CHECK (last_used_counter >= 0),
    last_used_time timestamp(0) without time zone NULL,
    revoked_time timestamp(0) without time zone NULL,
    status smallint NOT NULL DEFAULT 1 CHECK (status IN (1, 2)),
    create_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    delete_time timestamp(0) without time zone NULL,
    CONSTRAINT ck_sand_iam_mfa_factor_material CHECK (encrypted_secret IS NOT NULL),
    CONSTRAINT uk_sand_iam_mfa_factor_id_application_identity UNIQUE (id, application_id, identity_id),
    CONSTRAINT fk_sand_iam_mfa_factor_identity_application FOREIGN KEY (identity_id, application_id) REFERENCES sand_iam_identity(id, application_id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS idx_sand_iam_mfa_factor_identity_active ON sand_iam_mfa_factor (application_id, identity_id, status, type);
CREATE UNIQUE INDEX IF NOT EXISTS uk_sand_iam_mfa_factor_identity_active_totp ON sand_iam_mfa_factor (application_id, identity_id) WHERE status = 1 AND delete_time IS NULL;
CREATE TABLE IF NOT EXISTS sand_iam_mfa_recovery_code (
    id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    application_id bigint NOT NULL REFERENCES sand_iam_application(id) ON DELETE RESTRICT,
    identity_id bigint NOT NULL,
    factor_id bigint NOT NULL,
    code_hash char(64) NOT NULL,
    generation bigint NOT NULL,
    used_time timestamp(0) without time zone NULL,
    status smallint NOT NULL DEFAULT 1 CHECK (status IN (1, 2)),
    create_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    delete_time timestamp(0) without time zone NULL,
    CONSTRAINT uk_sand_iam_mfa_recovery_code_hash UNIQUE (application_id, code_hash),
    CONSTRAINT fk_sand_iam_mfa_recovery_identity_application FOREIGN KEY (identity_id, application_id) REFERENCES sand_iam_identity(id, application_id) ON DELETE RESTRICT,
    CONSTRAINT fk_sand_iam_mfa_recovery_factor_scope FOREIGN KEY (factor_id, application_id, identity_id) REFERENCES sand_iam_mfa_factor(id, application_id, identity_id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS idx_sand_iam_mfa_recovery_code_identity_active ON sand_iam_mfa_recovery_code (application_id, identity_id, status);
CREATE TABLE IF NOT EXISTS sand_iam_auth_challenge (
    id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    application_id bigint NOT NULL REFERENCES sand_iam_application(id) ON DELETE RESTRICT,
    identity_id bigint NULL,
    purpose varchar(32) NOT NULL CHECK (purpose IN ('mfa_login', 'webauthn_register', 'webauthn_auth')),
    token_hash char(64) NOT NULL,
    encrypted_challenge text NOT NULL,
    encrypted_user_handle text NULL,
    encryption_version varchar(32) NOT NULL,
    context jsonb NOT NULL DEFAULT '{}'::jsonb,
    expire_time timestamp(0) without time zone NOT NULL,
    consumed_time timestamp(0) without time zone NULL,
    attempt_count integer NOT NULL DEFAULT 0 CHECK (attempt_count BETWEEN 0 AND 5),
    status smallint NOT NULL DEFAULT 1 CHECK (status IN (1, 2)),
    create_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    delete_time timestamp(0) without time zone NULL,
    CONSTRAINT uk_sand_iam_auth_challenge_token UNIQUE (token_hash),
    CONSTRAINT ck_sand_iam_auth_challenge_identity CHECK (purpose = 'webauthn_auth' OR identity_id IS NOT NULL),
    CONSTRAINT fk_sand_iam_auth_challenge_identity_application FOREIGN KEY (identity_id, application_id) REFERENCES sand_iam_identity(id, application_id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS idx_sand_iam_auth_challenge_active ON sand_iam_auth_challenge (application_id, purpose, status, expire_time);
CREATE TABLE IF NOT EXISTS sand_iam_webauthn_credential (
    id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    application_id bigint NOT NULL REFERENCES sand_iam_application(id) ON DELETE RESTRICT,
    identity_id bigint NOT NULL,
    name varchar(128) NOT NULL,
    credential_id varchar(1400) NOT NULL,
    public_key text NOT NULL,
    user_handle varchar(128) NOT NULL,
    sign_count bigint NOT NULL DEFAULT 0 CHECK (sign_count >= 0),
    last_used_time timestamp(0) without time zone NULL,
    revoked_time timestamp(0) without time zone NULL,
    status smallint NOT NULL DEFAULT 1 CHECK (status IN (1, 2)),
    create_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    delete_time timestamp(0) without time zone NULL,
    CONSTRAINT uk_sand_iam_webauthn_credential_application_credential UNIQUE (application_id, credential_id),
    CONSTRAINT fk_sand_iam_webauthn_credential_identity_application FOREIGN KEY (identity_id, application_id) REFERENCES sand_iam_identity(id, application_id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS idx_sand_iam_webauthn_credential_identity_active ON sand_iam_webauthn_credential (application_id, identity_id, status);
COMMIT;

-- lifecycle source: migrations/005_oauth_oidc.pgsql
-- IAM-T03-005 BEGIN
-- OAuth 2.0 / OpenID Connect provider records.  All user and client records
-- are application scoped; signing-key history is issuer scoped by design.
BEGIN;

DO $$ BEGIN IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'uk_sand_iam_auth_session_id_application_identity') THEN ALTER TABLE sand_iam_auth_session ADD CONSTRAINT uk_sand_iam_auth_session_id_application_identity UNIQUE (id, application_id, identity_id); END IF; END $$;

CREATE TABLE IF NOT EXISTS sand_iam_oauth_client (
    id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    application_id bigint NOT NULL REFERENCES sand_iam_application(id) ON DELETE RESTRICT,
    code varchar(128) NOT NULL,
    name varchar(128) NOT NULL,
    client_type varchar(16) NOT NULL CHECK (client_type IN ('public', 'confidential')),
    secret_hash varchar(255) NULL,
    secret_version varchar(32) NULL,
    redirect_uris jsonb NOT NULL DEFAULT '[]'::jsonb,
    post_logout_redirect_uris jsonb NOT NULL DEFAULT '[]'::jsonb,
    allowed_scopes jsonb NOT NULL DEFAULT '["openid","profile","email"]'::jsonb,
    allowed_audiences jsonb NOT NULL DEFAULT '[]'::jsonb,
    default_audience varchar(255) NULL,
    status smallint NOT NULL DEFAULT 1 CHECK (status IN (1, 2)),
    create_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    delete_time timestamp(0) without time zone NULL,
    -- client_id is presented at issuer-wide endpoints, so it cannot be scoped
    -- only to an application even though all ownership FKs remain scoped.
    CONSTRAINT uk_sand_iam_oauth_client_code UNIQUE (code),
    CONSTRAINT uk_sand_iam_oauth_client_id_application UNIQUE (id, application_id),
    CONSTRAINT ck_sand_iam_oauth_client_secret CHECK ((client_type = 'public' AND secret_hash IS NULL AND secret_version IS NULL) OR (client_type = 'confidential' AND secret_hash IS NOT NULL AND secret_version IS NOT NULL))
);
CREATE INDEX IF NOT EXISTS idx_sand_iam_oauth_client_application_active ON sand_iam_oauth_client (application_id, status);

CREATE TABLE IF NOT EXISTS sand_iam_oauth_consent (
    id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    application_id bigint NOT NULL REFERENCES sand_iam_application(id) ON DELETE RESTRICT,
    client_id bigint NOT NULL,
    identity_id bigint NOT NULL,
    scope varchar(1000) NOT NULL,
    granted_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    revoked_time timestamp(0) without time zone NULL,
    status smallint NOT NULL DEFAULT 1 CHECK (status IN (1, 2)),
    create_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    delete_time timestamp(0) without time zone NULL,
    CONSTRAINT uk_sand_iam_oauth_consent_scope UNIQUE (application_id, client_id, identity_id),
    CONSTRAINT fk_sand_iam_oauth_consent_client_scope FOREIGN KEY (client_id, application_id) REFERENCES sand_iam_oauth_client(id, application_id) ON DELETE RESTRICT,
    CONSTRAINT fk_sand_iam_oauth_consent_identity_scope FOREIGN KEY (identity_id, application_id) REFERENCES sand_iam_identity(id, application_id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS idx_sand_iam_oauth_consent_identity_active ON sand_iam_oauth_consent (application_id, identity_id, status);

-- Browser authorization requests are server-side, one-time records.  The
-- browser only carries an opaque request handle and a same-site CSRF proof;
-- state, nonce and PKCE data are encrypted inside this record.
CREATE TABLE IF NOT EXISTS sand_iam_oauth_authorization_request (
    id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    application_id bigint NOT NULL REFERENCES sand_iam_application(id) ON DELETE RESTRICT,
    client_id bigint NOT NULL,
    identity_id bigint NULL,
    auth_session_id bigint NULL,
    -- session and identity are intentionally bound only by POST interaction/session.
    request_hash char(64) NOT NULL,
    csrf_hash char(64) NOT NULL,
    encrypted_payload text NOT NULL,
    encryption_version varchar(32) NOT NULL,
    expire_time timestamp(0) without time zone NOT NULL,
    consumed_time timestamp(0) without time zone NULL,
    status smallint NOT NULL DEFAULT 1 CHECK (status IN (1, 2)),
    create_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    delete_time timestamp(0) without time zone NULL,
    CONSTRAINT uk_sand_iam_oauth_authorization_request_hash UNIQUE (request_hash),
    CONSTRAINT ck_sand_iam_oauth_authorization_request_binding CHECK ((identity_id IS NULL AND auth_session_id IS NULL) OR (identity_id IS NOT NULL AND auth_session_id IS NOT NULL)),
    CONSTRAINT fk_sand_iam_oauth_authorization_request_client_scope FOREIGN KEY (client_id, application_id) REFERENCES sand_iam_oauth_client(id, application_id) ON DELETE RESTRICT,
    CONSTRAINT fk_sand_iam_oauth_authorization_request_identity_scope FOREIGN KEY (identity_id, application_id) REFERENCES sand_iam_identity(id, application_id) ON DELETE RESTRICT,
    CONSTRAINT fk_sand_iam_oauth_authorization_request_session_scope FOREIGN KEY (auth_session_id, application_id, identity_id) REFERENCES sand_iam_auth_session(id, application_id, identity_id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS idx_sand_iam_oauth_authorization_request_active ON sand_iam_oauth_authorization_request (application_id, client_id, identity_id, status, expire_time);

CREATE TABLE IF NOT EXISTS sand_iam_oauth_grant (
    id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    application_id bigint NOT NULL REFERENCES sand_iam_application(id) ON DELETE RESTRICT,
    client_id bigint NOT NULL,
    identity_id bigint NULL,
    auth_session_id bigint NULL,
    grant_type varchar(24) NOT NULL CHECK (grant_type IN ('authorization_code', 'client_credentials')),
    scope varchar(1000) NOT NULL,
    auth_time timestamp(0) without time zone NULL,
    revoked_time timestamp(0) without time zone NULL,
    status smallint NOT NULL DEFAULT 1 CHECK (status IN (1, 2)),
    create_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    delete_time timestamp(0) without time zone NULL,
    CONSTRAINT uk_sand_iam_oauth_grant_id_application UNIQUE (id, application_id),
    CONSTRAINT uk_sand_iam_oauth_grant_id_application_client UNIQUE (id, application_id, client_id),
    CONSTRAINT ck_sand_iam_oauth_grant_subject CHECK ((grant_type = 'authorization_code' AND identity_id IS NOT NULL AND auth_session_id IS NOT NULL AND auth_time IS NOT NULL) OR (grant_type = 'client_credentials' AND identity_id IS NULL AND auth_session_id IS NULL AND auth_time IS NULL)),
    CONSTRAINT fk_sand_iam_oauth_grant_client_scope FOREIGN KEY (client_id, application_id) REFERENCES sand_iam_oauth_client(id, application_id) ON DELETE RESTRICT,
    CONSTRAINT fk_sand_iam_oauth_grant_identity_scope FOREIGN KEY (identity_id, application_id) REFERENCES sand_iam_identity(id, application_id) ON DELETE RESTRICT,
    CONSTRAINT fk_sand_iam_oauth_grant_session_scope FOREIGN KEY (auth_session_id, application_id, identity_id) REFERENCES sand_iam_auth_session(id, application_id, identity_id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS idx_sand_iam_oauth_grant_active ON sand_iam_oauth_grant (application_id, client_id, identity_id, status);

CREATE TABLE IF NOT EXISTS sand_iam_authorization_code (
    id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    application_id bigint NOT NULL REFERENCES sand_iam_application(id) ON DELETE RESTRICT,
    client_id bigint NOT NULL,
    identity_id bigint NOT NULL,
    auth_session_id bigint NOT NULL,
    code_hash char(64) NOT NULL,
    redirect_uri varchar(2048) NOT NULL,
    scope varchar(1000) NOT NULL,
    encrypted_nonce text NULL,
    nonce_encryption_version varchar(32) NULL,
    nonce_hash char(64) NULL,
    code_challenge varchar(128) NOT NULL,
    code_challenge_method varchar(8) NOT NULL CHECK (code_challenge_method = 'S256'),
    auth_time timestamp(0) without time zone NOT NULL,
    expire_time timestamp(0) without time zone NOT NULL,
    consumed_time timestamp(0) without time zone NULL,
    status smallint NOT NULL DEFAULT 1 CHECK (status IN (1, 2)),
    create_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    delete_time timestamp(0) without time zone NULL,
    CONSTRAINT uk_sand_iam_authorization_code_hash UNIQUE (code_hash),
    CONSTRAINT fk_sand_iam_authorization_code_client_scope FOREIGN KEY (client_id, application_id) REFERENCES sand_iam_oauth_client(id, application_id) ON DELETE RESTRICT,
    CONSTRAINT fk_sand_iam_authorization_code_identity_scope FOREIGN KEY (identity_id, application_id) REFERENCES sand_iam_identity(id, application_id) ON DELETE RESTRICT,
    CONSTRAINT fk_sand_iam_authorization_code_session_scope FOREIGN KEY (auth_session_id, application_id, identity_id) REFERENCES sand_iam_auth_session(id, application_id, identity_id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS idx_sand_iam_authorization_code_active ON sand_iam_authorization_code (application_id, client_id, status, expire_time);

CREATE TABLE IF NOT EXISTS sand_iam_oauth_token (
    id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    application_id bigint NOT NULL REFERENCES sand_iam_application(id) ON DELETE RESTRICT,
    client_id bigint NOT NULL,
    grant_id bigint NOT NULL,
    identity_id bigint NULL,
    token_type varchar(16) NOT NULL CHECK (token_type IN ('access', 'refresh', 'id')),
    token_hash char(64) NOT NULL,
    token_id varchar(96) NOT NULL,
    scope varchar(1000) NOT NULL,
    expire_time timestamp(0) without time zone NOT NULL,
    used_time timestamp(0) without time zone NULL,
    revoked_time timestamp(0) without time zone NULL,
    status smallint NOT NULL DEFAULT 1 CHECK (status IN (1, 2)),
    create_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    delete_time timestamp(0) without time zone NULL,
    CONSTRAINT uk_sand_iam_oauth_token_hash UNIQUE (token_hash),
    CONSTRAINT uk_sand_iam_oauth_token_id UNIQUE (token_id),
    CONSTRAINT fk_sand_iam_oauth_token_client_scope FOREIGN KEY (client_id, application_id) REFERENCES sand_iam_oauth_client(id, application_id) ON DELETE RESTRICT,
    CONSTRAINT fk_sand_iam_oauth_token_grant_scope FOREIGN KEY (grant_id, application_id, client_id) REFERENCES sand_iam_oauth_grant(id, application_id, client_id) ON DELETE RESTRICT,
    CONSTRAINT fk_sand_iam_oauth_token_identity_scope FOREIGN KEY (identity_id, application_id) REFERENCES sand_iam_identity(id, application_id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS idx_sand_iam_oauth_token_grant_active ON sand_iam_oauth_token (application_id, grant_id, token_type, status, expire_time);

CREATE TABLE IF NOT EXISTS sand_iam_oidc_signing_key (
    id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    kid varchar(128) NOT NULL,
    public_jwk jsonb NOT NULL,
    -- Private material is write-only. Imported verification keys intentionally
    -- have no private material, so the two envelope fields stay nullable as a pair.
    encrypted_private_key text NULL,
    encryption_version varchar(32) NULL,
    algorithm varchar(16) NOT NULL DEFAULT 'RS256',
    state varchar(16) NOT NULL CHECK (state IN ('active', 'verify_only', 'retired')),
    not_before_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    retire_time timestamp(0) without time zone NULL,
    create_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uk_sand_iam_oidc_signing_key_kid UNIQUE (kid)
);
CREATE INDEX IF NOT EXISTS idx_sand_iam_oidc_signing_key_publish ON sand_iam_oidc_signing_key (state, retire_time);
COMMENT ON COLUMN sand_iam_oidc_signing_key.encrypted_private_key IS 'Write-only versioned private-key envelope; NULL only when no private signing material is stored.';
COMMENT ON COLUMN sand_iam_oidc_signing_key.encryption_version IS 'Key-encryption version for encrypted_private_key; NULL when no private signing material is stored.';

COMMIT;
-- IAM-T03-005 END

-- lifecycle source: migrations/006_federation_directory_scim.pgsql
-- IAM-T04-006 BEGIN: application-scoped federation, directory and SCIM.
-- Secrets stay in encrypted_config/token_hash.  Raw directory credentials,
-- bearer tokens and assertion payloads are never persisted.

ALTER TABLE sand_iam_identity_provider
    ADD COLUMN IF NOT EXISTS scope_type varchar(16) NOT NULL DEFAULT 'application',
    ADD COLUMN IF NOT EXISTS organization_id bigint NULL,
    ADD COLUMN IF NOT EXISTS public_code varchar(64) NOT NULL DEFAULT ('ip_' || md5(random()::text || clock_timestamp()::text)),
    ADD COLUMN IF NOT EXISTS provider_type varchar(16) NOT NULL DEFAULT 'local',
    ADD COLUMN IF NOT EXISTS encrypted_config text NULL,
    ADD COLUMN IF NOT EXISTS attribute_mapping jsonb NOT NULL DEFAULT '{}'::jsonb,
    ADD COLUMN IF NOT EXISTS conflict_policy varchar(16) NOT NULL DEFAULT 'reject',
    ADD COLUMN IF NOT EXISTS sync_cursor varchar(512) NULL,
    ADD COLUMN IF NOT EXISTS last_sync_time timestamp(0) without time zone NULL;

UPDATE sand_iam_identity_provider provider
SET organization_id = application.organization_id
FROM sand_iam_application application
WHERE provider.application_id = application.id AND provider.organization_id IS NULL;

ALTER TABLE sand_iam_identity_provider
    ALTER COLUMN organization_id SET NOT NULL,
    ALTER COLUMN application_id DROP NOT NULL,
    DROP CONSTRAINT IF EXISTS ck_sand_iam_identity_provider_type,
    DROP CONSTRAINT IF EXISTS ck_sand_iam_identity_provider_conflict_policy,
    DROP CONSTRAINT IF EXISTS ck_sand_iam_identity_provider_scope;
ALTER TABLE sand_iam_identity_provider
    ADD CONSTRAINT ck_sand_iam_identity_provider_type CHECK (provider_type IN ('local', 'oidc', 'oauth2', 'saml', 'ldap', 'scim', 'kerberos')),
    ADD CONSTRAINT ck_sand_iam_identity_provider_conflict_policy CHECK (conflict_policy IN ('reject', 'link_verified', 'create')),
    ADD CONSTRAINT ck_sand_iam_identity_provider_scope CHECK ((scope_type = 'application' AND application_id IS NOT NULL) OR (scope_type = 'organization' AND application_id IS NULL));
DO $$ BEGIN ALTER TABLE sand_iam_identity_provider ADD CONSTRAINT uk_sand_iam_identity_provider_public_code UNIQUE (public_code); EXCEPTION WHEN duplicate_object OR duplicate_table THEN NULL; END $$;
DO $$ BEGIN ALTER TABLE sand_iam_identity_provider ADD CONSTRAINT fk_sand_iam_identity_provider_organization FOREIGN KEY (organization_id) REFERENCES sand_iam_organization(id) ON DELETE RESTRICT; EXCEPTION WHEN duplicate_object OR duplicate_table THEN NULL; END $$;
ALTER TABLE sand_iam_identity_provider
    ADD COLUMN IF NOT EXISTS scope_application_key bigint GENERATED ALWAYS AS (COALESCE(application_id, 0)) STORED;
DO $$ BEGIN ALTER TABLE sand_iam_application ADD CONSTRAINT uk_sand_iam_application_id_organization UNIQUE (id, organization_id); EXCEPTION WHEN duplicate_object OR duplicate_table THEN NULL; END $$;
DO $$ BEGIN ALTER TABLE sand_iam_identity_provider ADD CONSTRAINT uk_sand_iam_identity_provider_scope_key UNIQUE (id, organization_id, scope_application_key); EXCEPTION WHEN duplicate_object OR duplicate_table THEN NULL; END $$;
DO $$ BEGIN ALTER TABLE sand_iam_identity_provider ADD CONSTRAINT fk_sand_iam_identity_provider_application_organization FOREIGN KEY (application_id, organization_id) REFERENCES sand_iam_application(id, organization_id) ON DELETE RESTRICT; EXCEPTION WHEN duplicate_object OR duplicate_table THEN NULL; END $$;
CREATE INDEX IF NOT EXISTS idx_sand_iam_identity_provider_type_status ON sand_iam_identity_provider (organization_id, provider_type, status);
CREATE UNIQUE INDEX IF NOT EXISTS uk_sand_iam_identity_provider_organization_code ON sand_iam_identity_provider (organization_id, code) WHERE scope_type = 'organization';

CREATE TABLE IF NOT EXISTS sand_iam_identity_provider_application (
    id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    identity_provider_id bigint NOT NULL,
    application_id bigint NOT NULL,
    organization_id bigint NOT NULL,
    provider_scope_application_key bigint NOT NULL,
    status smallint NOT NULL DEFAULT 1 CHECK (status IN (1, 2)),
    create_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uk_sand_iam_identity_provider_application UNIQUE (identity_provider_id, application_id),
    CONSTRAINT ck_sand_iam_identity_provider_application_scope CHECK (provider_scope_application_key = 0 OR provider_scope_application_key = application_id),
    CONSTRAINT fk_sand_iam_identity_provider_application_provider FOREIGN KEY (identity_provider_id, organization_id, provider_scope_application_key) REFERENCES sand_iam_identity_provider(id, organization_id, scope_application_key) ON DELETE RESTRICT,
    CONSTRAINT fk_sand_iam_identity_provider_application_application FOREIGN KEY (application_id, organization_id) REFERENCES sand_iam_application(id, organization_id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS idx_sand_iam_identity_provider_application_application ON sand_iam_identity_provider_application (application_id, status);
INSERT INTO sand_iam_identity_provider_application (identity_provider_id, application_id, organization_id, provider_scope_application_key, status)
SELECT id, application_id, organization_id, scope_application_key, status FROM sand_iam_identity_provider WHERE application_id IS NOT NULL
ON CONFLICT (identity_provider_id, application_id) DO NOTHING;

ALTER TABLE sand_iam_identity_binding
    DROP CONSTRAINT IF EXISTS fk_sand_iam_identity_binding_provider_application,
    DROP CONSTRAINT IF EXISTS uk_sand_iam_identity_binding_provider_subject,
    DROP CONSTRAINT IF EXISTS uk_sand_iam_identity_binding_provider_application_subject;
ALTER TABLE sand_iam_identity_binding
    ADD CONSTRAINT fk_sand_iam_identity_binding_provider_application FOREIGN KEY (identity_provider_id, application_id) REFERENCES sand_iam_identity_provider_application(identity_provider_id, application_id) ON DELETE RESTRICT,
    ADD CONSTRAINT uk_sand_iam_identity_binding_provider_application_subject UNIQUE (identity_provider_id, application_id, subject);

CREATE TABLE IF NOT EXISTS sand_iam_federation_transaction (
    id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    application_id bigint NOT NULL,
    identity_provider_id bigint NOT NULL,
    protocol varchar(16) NOT NULL CHECK (protocol IN ('oidc', 'saml')),
    purpose varchar(16) NOT NULL DEFAULT 'login' CHECK (purpose IN ('login', 'link')),
    state_hash char(64) NOT NULL,
    browser_binding_hash char(64) NULL,
    saml_request_id varchar(191) NULL,
    nonce_hash char(64) NULL,
    assertion_hash char(64) NULL,
    encrypted_pkce_verifier text NULL,
    redirect_uri varchar(2048) NULL,
    expire_time timestamp(0) without time zone NOT NULL,
    consumed_time timestamp(0) without time zone NULL,
    status smallint NOT NULL DEFAULT 1 CHECK (status IN (1, 2)),
    create_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uk_sand_iam_federation_transaction_state UNIQUE (state_hash),
    CONSTRAINT fk_sand_iam_federation_transaction_provider_application FOREIGN KEY (identity_provider_id, application_id) REFERENCES sand_iam_identity_provider_application(identity_provider_id, application_id) ON DELETE RESTRICT
);
ALTER TABLE sand_iam_federation_transaction ADD COLUMN IF NOT EXISTS assertion_hash char(64) NULL;
ALTER TABLE sand_iam_federation_transaction ADD COLUMN IF NOT EXISTS purpose varchar(16) NOT NULL DEFAULT 'login';
ALTER TABLE sand_iam_federation_transaction ADD COLUMN IF NOT EXISTS browser_binding_hash char(64) NULL;
ALTER TABLE sand_iam_federation_transaction ADD COLUMN IF NOT EXISTS saml_request_id varchar(191) NULL;
CREATE UNIQUE INDEX IF NOT EXISTS uk_sand_iam_federation_transaction_assertion ON sand_iam_federation_transaction (identity_provider_id, application_id, assertion_hash) WHERE assertion_hash IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_sand_iam_federation_transaction_provider_expire ON sand_iam_federation_transaction (identity_provider_id, expire_time);

ALTER TABLE sand_iam_auth_session
    ADD COLUMN IF NOT EXISTS auth_method varchar(32) NOT NULL DEFAULT 'local_password',
    ADD COLUMN IF NOT EXISTS identity_binding_id bigint NULL;
ALTER TABLE sand_iam_auth_session DROP CONSTRAINT IF EXISTS ck_sand_iam_auth_session_auth_method;
ALTER TABLE sand_iam_auth_session ADD CONSTRAINT ck_sand_iam_auth_session_auth_method CHECK (auth_method IN ('local_password', 'federation'));
DO $$ BEGIN ALTER TABLE sand_iam_auth_session ADD CONSTRAINT fk_sand_iam_auth_session_identity_binding FOREIGN KEY (identity_binding_id) REFERENCES sand_iam_identity_binding(id) ON DELETE RESTRICT; EXCEPTION WHEN duplicate_object THEN NULL; END $$;
CREATE INDEX IF NOT EXISTS idx_sand_iam_auth_session_binding_active ON sand_iam_auth_session (identity_binding_id, status);

CREATE TABLE IF NOT EXISTS sand_iam_directory_sync_run (
    id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    application_id bigint NOT NULL,
    identity_provider_id bigint NOT NULL,
    state varchar(16) NOT NULL CHECK (state IN ('running', 'succeeded', 'failed', 'partial')),
    cursor_before varchar(512) NULL,
    cursor_after varchar(512) NULL,
    processed_count integer NOT NULL DEFAULT 0 CHECK (processed_count >= 0),
    failed_count integer NOT NULL DEFAULT 0 CHECK (failed_count >= 0),
    error_code varchar(96) NULL,
    start_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    finish_time timestamp(0) without time zone NULL,
    CONSTRAINT fk_sand_iam_directory_sync_run_provider_application FOREIGN KEY (identity_provider_id, application_id) REFERENCES sand_iam_identity_provider_application(identity_provider_id, application_id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS idx_sand_iam_directory_sync_run_provider_start ON sand_iam_directory_sync_run (identity_provider_id, start_time DESC);

CREATE TABLE IF NOT EXISTS sand_iam_scim_token (
    id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    application_id bigint NOT NULL,
    identity_provider_id bigint NOT NULL,
    name varchar(128) NOT NULL,
    token_hash char(64) NOT NULL,
    status smallint NOT NULL DEFAULT 1 CHECK (status IN (1, 2)),
    expire_time timestamp(0) without time zone NULL,
    last_used_time timestamp(0) without time zone NULL,
    created_by bigint NULL,
    updated_by bigint NULL,
    create_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    delete_time timestamp(0) without time zone NULL,
    CONSTRAINT uk_sand_iam_scim_token_hash UNIQUE (token_hash),
    CONSTRAINT uk_sand_iam_scim_token_provider_name UNIQUE (identity_provider_id, name),
    CONSTRAINT fk_sand_iam_scim_token_provider_application FOREIGN KEY (identity_provider_id, application_id) REFERENCES sand_iam_identity_provider_application(identity_provider_id, application_id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS idx_sand_iam_scim_token_provider_status ON sand_iam_scim_token (identity_provider_id, status);

CREATE TABLE IF NOT EXISTS sand_iam_scim_group (
    id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    application_id bigint NOT NULL,
    identity_provider_id bigint NOT NULL,
    external_id varchar(191) NOT NULL,
    display_name varchar(256) NOT NULL,
    status smallint NOT NULL DEFAULT 1 CHECK (status IN (1, 2)),
    create_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uk_sand_iam_scim_group_provider_external UNIQUE (identity_provider_id, application_id, external_id),
    CONSTRAINT uk_sand_iam_scim_group_id_application UNIQUE (id, application_id),
    CONSTRAINT fk_sand_iam_scim_group_provider_application FOREIGN KEY (identity_provider_id, application_id) REFERENCES sand_iam_identity_provider_application(identity_provider_id, application_id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS idx_sand_iam_scim_group_application_id ON sand_iam_scim_group (application_id);
ALTER TABLE sand_iam_scim_group
    ADD COLUMN IF NOT EXISTS scim_id varchar(64) NULL,
    ADD COLUMN IF NOT EXISTS version bigint NOT NULL DEFAULT 1,
    ADD COLUMN IF NOT EXISTS source_state varchar(16) NOT NULL DEFAULT 'active',
    ADD COLUMN IF NOT EXISTS source_attributes jsonb NOT NULL DEFAULT '{}'::jsonb;
UPDATE sand_iam_scim_group SET scim_id = 'sg_' || md5(id::text || clock_timestamp()::text) WHERE scim_id IS NULL;
ALTER TABLE sand_iam_scim_group ALTER COLUMN scim_id SET NOT NULL;
DO $$ BEGIN ALTER TABLE sand_iam_scim_group ADD CONSTRAINT uk_sand_iam_scim_group_scim_id UNIQUE (scim_id); EXCEPTION WHEN duplicate_object OR duplicate_table THEN NULL; END $$;
ALTER TABLE sand_iam_scim_group DROP CONSTRAINT IF EXISTS ck_sand_iam_scim_group_source_state;
ALTER TABLE sand_iam_scim_group ADD CONSTRAINT ck_sand_iam_scim_group_source_state CHECK (source_state IN ('active', 'disabled', 'deleted'));

CREATE TABLE IF NOT EXISTS sand_iam_scim_group_member (
    id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    application_id bigint NOT NULL,
    group_id bigint NOT NULL,
    identity_id bigint NOT NULL,
    create_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uk_sand_iam_scim_group_member UNIQUE (group_id, identity_id),
    CONSTRAINT fk_sand_iam_scim_group_member_group_application FOREIGN KEY (group_id, application_id) REFERENCES sand_iam_scim_group(id, application_id) ON DELETE RESTRICT,
    CONSTRAINT fk_sand_iam_scim_group_member_identity_application FOREIGN KEY (identity_id, application_id) REFERENCES sand_iam_identity(id, application_id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS idx_sand_iam_scim_group_member_identity_id ON sand_iam_scim_group_member (identity_id);

CREATE TABLE IF NOT EXISTS sand_iam_scim_resource (
    id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    application_id bigint NOT NULL,
    identity_provider_id bigint NOT NULL,
    identity_id bigint NOT NULL,
    external_id varchar(191) NOT NULL,
    scim_id varchar(64) NOT NULL,
    version bigint NOT NULL DEFAULT 1 CHECK (version > 0),
    source_state varchar(16) NOT NULL DEFAULT 'active' CHECK (source_state IN ('active', 'disabled', 'deleted')),
    source_attributes jsonb NOT NULL DEFAULT '{}'::jsonb,
    create_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uk_sand_iam_scim_resource_provider_external UNIQUE (identity_provider_id, application_id, external_id),
    CONSTRAINT uk_sand_iam_scim_resource_scim_id UNIQUE (scim_id),
    CONSTRAINT uk_sand_iam_scim_resource_identity UNIQUE (identity_provider_id, application_id, identity_id),
    CONSTRAINT fk_sand_iam_scim_resource_provider_application FOREIGN KEY (identity_provider_id, application_id) REFERENCES sand_iam_identity_provider_application(identity_provider_id, application_id) ON DELETE RESTRICT,
    CONSTRAINT fk_sand_iam_scim_resource_identity_application FOREIGN KEY (identity_id, application_id) REFERENCES sand_iam_identity(id, application_id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS idx_sand_iam_scim_resource_application_state ON sand_iam_scim_resource (application_id, source_state);

CREATE TABLE IF NOT EXISTS sand_iam_provisioning_event (
    id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    application_id bigint NOT NULL,
    identity_provider_id bigint NOT NULL,
    scim_resource_id bigint NULL,
    event_type varchar(64) NOT NULL,
    outcome varchar(16) NOT NULL CHECK (outcome IN ('succeeded', 'failed', 'denied')),
    request_id varchar(96) NOT NULL,
    create_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_sand_iam_provisioning_event_provider_application FOREIGN KEY (identity_provider_id, application_id) REFERENCES sand_iam_identity_provider_application(identity_provider_id, application_id) ON DELETE RESTRICT,
    CONSTRAINT fk_sand_iam_provisioning_event_resource FOREIGN KEY (scim_resource_id) REFERENCES sand_iam_scim_resource(id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS idx_sand_iam_provisioning_event_provider_create ON sand_iam_provisioning_event (identity_provider_id, create_time DESC);

WITH permission_def("name","slug","sort") AS (
    VALUES
        ('创建联合身份源','sand_iam:federation:create',100),
        ('配置联合身份源','sand_iam:federation:configure',99),
        ('挂载联合身份源','sand_iam:federation:mount',98),
        ('同步企业目录','sand_iam:federation:sync',97),
        ('签发SCIM令牌','sand_iam:scim:token_issue',96)
)
INSERT INTO sand_system_menu (parent_id, name, code, slug, type, path, component, icon, sort, status, create_time, update_time)
SELECT parent.id, permission_def.name, '', permission_def.slug, 3, '', '', '', permission_def.sort, 1, NOW(), NOW()
FROM permission_def
JOIN sand_system_menu parent ON parent.code = 'SandIAMIdentityProvider'
WHERE NOT EXISTS (SELECT 1 FROM sand_system_menu existing WHERE existing.slug = permission_def.slug);

-- IAM-T04-006 END

-- lifecycle source: migrations/006_federation_integrity.pgsql
-- SandIAM v0.6.0 federation integrity additions.
-- Kept separate so existing 006 deployments receive the same idempotent
-- security constraints without renumbering later planned migrations.

BEGIN;

CREATE UNIQUE INDEX IF NOT EXISTS uq_sand_iam_identity_binding_id_app_identity
    ON sand_iam_identity_binding(id, application_id, identity_id);

ALTER TABLE sand_iam_identity_binding ADD COLUMN IF NOT EXISTS source_state varchar(16) NOT NULL DEFAULT 'active';
ALTER TABLE sand_iam_identity_binding ADD COLUMN IF NOT EXISTS source_updated_time timestamp NULL;
ALTER TABLE sand_iam_identity_binding ADD COLUMN IF NOT EXISTS missing_since timestamp NULL;
ALTER TABLE sand_iam_identity_binding DROP CONSTRAINT IF EXISTS ck_sand_iam_identity_binding_source_state;
ALTER TABLE sand_iam_identity_binding ADD CONSTRAINT ck_sand_iam_identity_binding_source_state CHECK (source_state IN ('active', 'disabled', 'deleted'));

ALTER TABLE sand_iam_identity_provider ADD COLUMN IF NOT EXISTS config_version bigint NOT NULL DEFAULT 1;
ALTER TABLE sand_iam_federation_transaction ADD COLUMN IF NOT EXISTS provider_config_version bigint NOT NULL DEFAULT 1;
ALTER TABLE sand_iam_directory_sync_run ADD COLUMN IF NOT EXISTS provider_config_version bigint NOT NULL DEFAULT 1;
ALTER TABLE sand_iam_directory_sync_run ADD COLUMN IF NOT EXISTS observed_count integer NULL;

ALTER TABLE sand_iam_auth_session
    DROP CONSTRAINT IF EXISTS ck_sand_iam_auth_session_federation_method;
ALTER TABLE sand_iam_auth_session
    ADD CONSTRAINT ck_sand_iam_auth_session_federation_method CHECK (
        (auth_method = 'local_password' AND identity_binding_id IS NULL)
        OR (auth_method = 'federation' AND identity_binding_id IS NOT NULL)
    );
ALTER TABLE sand_iam_auth_session
    DROP CONSTRAINT IF EXISTS fk_sand_iam_auth_session_federation_binding;
ALTER TABLE sand_iam_auth_session
    ADD CONSTRAINT fk_sand_iam_auth_session_federation_binding
    FOREIGN KEY (identity_binding_id, application_id, identity_id)
    REFERENCES sand_iam_identity_binding(id, application_id, identity_id);

CREATE UNIQUE INDEX IF NOT EXISTS uq_sand_iam_federation_assertion_replay
    ON sand_iam_federation_transaction(identity_provider_id, assertion_hash)
    WHERE assertion_hash IS NOT NULL;

DO $$ DECLARE row record; BEGIN FOR row IN SELECT conname FROM pg_constraint WHERE conrelid = 'sand_iam_identity_provider'::regclass AND contype = 'c' AND pg_get_constraintdef(oid) LIKE '%provider_type%' LOOP EXECUTE format('ALTER TABLE sand_iam_identity_provider DROP CONSTRAINT %I', row.conname); END LOOP; ALTER TABLE sand_iam_identity_provider ADD CONSTRAINT ck_sand_iam_identity_provider_type CHECK (provider_type IN ('local', 'oidc', 'oauth2', 'saml', 'ldap', 'scim', 'kerberos')); EXCEPTION WHEN duplicate_object THEN NULL; END $$;

COMMIT;

-- lifecycle source: migrations/007_federation_handoff.pgsql
-- IAM-T04 browser handoff.  Plaintext codes never reach durable storage.

ALTER TABLE sand_iam_federation_transaction
    ADD COLUMN IF NOT EXISTS handoff_return_uri varchar(2048),
    ADD COLUMN IF NOT EXISTS handoff_state varchar(2048),
    ADD COLUMN IF NOT EXISTS handoff_code_challenge varchar(64),
    ADD COLUMN IF NOT EXISTS link_identity_id bigint NULL,
    ADD COLUMN IF NOT EXISTS link_session_id bigint NULL;

ALTER TABLE sand_iam_auth_session
    ADD COLUMN IF NOT EXISTS step_up_time timestamp(0) without time zone NULL,
    ADD COLUMN IF NOT EXISTS step_up_method varchar(16) NULL;

CREATE TABLE IF NOT EXISTS sand_iam_federation_handoff (
    id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    organization_id bigint NOT NULL,
    application_id bigint NOT NULL,
    identity_provider_id bigint NOT NULL,
    identity_binding_id bigint NOT NULL,
    provider_config_version bigint NOT NULL,
    code_hash char(64) NOT NULL,
    return_uri varchar(2048) NOT NULL,
    code_challenge varchar(64) NOT NULL,
    expire_time timestamp(0) without time zone NOT NULL,
    consumed_time timestamp(0) without time zone NULL,
    status smallint NOT NULL DEFAULT 1,
    create_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp(0) without time zone NULL,
    CONSTRAINT uk_sand_iam_federation_handoff_code_hash UNIQUE (code_hash),
    CONSTRAINT ck_sand_iam_federation_handoff_status CHECK (status IN (1, 2)),
    CONSTRAINT fk_sand_iam_federation_handoff_application FOREIGN KEY (application_id) REFERENCES sand_iam_application(id),
    CONSTRAINT fk_sand_iam_federation_handoff_provider FOREIGN KEY (identity_provider_id) REFERENCES sand_iam_identity_provider(id),
    CONSTRAINT fk_sand_iam_federation_handoff_binding FOREIGN KEY (identity_binding_id) REFERENCES sand_iam_identity_binding(id)
);

CREATE INDEX IF NOT EXISTS idx_sand_iam_federation_handoff_expire ON sand_iam_federation_handoff (expire_time);
CREATE INDEX IF NOT EXISTS idx_sand_iam_federation_handoff_binding ON sand_iam_federation_handoff (identity_binding_id, status);

-- lifecycle source: migrations/008_api_governance.pgsql
CREATE UNIQUE INDEX IF NOT EXISTS uk_sand_iam_resource_id_application
    ON sand_iam_resource (id, application_id);

CREATE TABLE IF NOT EXISTS sand_iam_api_resource (
    id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    application_id bigint NOT NULL,
    resource_id bigint NOT NULL,
    code varchar(96) NOT NULL,
    name varchar(128) NOT NULL,
    action varchar(96) NOT NULL,
    operation varchar(16) NOT NULL,
    api_version varchar(32) NOT NULL DEFAULT 'v1',
    audience varchar(128) NOT NULL,
    required_scope varchar(96) NULL,
    risk_level varchar(16) NOT NULL DEFAULT 'medium',
    description varchar(500) NULL,
    status smallint NOT NULL DEFAULT 1,
    created_by bigint NULL,
    updated_by bigint NULL,
    create_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    delete_time timestamp(0) without time zone NULL,
    CONSTRAINT fk_sand_iam_api_resource_application
        FOREIGN KEY (application_id) REFERENCES sand_iam_application(id) ON DELETE RESTRICT,
    CONSTRAINT fk_sand_iam_api_resource_resource
        FOREIGN KEY (resource_id, application_id) REFERENCES sand_iam_resource(id, application_id) ON DELETE RESTRICT,
    CONSTRAINT ck_sand_iam_api_resource_operation
        CHECK (operation IN ('list', 'read', 'create', 'update', 'delete', 'export', 'batch')),
    CONSTRAINT ck_sand_iam_api_resource_risk
        CHECK (risk_level IN ('low', 'medium', 'high', 'critical')),
    CONSTRAINT ck_sand_iam_api_resource_status
        CHECK (status IN (1, 2)),
    CONSTRAINT uk_sand_iam_api_resource_code_version
        UNIQUE (application_id, code, api_version),
    CONSTRAINT uk_sand_iam_api_resource_id_application
        UNIQUE (id, application_id)
);

CREATE INDEX IF NOT EXISTS idx_sand_iam_api_resource_resource
    ON sand_iam_api_resource (application_id, resource_id, status);

CREATE TABLE IF NOT EXISTS sand_iam_api_route_binding (
    id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    application_id bigint NOT NULL,
    api_resource_id bigint NOT NULL,
    http_method varchar(8) NOT NULL,
    route_template varchar(255) NOT NULL,
    route_fingerprint char(64) NOT NULL,
    source varchar(16) NOT NULL DEFAULT 'manual',
    last_seen_time timestamp(0) without time zone NULL,
    status smallint NOT NULL DEFAULT 1,
    created_by bigint NULL,
    updated_by bigint NULL,
    create_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    delete_time timestamp(0) without time zone NULL,
    CONSTRAINT fk_sand_iam_api_route_application
        FOREIGN KEY (application_id) REFERENCES sand_iam_application(id) ON DELETE RESTRICT,
    CONSTRAINT fk_sand_iam_api_route_resource
        FOREIGN KEY (api_resource_id, application_id) REFERENCES sand_iam_api_resource(id, application_id) ON DELETE RESTRICT,
    CONSTRAINT ck_sand_iam_api_route_method
        CHECK (http_method IN ('GET', 'POST', 'PUT', 'PATCH', 'DELETE')),
    CONSTRAINT ck_sand_iam_api_route_source
        CHECK (source IN ('manual', 'openapi', 'route_scan')),
    CONSTRAINT ck_sand_iam_api_route_status
        CHECK (status IN (1, 2)),
    CONSTRAINT uk_sand_iam_api_route_method_template
        UNIQUE (application_id, http_method, route_template)
);

CREATE INDEX IF NOT EXISTS idx_sand_iam_api_route_resource
    ON sand_iam_api_route_binding (application_id, api_resource_id, status);

-- lifecycle source: migrations/009_admin_application_grant.pgsql
CREATE TABLE IF NOT EXISTS sand_iam_admin_application_grant (
    id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    admin_user_id bigint NOT NULL,
    application_id bigint NOT NULL,
    status smallint NOT NULL DEFAULT 1,
    created_by bigint NULL,
    updated_by bigint NULL,
    create_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    delete_time timestamp(0) without time zone NULL,
    CONSTRAINT fk_sand_iam_admin_application_grant_application
        FOREIGN KEY (application_id) REFERENCES sand_iam_application(id) ON DELETE RESTRICT,
    CONSTRAINT ck_sand_iam_admin_application_grant_status
        CHECK (status IN (1, 2)),
    CONSTRAINT uk_sand_iam_admin_application_grant_admin_app
        UNIQUE (admin_user_id, application_id)
);

CREATE INDEX IF NOT EXISTS idx_sand_iam_admin_application_grant_app
    ON sand_iam_admin_application_grant (application_id, status);

-- lifecycle source: migrations/010_webhook_delivery.pgsql
CREATE TABLE IF NOT EXISTS sand_iam_webhook_endpoint (
    id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    application_id bigint NOT NULL,
    code varchar(64) NOT NULL,
    name varchar(128) NOT NULL,
    url varchar(500) NOT NULL,
    encrypted_secret text NOT NULL,
    secret_version integer NOT NULL DEFAULT 1,
    event_types jsonb NOT NULL DEFAULT '[]'::jsonb,
    timeout_seconds smallint NOT NULL DEFAULT 10,
    max_attempts smallint NOT NULL DEFAULT 5,
    status smallint NOT NULL DEFAULT 1,
    disabled_time timestamp(0) without time zone NULL,
    created_by bigint NULL,
    updated_by bigint NULL,
    create_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    delete_time timestamp(0) without time zone NULL,
    CONSTRAINT fk_sand_iam_webhook_endpoint_application
        FOREIGN KEY (application_id) REFERENCES sand_iam_application(id) ON DELETE RESTRICT,
    CONSTRAINT ck_sand_iam_webhook_endpoint_event_types
        CHECK (jsonb_typeof(event_types) = 'array'),
    CONSTRAINT ck_sand_iam_webhook_endpoint_timeout
        CHECK (timeout_seconds BETWEEN 1 AND 30),
    CONSTRAINT ck_sand_iam_webhook_endpoint_attempts
        CHECK (max_attempts BETWEEN 1 AND 10),
    CONSTRAINT ck_sand_iam_webhook_endpoint_status
        CHECK (status IN (1, 2)),
    CONSTRAINT uk_sand_iam_webhook_endpoint_app_code
        UNIQUE (application_id, code),
    CONSTRAINT uk_sand_iam_webhook_endpoint_id_application
        UNIQUE (id, application_id)
);

CREATE INDEX IF NOT EXISTS idx_sand_iam_webhook_endpoint_app_status
    ON sand_iam_webhook_endpoint (application_id, status);

CREATE TABLE IF NOT EXISTS sand_iam_webhook_delivery (
    id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    application_id bigint NOT NULL,
    webhook_endpoint_id bigint NOT NULL,
    event_id varchar(96) NOT NULL,
    event_type varchar(96) NOT NULL,
    payload jsonb NOT NULL,
    status smallint NOT NULL DEFAULT 1,
    attempt_count smallint NOT NULL DEFAULT 0,
    next_attempt_time timestamp(0) without time zone NULL,
    locked_until timestamp(0) without time zone NULL,
    delivered_time timestamp(0) without time zone NULL,
    response_status smallint NULL,
    response_digest char(64) NULL,
    last_error_code varchar(96) NULL,
    created_by bigint NULL,
    updated_by bigint NULL,
    create_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    delete_time timestamp(0) without time zone NULL,
    CONSTRAINT fk_sand_iam_webhook_delivery_endpoint
        FOREIGN KEY (webhook_endpoint_id, application_id) REFERENCES sand_iam_webhook_endpoint(id, application_id) ON DELETE RESTRICT,
    CONSTRAINT ck_sand_iam_webhook_delivery_payload
        CHECK (jsonb_typeof(payload) = 'object'),
    CONSTRAINT ck_sand_iam_webhook_delivery_status
        CHECK (status IN (1, 2, 3, 4)),
    CONSTRAINT ck_sand_iam_webhook_delivery_attempts
        CHECK (attempt_count BETWEEN 0 AND 10),
    CONSTRAINT uk_sand_iam_webhook_delivery_event
        UNIQUE (webhook_endpoint_id, event_id)
);

CREATE INDEX IF NOT EXISTS idx_sand_iam_webhook_delivery_pending
    ON sand_iam_webhook_delivery (status, next_attempt_time, id);

CREATE INDEX IF NOT EXISTS idx_sand_iam_webhook_delivery_application
    ON sand_iam_webhook_delivery (application_id, event_type, create_time DESC);

-- lifecycle source: migrations/011_application_experience_message_provider.pgsql
-- SandIAM T09: application login experience and organization-owned message providers.
-- PostgreSQL only. This file is not active until root lifecycle SQL is explicitly updated.

ALTER TABLE sand_iam_auth_policy
    ADD COLUMN IF NOT EXISTS require_captcha SMALLINT NOT NULL DEFAULT 2
        CHECK (require_captcha IN (1, 2));

CREATE TABLE IF NOT EXISTS sand_iam_application_experience (
    id BIGSERIAL PRIMARY KEY,
    application_id BIGINT NOT NULL REFERENCES sand_iam_application(id) ON DELETE RESTRICT,
    brand_name VARCHAR(128) NOT NULL,
    logo_url VARCHAR(2048),
    primary_color VARCHAR(7) NOT NULL DEFAULT '#1677ff',
    theme_mode VARCHAR(16) NOT NULL DEFAULT 'system' CHECK (theme_mode IN ('light', 'dark', 'system')),
    default_locale VARCHAR(16) NOT NULL DEFAULT 'zh-CN',
    terms_url VARCHAR(2048),
    privacy_url VARCHAR(2048),
    registration_mode VARCHAR(16) NOT NULL DEFAULT 'disabled' CHECK (registration_mode IN ('open', 'invite', 'disabled')),
    login_methods JSONB NOT NULL DEFAULT '["password"]'::jsonb CHECK (jsonb_typeof(login_methods) = 'array'),
    registration_fields JSONB NOT NULL DEFAULT '["username","display_name","email"]'::jsonb CHECK (jsonb_typeof(registration_fields) = 'array'),
    status SMALLINT NOT NULL DEFAULT 1 CHECK (status IN (1, 2)),
    create_time TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uk_sand_iam_application_experience_application UNIQUE (application_id)
);

CREATE INDEX IF NOT EXISTS idx_sand_iam_application_experience_status
    ON sand_iam_application_experience(status);

CREATE TABLE IF NOT EXISTS sand_iam_message_provider (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL REFERENCES sand_iam_organization(id) ON DELETE RESTRICT,
    code VARCHAR(64) NOT NULL,
    name VARCHAR(128) NOT NULL,
    provider_type VARCHAR(24) NOT NULL CHECK (provider_type IN ('email', 'sms', 'captcha', 'notification')),
    driver_code VARCHAR(64) NOT NULL,
    encrypted_config TEXT,
    config_version INTEGER NOT NULL DEFAULT 0 CHECK (config_version >= 0),
    status SMALLINT NOT NULL DEFAULT 1 CHECK (status IN (1, 2)),
    create_time TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uk_sand_iam_message_provider_org_code UNIQUE (organization_id, code)
);

CREATE INDEX IF NOT EXISTS idx_sand_iam_message_provider_org_type_status
    ON sand_iam_message_provider(organization_id, provider_type, status);

CREATE TABLE IF NOT EXISTS sand_iam_message_provider_application (
    id BIGSERIAL PRIMARY KEY,
    message_provider_id BIGINT NOT NULL REFERENCES sand_iam_message_provider(id) ON DELETE RESTRICT,
    application_id BIGINT NOT NULL REFERENCES sand_iam_application(id) ON DELETE RESTRICT,
    organization_id BIGINT NOT NULL REFERENCES sand_iam_organization(id) ON DELETE RESTRICT,
    purposes JSONB NOT NULL DEFAULT '[]'::jsonb CHECK (jsonb_typeof(purposes) = 'array'),
    template_codes JSONB NOT NULL DEFAULT '{}'::jsonb CHECK (jsonb_typeof(template_codes) = 'object'),
    priority INTEGER NOT NULL DEFAULT 100 CHECK (priority BETWEEN 1 AND 1000),
    status SMALLINT NOT NULL DEFAULT 1 CHECK (status IN (1, 2)),
    create_time TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uk_sand_iam_message_provider_application UNIQUE (message_provider_id, application_id)
);

CREATE INDEX IF NOT EXISTS idx_sand_iam_message_mount_application_status_priority
    ON sand_iam_message_provider_application(application_id, status, priority, id);

-- lifecycle source: migrations/012_identity_lifecycle_group.pgsql
-- SandIAM T10 phase 1: identity lifecycle and application-local groups.
-- PostgreSQL only; integrated into the generated root lifecycle.

ALTER TABLE sand_iam_identity
    ADD COLUMN IF NOT EXISTS lifecycle_state VARCHAR(16) NOT NULL DEFAULT 'active',
    ADD COLUMN IF NOT EXISTS state_before_delete VARCHAR(16),
    ADD COLUMN IF NOT EXISTS deleted_time TIMESTAMP WITHOUT TIME ZONE,
    ADD COLUMN IF NOT EXISTS purge_after TIMESTAMP WITHOUT TIME ZONE,
    ADD COLUMN IF NOT EXISTS external_guest_ref_hash CHAR(64);

UPDATE sand_iam_identity
SET lifecycle_state = CASE WHEN status = 1 THEN 'active' ELSE 'disabled' END
WHERE lifecycle_state = 'active' AND status <> 1;

DO $$ BEGIN IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'ck_sand_iam_identity_lifecycle_state') THEN ALTER TABLE sand_iam_identity ADD CONSTRAINT ck_sand_iam_identity_lifecycle_state CHECK (lifecycle_state IN ('pending', 'active', 'disabled', 'guest', 'deleted')); END IF; IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'ck_sand_iam_identity_state_before_delete') THEN ALTER TABLE sand_iam_identity ADD CONSTRAINT ck_sand_iam_identity_state_before_delete CHECK (state_before_delete IS NULL OR state_before_delete IN ('pending', 'active', 'disabled', 'guest')); END IF; IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'uk_sand_iam_identity_id_application') THEN ALTER TABLE sand_iam_identity ADD CONSTRAINT uk_sand_iam_identity_id_application UNIQUE (id, application_id); END IF; END $$;

CREATE UNIQUE INDEX IF NOT EXISTS uk_sand_iam_identity_guest_application
    ON sand_iam_identity(application_id, external_guest_ref_hash)
    WHERE external_guest_ref_hash IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_sand_iam_identity_application_lifecycle
    ON sand_iam_identity(application_id, lifecycle_state, status);
CREATE INDEX IF NOT EXISTS idx_sand_iam_identity_purge_after
    ON sand_iam_identity(purge_after)
    WHERE lifecycle_state = 'deleted';

CREATE TABLE IF NOT EXISTS sand_iam_identity_group (
    id BIGSERIAL PRIMARY KEY,
    application_id BIGINT NOT NULL REFERENCES sand_iam_application(id) ON DELETE RESTRICT,
    parent_id BIGINT,
    code VARCHAR(64) NOT NULL,
    name VARCHAR(128) NOT NULL,
    description VARCHAR(500),
    depth SMALLINT NOT NULL DEFAULT 1 CHECK (depth BETWEEN 1 AND 8),
    status SMALLINT NOT NULL DEFAULT 1 CHECK (status IN (1, 2)),
    create_time TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uk_sand_iam_identity_group_app_code UNIQUE (application_id, code),
    CONSTRAINT uk_sand_iam_identity_group_id_app UNIQUE (id, application_id),
    CONSTRAINT fk_sand_iam_identity_group_parent_app FOREIGN KEY (parent_id, application_id)
        REFERENCES sand_iam_identity_group(id, application_id) ON DELETE RESTRICT
);

CREATE INDEX IF NOT EXISTS idx_sand_iam_identity_group_parent
    ON sand_iam_identity_group(application_id, parent_id, status);

CREATE TABLE IF NOT EXISTS sand_iam_identity_group_member (
    id BIGSERIAL PRIMARY KEY,
    identity_group_id BIGINT NOT NULL,
    application_id BIGINT NOT NULL,
    identity_id BIGINT NOT NULL,
    status SMALLINT NOT NULL DEFAULT 1 CHECK (status IN (1, 2)),
    create_time TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uk_sand_iam_identity_group_member UNIQUE (identity_group_id, identity_id),
    CONSTRAINT fk_sand_iam_group_member_group_app FOREIGN KEY (identity_group_id, application_id)
        REFERENCES sand_iam_identity_group(id, application_id) ON DELETE RESTRICT,
    CONSTRAINT fk_sand_iam_group_member_identity_app FOREIGN KEY (identity_id, application_id)
        REFERENCES sand_iam_identity(id, application_id) ON DELETE RESTRICT
);

CREATE INDEX IF NOT EXISTS idx_sand_iam_identity_group_member_identity
    ON sand_iam_identity_group_member(application_id, identity_id, status);

INSERT INTO sand_iam_service (code, name, status)
VALUES ('sand-iam', 'SandIAM 身份服务', 1)
ON CONFLICT (code) DO UPDATE SET name = EXCLUDED.name;

INSERT INTO sand_iam_service_action (service_id, code, name, status)
SELECT id, 'identity.guest.upsert', '创建或更新应用访客', 1
FROM sand_iam_service WHERE code = 'sand-iam'
ON CONFLICT (service_id, code) DO UPDATE SET name = EXCLUDED.name;

-- lifecycle source: migrations/013_identity_invitation.pgsql
-- SandIAM T10 phase 2: application invitation lifecycle.
-- PostgreSQL only; integrated into the generated root lifecycle.

CREATE TABLE IF NOT EXISTS sand_iam_identity_invitation (
    id BIGSERIAL PRIMARY KEY,
    application_id BIGINT NOT NULL REFERENCES sand_iam_application(id) ON DELETE RESTRICT,
    target_type VARCHAR(16) NOT NULL CHECK (target_type IN ('email', 'phone')),
    target_hash CHAR(64) NOT NULL,
    target_masked VARCHAR(320) NOT NULL,
    encrypted_target TEXT,
    token_hash CHAR(64) NOT NULL,
    encrypted_delivery_token TEXT,
    initial_group_ids JSONB NOT NULL DEFAULT '[]'::jsonb CHECK (jsonb_typeof(initial_group_ids) = 'array'),
    invited_by VARCHAR(64) NOT NULL,
    state VARCHAR(24) NOT NULL CHECK (state IN ('sending', 'pending', 'delivery_failed', 'accepted', 'revoked', 'expired')),
    identity_id BIGINT,
    guest_identity_id BIGINT,
    expire_time TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    delivered_time TIMESTAMP WITHOUT TIME ZONE,
    consumed_time TIMESTAMP WITHOUT TIME ZONE,
    delivery_error_code VARCHAR(128),
    status SMALLINT NOT NULL DEFAULT 1 CHECK (status IN (1, 2)),
    create_time TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uk_sand_iam_invitation_token_hash UNIQUE (token_hash),
    CONSTRAINT fk_sand_iam_invitation_identity_app FOREIGN KEY (identity_id, application_id)
        REFERENCES sand_iam_identity(id, application_id) ON DELETE RESTRICT,
    CONSTRAINT fk_sand_iam_invitation_guest_identity_app FOREIGN KEY (guest_identity_id, application_id)
        REFERENCES sand_iam_identity(id, application_id) ON DELETE RESTRICT
);

CREATE UNIQUE INDEX IF NOT EXISTS uk_sand_iam_invitation_active_target
    ON sand_iam_identity_invitation(application_id, target_hash)
    WHERE state IN ('sending', 'pending', 'delivery_failed');
CREATE UNIQUE INDEX IF NOT EXISTS uk_sand_iam_invitation_active_guest
    ON sand_iam_identity_invitation(application_id, guest_identity_id)
    WHERE guest_identity_id IS NOT NULL AND state IN ('sending', 'pending', 'delivery_failed');
CREATE INDEX IF NOT EXISTS idx_sand_iam_invitation_application_state
    ON sand_iam_identity_invitation(application_id, state, expire_time);

-- lifecycle source: migrations/014_identity_import_export.pgsql
-- SandIAM T10 phase 4: two-step identity CSV import and export reports.
-- PostgreSQL only; integrated into the generated root lifecycle.

CREATE TABLE IF NOT EXISTS sand_iam_identity_import_job (
    id BIGSERIAL PRIMARY KEY,
    application_id BIGINT NOT NULL REFERENCES sand_iam_application(id) ON DELETE RESTRICT,
    original_name VARCHAR(255) NOT NULL,
    content_digest CHAR(64) NOT NULL,
    mode VARCHAR(16) NOT NULL CHECK (mode IN ('create', 'update')),
    state VARCHAR(16) NOT NULL CHECK (state IN ('previewed', 'running', 'completed', 'partial', 'failed')),
    total_count INTEGER NOT NULL DEFAULT 0 CHECK (total_count >= 0),
    valid_count INTEGER NOT NULL DEFAULT 0 CHECK (valid_count >= 0),
    invalid_count INTEGER NOT NULL DEFAULT 0 CHECK (invalid_count >= 0),
    success_count INTEGER NOT NULL DEFAULT 0 CHECK (success_count >= 0),
    warning_count INTEGER NOT NULL DEFAULT 0 CHECK (warning_count >= 0),
    failure_count INTEGER NOT NULL DEFAULT 0 CHECK (failure_count >= 0),
    created_by VARCHAR(64) NOT NULL,
    confirmed_time TIMESTAMP WITHOUT TIME ZONE,
    completed_time TIMESTAMP WITHOUT TIME ZONE,
    status SMALLINT NOT NULL DEFAULT 1 CHECK (status IN (1, 2)),
    create_time TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_sand_iam_import_job_application_state
    ON sand_iam_identity_import_job(application_id, state, id DESC);

CREATE TABLE IF NOT EXISTS sand_iam_identity_import_row (
    id BIGSERIAL PRIMARY KEY,
    import_job_id BIGINT NOT NULL REFERENCES sand_iam_identity_import_job(id) ON DELETE RESTRICT,
    application_id BIGINT NOT NULL REFERENCES sand_iam_application(id) ON DELETE RESTRICT,
    row_number INTEGER NOT NULL CHECK (row_number >= 2),
    idempotency_key CHAR(64) NOT NULL,
    encrypted_payload TEXT,
    summary JSONB NOT NULL DEFAULT '{}'::jsonb CHECK (jsonb_typeof(summary) = 'object'),
    validation_errors JSONB NOT NULL DEFAULT '[]'::jsonb CHECK (jsonb_typeof(validation_errors) = 'array'),
    state VARCHAR(32) NOT NULL CHECK (state IN ('valid', 'invalid', 'processing', 'succeeded', 'succeeded_with_warning', 'failed')),
    result_identity_id BIGINT,
    result_invitation_id BIGINT,
    error_code VARCHAR(128),
    status SMALLINT NOT NULL DEFAULT 1 CHECK (status IN (1, 2)),
    create_time TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uk_sand_iam_import_row_job_number UNIQUE (import_job_id, row_number),
    CONSTRAINT uk_sand_iam_import_row_idempotency UNIQUE (idempotency_key),
    CONSTRAINT fk_sand_iam_import_row_identity_app FOREIGN KEY (result_identity_id, application_id)
        REFERENCES sand_iam_identity(id, application_id) ON DELETE RESTRICT,
    CONSTRAINT fk_sand_iam_import_row_invitation FOREIGN KEY (result_invitation_id)
        REFERENCES sand_iam_identity_invitation(id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS idx_sand_iam_import_row_job_state
    ON sand_iam_identity_import_row(import_job_id, state, row_number);

-- lifecycle source: migrations/015_identity_sync_connector.pgsql
-- SandIAM T10: application-scoped identity synchronization connector.
-- Candidate migration only. The root install/update/uninstall lifecycle scripts
-- remain the release source of truth and must be integrated and verified separately.

CREATE TABLE IF NOT EXISTS sand_iam_sync_connector (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    application_id BIGINT NOT NULL,
    code VARCHAR(64) NOT NULL,
    name VARCHAR(128) NOT NULL,
    direction VARCHAR(16) NOT NULL DEFAULT 'inbound',
    driver_code VARCHAR(64) NOT NULL,
    encrypted_config TEXT NULL,
    config_version INTEGER NOT NULL DEFAULT 0,
    authority_map JSONB NOT NULL DEFAULT '{}'::JSONB,
    conflict_policy VARCHAR(16) NOT NULL DEFAULT 'manual',
    encrypted_cursor TEXT NULL,
    missing_protection_hours INTEGER NOT NULL DEFAULT 24,
    disable_threshold_percent INTEGER NOT NULL DEFAULT 20,
    last_sync_time TIMESTAMP(0) WITHOUT TIME ZONE NULL,
    status SMALLINT NOT NULL DEFAULT 1,
    create_time TIMESTAMP(0) WITHOUT TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time TIMESTAMP(0) WITHOUT TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT ck_sand_iam_sync_connector_direction
        CHECK (direction IN ('inbound', 'outbound', 'bidirectional')),
    CONSTRAINT ck_sand_iam_sync_connector_conflict_policy
        CHECK (conflict_policy IN ('manual', 'reject', 'source_wins', 'local_wins')),
    CONSTRAINT ck_sand_iam_sync_connector_config_version
        CHECK (config_version >= 0),
    CONSTRAINT ck_sand_iam_sync_connector_missing_protection
        CHECK (missing_protection_hours BETWEEN 1 AND 720),
    CONSTRAINT ck_sand_iam_sync_connector_disable_threshold
        CHECK (disable_threshold_percent BETWEEN 1 AND 100),
    CONSTRAINT ck_sand_iam_sync_connector_status
        CHECK (status IN (1, 2)),
    CONSTRAINT uk_sand_iam_sync_connector_app_code
        UNIQUE (application_id, code),
    CONSTRAINT uk_sand_iam_sync_connector_id_app
        UNIQUE (id, application_id),
    CONSTRAINT fk_sand_iam_sync_connector_org
        FOREIGN KEY (organization_id) REFERENCES sand_iam_organization (id) ON DELETE RESTRICT,
    CONSTRAINT fk_sand_iam_sync_connector_app
        FOREIGN KEY (application_id) REFERENCES sand_iam_application (id) ON DELETE RESTRICT
);

CREATE INDEX IF NOT EXISTS idx_sand_iam_sync_connector_app_status
    ON sand_iam_sync_connector (application_id, status, id DESC);

CREATE TABLE IF NOT EXISTS sand_iam_sync_run (
    id BIGSERIAL PRIMARY KEY,
    sync_connector_id BIGINT NOT NULL,
    application_id BIGINT NOT NULL,
    connector_config_version INTEGER NOT NULL,
    state VARCHAR(16) NOT NULL DEFAULT 'running',
    cursor_before_hash CHAR(64) NULL,
    cursor_after_hash CHAR(64) NULL,
    pulled INTEGER NOT NULL DEFAULT 0,
    pushed INTEGER NOT NULL DEFAULT 0,
    created INTEGER NOT NULL DEFAULT 0,
    updated INTEGER NOT NULL DEFAULT 0,
    missing INTEGER NOT NULL DEFAULT 0,
    disabled INTEGER NOT NULL DEFAULT 0,
    conflict INTEGER NOT NULL DEFAULT 0,
    error_code VARCHAR(128) NULL,
    start_time TIMESTAMP(0) WITHOUT TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    finish_time TIMESTAMP(0) WITHOUT TIME ZONE NULL,
    status SMALLINT NOT NULL DEFAULT 1,
    create_time TIMESTAMP(0) WITHOUT TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time TIMESTAMP(0) WITHOUT TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT ck_sand_iam_sync_run_state
        CHECK (state IN ('running', 'succeeded', 'failed')),
    CONSTRAINT ck_sand_iam_sync_run_counts
        CHECK (pulled >= 0 AND pushed >= 0 AND created >= 0 AND updated >= 0
            AND missing >= 0 AND disabled >= 0 AND conflict >= 0),
    CONSTRAINT ck_sand_iam_sync_run_status
        CHECK (status IN (1, 2)),
    CONSTRAINT uk_sand_iam_sync_run_id_app
        UNIQUE (id, application_id),
    CONSTRAINT fk_sand_iam_sync_run_connector_app
        FOREIGN KEY (sync_connector_id, application_id)
        REFERENCES sand_iam_sync_connector (id, application_id) ON DELETE RESTRICT
);

CREATE UNIQUE INDEX IF NOT EXISTS uk_sand_iam_sync_run_running
    ON sand_iam_sync_run (sync_connector_id)
    WHERE state = 'running';
CREATE INDEX IF NOT EXISTS idx_sand_iam_sync_run_connector_time
    ON sand_iam_sync_run (sync_connector_id, id DESC);

CREATE TABLE IF NOT EXISTS sand_iam_sync_resource (
    id BIGSERIAL PRIMARY KEY,
    sync_connector_id BIGINT NOT NULL,
    application_id BIGINT NOT NULL,
    source_key_hash CHAR(64) NOT NULL,
    source_version VARCHAR(128) NOT NULL,
    identity_id BIGINT NOT NULL,
    encrypted_snapshot TEXT NOT NULL,
    snapshot_hash CHAR(64) NOT NULL,
    source_state VARCHAR(16) NOT NULL DEFAULT 'active',
    missing_since TIMESTAMP(0) WITHOUT TIME ZONE NULL,
    last_seen_run_id BIGINT NULL,
    status SMALLINT NOT NULL DEFAULT 1,
    create_time TIMESTAMP(0) WITHOUT TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time TIMESTAMP(0) WITHOUT TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT ck_sand_iam_sync_resource_state
        CHECK (source_state IN ('active', 'missing', 'disabled', 'conflict')),
    CONSTRAINT ck_sand_iam_sync_resource_status
        CHECK (status IN (1, 2)),
    CONSTRAINT uk_sand_iam_sync_resource_source
        UNIQUE (sync_connector_id, source_key_hash),
    CONSTRAINT fk_sand_iam_sync_resource_connector_app
        FOREIGN KEY (sync_connector_id, application_id)
        REFERENCES sand_iam_sync_connector (id, application_id) ON DELETE RESTRICT,
    CONSTRAINT fk_sand_iam_sync_resource_identity_app
        FOREIGN KEY (identity_id, application_id)
        REFERENCES sand_iam_identity (id, application_id) ON DELETE RESTRICT,
    CONSTRAINT fk_sand_iam_sync_resource_run_app
        FOREIGN KEY (last_seen_run_id, application_id)
        REFERENCES sand_iam_sync_run (id, application_id) ON DELETE RESTRICT
);

CREATE INDEX IF NOT EXISTS idx_sand_iam_sync_resource_missing
    ON sand_iam_sync_resource (sync_connector_id, missing_since)
    WHERE source_state = 'missing' AND status = 1;
CREATE INDEX IF NOT EXISTS idx_sand_iam_sync_resource_identity
    ON sand_iam_sync_resource (application_id, identity_id);

CREATE TABLE IF NOT EXISTS sand_iam_sync_outbox (
    id BIGSERIAL PRIMARY KEY,
    sync_connector_id BIGINT NOT NULL,
    application_id BIGINT NOT NULL,
    identity_id BIGINT NOT NULL,
    event_id VARCHAR(128) NOT NULL,
    operation VARCHAR(16) NOT NULL,
    encrypted_payload TEXT NOT NULL,
    state VARCHAR(16) NOT NULL DEFAULT 'pending',
    attempt_count INTEGER NOT NULL DEFAULT 0,
    error_code VARCHAR(128) NULL,
    delivered_time TIMESTAMP(0) WITHOUT TIME ZONE NULL,
    status SMALLINT NOT NULL DEFAULT 1,
    create_time TIMESTAMP(0) WITHOUT TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time TIMESTAMP(0) WITHOUT TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT ck_sand_iam_sync_outbox_operation
        CHECK (operation IN ('create', 'update', 'disable', 'delete')),
    CONSTRAINT ck_sand_iam_sync_outbox_state
        CHECK (state IN ('pending', 'succeeded', 'failed')),
    CONSTRAINT ck_sand_iam_sync_outbox_attempt_count
        CHECK (attempt_count >= 0),
    CONSTRAINT ck_sand_iam_sync_outbox_status
        CHECK (status IN (1, 2)),
    CONSTRAINT uk_sand_iam_sync_outbox_event
        UNIQUE (event_id),
    CONSTRAINT fk_sand_iam_sync_outbox_connector_app
        FOREIGN KEY (sync_connector_id, application_id)
        REFERENCES sand_iam_sync_connector (id, application_id) ON DELETE RESTRICT,
    CONSTRAINT fk_sand_iam_sync_outbox_identity_app
        FOREIGN KEY (identity_id, application_id)
        REFERENCES sand_iam_identity (id, application_id) ON DELETE RESTRICT
);

CREATE INDEX IF NOT EXISTS idx_sand_iam_sync_outbox_pending
    ON sand_iam_sync_outbox (sync_connector_id, id)
    WHERE state = 'pending' AND status = 1;

-- lifecycle source: migrations/016_oauth_dynamic_registration_logout.pgsql
-- SandIAM T11: RFC 7591 initial access tokens and OIDC logout metadata.
-- Candidate migration only; root lifecycle integration is verified separately.

CREATE TABLE IF NOT EXISTS sand_iam_oauth_registration_token (
    id BIGSERIAL PRIMARY KEY,
    application_id BIGINT NOT NULL,
    name VARCHAR(128) NOT NULL,
    token_hash CHAR(64) NOT NULL,
    allowed_redirect_hosts JSONB NOT NULL DEFAULT '[]'::JSONB,
    allowed_scopes JSONB NOT NULL DEFAULT '[]'::JSONB,
    max_uses INTEGER NOT NULL DEFAULT 1,
    used_count INTEGER NOT NULL DEFAULT 0,
    expire_time TIMESTAMP(0) WITHOUT TIME ZONE NOT NULL,
    issued_by VARCHAR(128) NOT NULL,
    last_used_time TIMESTAMP(0) WITHOUT TIME ZONE NULL,
    last_used_ip_hash CHAR(64) NULL,
    revoked_time TIMESTAMP(0) WITHOUT TIME ZONE NULL,
    status SMALLINT NOT NULL DEFAULT 1,
    create_time TIMESTAMP(0) WITHOUT TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time TIMESTAMP(0) WITHOUT TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uk_sand_iam_oauth_registration_token_hash UNIQUE (token_hash),
    CONSTRAINT ck_sand_iam_oauth_registration_token_hosts CHECK (jsonb_typeof(allowed_redirect_hosts) = 'array'),
    CONSTRAINT ck_sand_iam_oauth_registration_token_scopes CHECK (jsonb_typeof(allowed_scopes) = 'array'),
    CONSTRAINT ck_sand_iam_oauth_registration_token_uses CHECK (max_uses BETWEEN 1 AND 1000 AND used_count BETWEEN 0 AND max_uses),
    CONSTRAINT ck_sand_iam_oauth_registration_token_status CHECK (status IN (1, 2)),
    CONSTRAINT fk_sand_iam_oauth_registration_token_app FOREIGN KEY (application_id) REFERENCES sand_iam_application (id) ON DELETE RESTRICT
);

CREATE INDEX IF NOT EXISTS idx_sand_iam_oauth_registration_token_app_status
    ON sand_iam_oauth_registration_token (application_id, status, expire_time, id DESC);

ALTER TABLE sand_iam_oauth_client
    ADD COLUMN IF NOT EXISTS registration_source VARCHAR(16) NOT NULL DEFAULT 'manual',
    ADD COLUMN IF NOT EXISTS dynamic_registration_token_id BIGINT NULL,
    ADD COLUMN IF NOT EXISTS frontchannel_logout_uri VARCHAR(2048) NULL,
    ADD COLUMN IF NOT EXISTS frontchannel_logout_session_required BOOLEAN NOT NULL DEFAULT TRUE,
    ADD COLUMN IF NOT EXISTS backchannel_logout_uri VARCHAR(2048) NULL,
    ADD COLUMN IF NOT EXISTS backchannel_logout_session_required BOOLEAN NOT NULL DEFAULT TRUE;

DO $$ BEGIN IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'ck_sand_iam_oauth_client_registration_source') THEN ALTER TABLE sand_iam_oauth_client ADD CONSTRAINT ck_sand_iam_oauth_client_registration_source CHECK (registration_source IN ('manual', 'dynamic')); END IF; IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'fk_sand_iam_oauth_client_dcr_token') THEN ALTER TABLE sand_iam_oauth_client ADD CONSTRAINT fk_sand_iam_oauth_client_dcr_token FOREIGN KEY (dynamic_registration_token_id) REFERENCES sand_iam_oauth_registration_token (id) ON DELETE RESTRICT; END IF; END $$;

CREATE INDEX IF NOT EXISTS idx_sand_iam_oauth_client_dcr_token
    ON sand_iam_oauth_client (dynamic_registration_token_id)
    WHERE dynamic_registration_token_id IS NOT NULL;

CREATE TABLE IF NOT EXISTS sand_iam_oidc_logout_delivery (
    id BIGSERIAL PRIMARY KEY,
    application_id BIGINT NOT NULL,
    oauth_client_id BIGINT NOT NULL,
    auth_session_id BIGINT NOT NULL,
    event_id VARCHAR(64) NOT NULL,
    encrypted_logout_token TEXT NOT NULL,
    state VARCHAR(16) NOT NULL DEFAULT 'pending',
    attempt_count INTEGER NOT NULL DEFAULT 0,
    next_attempt_time TIMESTAMP(0) WITHOUT TIME ZONE NULL,
    locked_until TIMESTAMP(0) WITHOUT TIME ZONE NULL,
    delivered_time TIMESTAMP(0) WITHOUT TIME ZONE NULL,
    response_status INTEGER NULL,
    response_digest CHAR(64) NULL,
    last_error_code VARCHAR(128) NULL,
    status SMALLINT NOT NULL DEFAULT 1,
    create_time TIMESTAMP(0) WITHOUT TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time TIMESTAMP(0) WITHOUT TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uk_sand_iam_oidc_logout_delivery_event UNIQUE (event_id),
    CONSTRAINT ck_sand_iam_oidc_logout_delivery_state CHECK (state IN ('pending', 'sending', 'delivered', 'dead')),
    CONSTRAINT ck_sand_iam_oidc_logout_delivery_attempt CHECK (attempt_count BETWEEN 0 AND 5),
    CONSTRAINT ck_sand_iam_oidc_logout_delivery_status CHECK (status IN (1, 2)),
    CONSTRAINT fk_sand_iam_oidc_logout_delivery_app FOREIGN KEY (application_id) REFERENCES sand_iam_application (id) ON DELETE RESTRICT,
    CONSTRAINT fk_sand_iam_oidc_logout_delivery_client FOREIGN KEY (oauth_client_id) REFERENCES sand_iam_oauth_client (id) ON DELETE RESTRICT,
    CONSTRAINT fk_sand_iam_oidc_logout_delivery_session FOREIGN KEY (auth_session_id) REFERENCES sand_iam_auth_session (id) ON DELETE RESTRICT
);

CREATE INDEX IF NOT EXISTS idx_sand_iam_oidc_logout_delivery_pending
    ON sand_iam_oidc_logout_delivery (next_attempt_time, id)
    WHERE state = 'pending' AND status = 1;

-- lifecycle source: migrations/017_cas_protocol.pgsql
BEGIN;

CREATE TABLE IF NOT EXISTS sand_iam_cas_service (
    id bigserial PRIMARY KEY,
    application_id bigint NOT NULL REFERENCES sand_iam_application(id),
    name varchar(128) NOT NULL,
    service_url varchar(512) NOT NULL,
    released_attributes jsonb NOT NULL DEFAULT '[]'::jsonb,
    status smallint NOT NULL DEFAULT 1 CHECK (status IN (1, 2)),
    create_time timestamp without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uk_sand_iam_cas_service_url UNIQUE (service_url)
);

CREATE INDEX IF NOT EXISTS idx_sand_iam_cas_service_app_status
    ON sand_iam_cas_service (application_id, status);

CREATE TABLE IF NOT EXISTS sand_iam_cas_login_request (
    id bigserial PRIMARY KEY,
    application_id bigint NOT NULL REFERENCES sand_iam_application(id),
    cas_service_id bigint NOT NULL REFERENCES sand_iam_cas_service(id),
    request_hash char(64) NOT NULL,
    expire_time timestamp without time zone NOT NULL,
    consumed_time timestamp without time zone NULL,
    status smallint NOT NULL DEFAULT 1 CHECK (status IN (1, 2)),
    create_time timestamp without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uk_sand_iam_cas_login_request_hash UNIQUE (request_hash)
);

CREATE INDEX IF NOT EXISTS idx_sand_iam_cas_login_request_expire
    ON sand_iam_cas_login_request (status, expire_time);

CREATE TABLE IF NOT EXISTS sand_iam_cas_ticket (
    id bigserial PRIMARY KEY,
    application_id bigint NOT NULL REFERENCES sand_iam_application(id),
    cas_service_id bigint NOT NULL REFERENCES sand_iam_cas_service(id),
    identity_id bigint NOT NULL REFERENCES sand_iam_identity(id),
    ticket_hash char(64) NOT NULL,
    expire_time timestamp without time zone NOT NULL,
    consumed_time timestamp without time zone NULL,
    status smallint NOT NULL DEFAULT 1 CHECK (status IN (1, 2)),
    create_time timestamp without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uk_sand_iam_cas_ticket_hash UNIQUE (ticket_hash)
);

CREATE INDEX IF NOT EXISTS idx_sand_iam_cas_ticket_expire
    ON sand_iam_cas_ticket (status, expire_time);
CREATE INDEX IF NOT EXISTS idx_sand_iam_cas_ticket_identity
    ON sand_iam_cas_ticket (application_id, identity_id, create_time DESC);

COMMIT;

-- lifecycle source: migrations/018_radius_server.pgsql
BEGIN;

CREATE TABLE IF NOT EXISTS sand_iam_radius_nas (
    id bigserial PRIMARY KEY,
    application_id bigint NOT NULL REFERENCES sand_iam_application(id),
    name varchar(128) NOT NULL,
    source_cidr cidr NOT NULL,
    encrypted_shared_secret text NULL,
    secret_version varchar(32) NULL,
    accounting_enabled boolean NOT NULL DEFAULT false,
    status smallint NOT NULL DEFAULT 1 CHECK (status IN (1, 2)),
    create_time timestamp without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uk_sand_iam_radius_nas_source UNIQUE (source_cidr)
);

CREATE INDEX IF NOT EXISTS idx_sand_iam_radius_nas_app_status
    ON sand_iam_radius_nas (application_id, status);

CREATE TABLE IF NOT EXISTS sand_iam_radius_replay (
    id bigserial PRIMARY KEY,
    radius_nas_id bigint NOT NULL REFERENCES sand_iam_radius_nas(id) ON DELETE CASCADE,
    request_fingerprint char(64) NOT NULL,
    expire_time timestamp without time zone NOT NULL,
    status smallint NOT NULL DEFAULT 1 CHECK (status IN (1, 2)),
    create_time timestamp without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uk_sand_iam_radius_replay UNIQUE (radius_nas_id, request_fingerprint)
);

CREATE INDEX IF NOT EXISTS idx_sand_iam_radius_replay_expire
    ON sand_iam_radius_replay (expire_time);

CREATE TABLE IF NOT EXISTS sand_iam_radius_accounting_session (
    id bigserial PRIMARY KEY,
    application_id bigint NOT NULL REFERENCES sand_iam_application(id),
    radius_nas_id bigint NOT NULL REFERENCES sand_iam_radius_nas(id),
    session_reference char(64) NOT NULL,
    user_reference char(64) NULL,
    state varchar(16) NOT NULL CHECK (state IN ('active', 'stopped')),
    start_time timestamp without time zone NOT NULL,
    last_event_time timestamp without time zone NOT NULL,
    stop_time timestamp without time zone NULL,
    session_seconds bigint NOT NULL DEFAULT 0 CHECK (session_seconds >= 0),
    input_octets bigint NOT NULL DEFAULT 0 CHECK (input_octets >= 0),
    output_octets bigint NOT NULL DEFAULT 0 CHECK (output_octets >= 0),
    status smallint NOT NULL DEFAULT 1 CHECK (status IN (1, 2)),
    create_time timestamp without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE UNIQUE INDEX IF NOT EXISTS uk_sand_iam_radius_accounting_active
    ON sand_iam_radius_accounting_session (radius_nas_id, session_reference)
    WHERE state = 'active';
CREATE INDEX IF NOT EXISTS idx_sand_iam_radius_accounting_app_time
    ON sand_iam_radius_accounting_session (application_id, last_event_time DESC);

CREATE TABLE IF NOT EXISTS sand_iam_radius_accounting_event (
    id bigserial PRIMARY KEY,
    application_id bigint NOT NULL REFERENCES sand_iam_application(id),
    radius_nas_id bigint NOT NULL REFERENCES sand_iam_radius_nas(id),
    accounting_session_id bigint NULL REFERENCES sand_iam_radius_accounting_session(id),
    session_reference char(64) NOT NULL,
    user_reference char(64) NULL,
    request_fingerprint char(64) NOT NULL,
    event_type varchar(16) NOT NULL CHECK (event_type IN ('start', 'interim', 'stop')),
    outcome varchar(16) NOT NULL CHECK (outcome IN ('applied', 'orphaned', 'conflict')),
    event_time timestamp without time zone NOT NULL,
    session_seconds bigint NOT NULL DEFAULT 0 CHECK (session_seconds >= 0),
    input_octets bigint NOT NULL DEFAULT 0 CHECK (input_octets >= 0),
    output_octets bigint NOT NULL DEFAULT 0 CHECK (output_octets >= 0),
    create_time timestamp without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uk_sand_iam_radius_accounting_event UNIQUE (radius_nas_id, request_fingerprint)
);

CREATE INDEX IF NOT EXISTS idx_sand_iam_radius_accounting_event_time
    ON sand_iam_radius_accounting_event (application_id, event_time DESC);

COMMIT;

-- lifecycle source: migrations/019_security_operations.pgsql
-- SandIAM 0.12: application IP allowlist, audit retention/archive and alerts.
-- This immutable migration is not wired into root lifecycle SQL until the
-- separately authorized PostgreSQL lifecycle acceptance.

CREATE TABLE IF NOT EXISTS sand_iam_application_network_policy (
    id bigserial PRIMARY KEY,
    application_id bigint NOT NULL REFERENCES sand_iam_application(id) ON DELETE CASCADE,
    allow_cidrs jsonb NOT NULL DEFAULT '[]'::jsonb,
    deny_cidrs jsonb NOT NULL DEFAULT '[]'::jsonb,
    status smallint NOT NULL DEFAULT 1,
    created_by bigint NULL,
    updated_by bigint NULL,
    create_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uk_sand_iam_application_network_policy UNIQUE (application_id),
    CONSTRAINT ck_sand_iam_application_network_policy_status CHECK (status IN (1, 2)),
    CONSTRAINT ck_sand_iam_application_network_policy_allow CHECK (jsonb_typeof(allow_cidrs) = 'array'),
    CONSTRAINT ck_sand_iam_application_network_policy_deny CHECK (jsonb_typeof(deny_cidrs) = 'array')
);

CREATE INDEX IF NOT EXISTS idx_sand_iam_application_network_policy_status ON sand_iam_application_network_policy(status);

CREATE TABLE IF NOT EXISTS sand_iam_audit_retention_policy (
    id bigserial PRIMARY KEY,
    organization_id bigint NOT NULL REFERENCES sand_iam_organization(id) ON DELETE CASCADE,
    archive_after_days integer NOT NULL DEFAULT 90,
    retention_days integer NOT NULL DEFAULT 365,
    purge_enabled boolean NOT NULL DEFAULT false,
    alert_window_seconds integer NOT NULL DEFAULT 300,
    alert_failure_threshold integer NOT NULL DEFAULT 5,
    status smallint NOT NULL DEFAULT 1,
    created_by bigint NULL,
    updated_by bigint NULL,
    create_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uk_sand_iam_audit_retention_policy UNIQUE (organization_id),
    CONSTRAINT ck_sand_iam_audit_retention_range CHECK (archive_after_days BETWEEN 1 AND 3650 AND retention_days BETWEEN archive_after_days AND 3650),
    CONSTRAINT ck_sand_iam_audit_alert_window CHECK (alert_window_seconds BETWEEN 60 AND 86400),
    CONSTRAINT ck_sand_iam_audit_alert_threshold CHECK (alert_failure_threshold BETWEEN 2 AND 10000),
    CONSTRAINT ck_sand_iam_audit_retention_status CHECK (status IN (1, 2))
);

CREATE TABLE IF NOT EXISTS sand_iam_audit_archive (
    id bigserial PRIMARY KEY,
    original_audit_id bigint NOT NULL,
    actor_type varchar(32) NOT NULL,
    actor_ref varchar(128) NOT NULL,
    organization_id bigint NULL,
    application_id bigint NULL,
    action varchar(96) NOT NULL,
    resource_type varchar(64) NOT NULL,
    resource_id bigint NULL,
    outcome varchar(32) NOT NULL,
    request_id varchar(96) NOT NULL,
    context jsonb NOT NULL DEFAULT '{}'::jsonb,
    original_create_time timestamp(0) without time zone NOT NULL,
    archive_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uk_sand_iam_audit_archive_original UNIQUE (original_audit_id)
);

CREATE INDEX IF NOT EXISTS idx_sand_iam_audit_archive_org_time ON sand_iam_audit_archive(organization_id, original_create_time DESC);
CREATE INDEX IF NOT EXISTS idx_sand_iam_audit_archive_request ON sand_iam_audit_archive(request_id);

CREATE TABLE IF NOT EXISTS sand_iam_security_alert (
    id bigserial PRIMARY KEY,
    organization_id bigint NOT NULL REFERENCES sand_iam_organization(id) ON DELETE CASCADE,
    application_id bigint NULL REFERENCES sand_iam_application(id) ON DELETE CASCADE,
    rule_code varchar(64) NOT NULL,
    severity varchar(16) NOT NULL,
    fingerprint char(64) NOT NULL,
    occurrence_count integer NOT NULL DEFAULT 1,
    first_seen_time timestamp(0) without time zone NOT NULL,
    last_seen_time timestamp(0) without time zone NOT NULL,
    status varchar(16) NOT NULL DEFAULT 'open',
    resolved_by bigint NULL,
    resolved_time timestamp(0) without time zone NULL,
    create_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT ck_sand_iam_security_alert_severity CHECK (severity IN ('low', 'medium', 'high', 'critical')),
    CONSTRAINT ck_sand_iam_security_alert_status CHECK (status IN ('open', 'acknowledged', 'resolved'))
);

CREATE INDEX IF NOT EXISTS idx_sand_iam_security_alert_scope ON sand_iam_security_alert(organization_id, application_id, status, last_seen_time DESC);
CREATE UNIQUE INDEX IF NOT EXISTS uk_sand_iam_security_alert_open ON sand_iam_security_alert(organization_id, fingerprint) WHERE status = 'open';

-- lifecycle source: migrations/020_initialization_package.pgsql
-- SandIAM 0.12: reviewable initialization packages and rollback records.
-- No secrets, identities or business data may be stored in these tables.

CREATE TABLE IF NOT EXISTS sand_iam_initialization_run (
    id bigserial PRIMARY KEY,
    organization_id bigint NOT NULL REFERENCES sand_iam_organization(id) ON DELETE RESTRICT,
    application_id bigint NULL REFERENCES sand_iam_application(id) ON DELETE RESTRICT,
    package_code varchar(64) NOT NULL,
    package_hash char(64) NOT NULL,
    preview_hash char(64) NOT NULL,
    manifest jsonb NOT NULL,
    changes jsonb NOT NULL,
    state varchar(16) NOT NULL DEFAULT 'applied',
    applied_by bigint NOT NULL,
    applied_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    rollback_by bigint NULL,
    rollback_time timestamp(0) without time zone NULL,
    request_id varchar(96) NOT NULL,
    create_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT ck_sand_iam_initialization_run_state CHECK (state IN ('applied', 'rolled_back'))
);

CREATE INDEX IF NOT EXISTS idx_sand_iam_initialization_run_scope ON sand_iam_initialization_run(organization_id, application_id, applied_time DESC);
CREATE INDEX IF NOT EXISTS idx_sand_iam_initialization_run_package ON sand_iam_initialization_run(package_code, package_hash);

CREATE TABLE IF NOT EXISTS sand_iam_initialization_binding (
    id bigserial PRIMARY KEY,
    application_id bigint NOT NULL REFERENCES sand_iam_application(id) ON DELETE CASCADE,
    package_code varchar(64) NOT NULL,
    object_type varchar(32) NOT NULL,
    object_key varchar(128) NOT NULL,
    table_name varchar(64) NOT NULL,
    resource_id bigint NOT NULL,
    create_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uk_sand_iam_initialization_binding UNIQUE (application_id, package_code, object_type, object_key),
    CONSTRAINT ck_sand_iam_initialization_binding_type CHECK (object_type IN ('application', 'role', 'user_type', 'resource', 'identity_provider', 'policy', 'application_business_action')),
    CONSTRAINT ck_sand_iam_initialization_binding_table CHECK (table_name IN ('sand_iam_application', 'sand_iam_role', 'sand_iam_user_type', 'sand_iam_resource', 'sand_iam_identity_provider', 'sand_iam_policy', 'sand_iam_application_business_action'))
);

CREATE INDEX IF NOT EXISTS idx_sand_iam_initialization_binding_resource ON sand_iam_initialization_binding(table_name, resource_id);

-- lifecycle source: migrations/021_admin_permission_catalog.pgsql
-- SandIAM terminal administration permission catalog.
-- Permission nodes stay hidden; operators see task paths instead of a flat
-- list of machine actions. Chinese names describe the actual operation.
BEGIN;

WITH permission_group(resource_code, resource_name, parent_code, base_sort, actions) AS (
    VALUES
        ('admin_application_grant', '应用管理委派', 'SandIAMConnection', 2100, ARRAY['index','read','save','update','disable']::text[]),
        ('application_experience', '登录与用户体验', 'SandIAMConnection', 2080, ARRAY['index','read','save','update','disable']::text[]),
        ('message_provider', '消息服务商', 'SandIAMConnection', 2060, ARRAY['index','read','save','update','configure','test','disable']::text[]),
        ('message_provider_mount', '应用消息服务', 'SandIAMConnection', 2040, ARRAY['index','save','disable']::text[]),
        ('initialization', '应用初始化方案', 'SandIAMConnection', 2020, ARRAY['index','read','preview','apply','rollback','export']::text[]),
        -- Explicit assignment only: onboarding can create or change several
        -- application-scoped authorization records in one operation.
        ('onboarding', '开发者接入', 'SandIAMConnection', 2010, ARRAY['preview','apply']::text[]),

        ('api_resource', '接口资源', 'SandIAMPeopleAccess', 2000, ARRAY['index','read','save','update','disable']::text[]),
        ('api_route_binding', '接口路由绑定', 'SandIAMPeopleAccess', 1980, ARRAY['index','read','save','update','disable']::text[]),
        ('cas_service', 'CAS 接入服务', 'SandIAMPeopleAccess', 1960, ARRAY['index','read','save','update','disable']::text[]),
        ('identity', '应用用户', 'SandIAMPeopleAccess', 1940, ARRAY['enable','delete','restore']::text[]),
        ('identity_export', '应用用户导出', 'SandIAMPeopleAccess', 1920, ARRAY['masked','sensitive']::text[]),
        ('identity_group', '用户组', 'SandIAMPeopleAccess', 1900, ARRAY['index','read','save','update','disable']::text[]),
        ('identity_group_member', '用户组成员', 'SandIAMPeopleAccess', 1880, ARRAY['index','add','remove']::text[]),
        ('identity_import', '应用用户导入', 'SandIAMPeopleAccess', 1860, ARRAY['index','read','preview','confirm']::text[]),
        ('identity_invitation', '用户邀请', 'SandIAMPeopleAccess', 1840, ARRAY['index','read','send','resend','revoke']::text[]),
        ('oauth_registration_token', 'OAuth 动态注册令牌', 'SandIAMPeopleAccess', 1820, ARRAY['index','issue','revoke']::text[]),
        ('radius_nas', 'RADIUS 接入设备', 'SandIAMPeopleAccess', 1800, ARRAY['index','read','save','update','configure','disable']::text[]),
        ('sync_connector', '身份同步连接器', 'SandIAMPeopleAccess', 1780, ARRAY['index','read','save','update','configure','test','disable']::text[]),
        ('sync_run', '身份同步任务', 'SandIAMPeopleAccess', 1760, ARRAY['index','run']::text[]),

        ('audit', '访问审计', 'SandIAMAuditTroubleshooting', 1740, ARRAY['export']::text[]),
        ('application_network_policy', '应用访问网络规则', 'SandIAMAuditTroubleshooting', 1720, ARRAY['index','read','save','update','disable']::text[]),
        ('audit_retention_policy', '审计保留规则', 'SandIAMAuditTroubleshooting', 1700, ARRAY['index','read','save','update','disable']::text[]),
        ('developer', '开发者资料', 'SandIAMAuditTroubleshooting', 1680, ARRAY['openapi','events']::text[]),
        ('security_alert', '安全告警', 'SandIAMAuditTroubleshooting', 1660, ARRAY['index','read','resolve']::text[]),
        ('webhook', '事件通知地址', 'SandIAMAuditTroubleshooting', 1640, ARRAY['index','read','save','update','disable']::text[]),
        ('webhook_delivery', '事件通知记录', 'SandIAMAuditTroubleshooting', 1620, ARRAY['index','read','retry']::text[])
), permission_def AS (
    SELECT
        permission_group.resource_code,
        permission_group.resource_name,
        permission_group.parent_code,
        permission_group.base_sort + action.position::integer AS sort,
        action.code AS action_code,
        'sand_iam:' || permission_group.resource_code || ':' || action.code AS permission_code,
        CASE
            WHEN permission_group.resource_code = 'onboarding' AND action.code = 'preview' THEN '开发者接入预检'
            WHEN permission_group.resource_code = 'onboarding' AND action.code = 'apply' THEN '确认应用开发者接入清单'
            ELSE permission_group.resource_name || CASE action.code
            WHEN 'index' THEN '查看'
            WHEN 'read' THEN '查看详情'
            WHEN 'save' THEN '新建'
            WHEN 'update' THEN '编辑'
            WHEN 'disable' THEN '停用'
            WHEN 'enable' THEN '启用'
            WHEN 'delete' THEN '删除'
            WHEN 'restore' THEN '恢复'
            WHEN 'export' THEN '导出'
            WHEN 'masked' THEN '脱敏导出'
            WHEN 'sensitive' THEN '敏感导出'
            WHEN 'add' THEN '添加'
            WHEN 'remove' THEN '移除'
            WHEN 'preview' THEN '预检'
            WHEN 'confirm' THEN '确认导入'
            WHEN 'send' THEN '发出邀请'
            WHEN 'resend' THEN '重新发送'
            WHEN 'revoke' THEN '撤销'
            WHEN 'configure' THEN '配置'
            WHEN 'test' THEN '测试连接'
            WHEN 'openapi' THEN '查看接口文档'
            WHEN 'events' THEN '查看事件目录'
            WHEN 'apply' THEN '应用方案'
            WHEN 'rollback' THEN '回滚'
            WHEN 'issue' THEN '签发'
            WHEN 'resolve' THEN '处理'
            WHEN 'run' THEN '执行'
            WHEN 'retry' THEN '重试'
            ELSE action.code
            END
        END AS permission_name
    FROM permission_group
    CROSS JOIN LATERAL unnest(permission_group.actions) WITH ORDINALITY AS action(code, position)
), permission_menu AS (
    SELECT parent.id AS parent_id,
           permission_def.resource_code,
           permission_def.resource_name,
           permission_def.parent_code,
           permission_def.sort,
           permission_def.action_code,
           permission_def.permission_code,
           permission_def.permission_code AS slug,
           permission_def.permission_name
    FROM permission_def
    JOIN LATERAL (
        SELECT id FROM sand_system_menu WHERE code = permission_def.parent_code ORDER BY id LIMIT 1
    ) parent ON TRUE
), refresh_existing AS (
    -- Earlier 021 revisions used a short dashed slug. SandAdmin's non-super
    -- administrator permission middleware compares the type=3 slug with the
    -- controller Permission code, so correct existing rows before inserting.
    UPDATE sand_system_menu existing
    SET parent_id = desired.parent_id,
        name = desired.permission_name,
        slug = desired.permission_code,
        is_hidden = 1,
        status = 1,
        update_time = CURRENT_TIMESTAMP
    FROM permission_menu desired
    WHERE existing.type = 3
      AND existing.code = desired.permission_code
      AND (
          existing.parent_id IS DISTINCT FROM desired.parent_id
          OR existing.name IS DISTINCT FROM desired.permission_name
          OR existing.slug IS DISTINCT FROM desired.permission_code
          OR existing.is_hidden IS DISTINCT FROM 1
          OR existing.status IS DISTINCT FROM 1
      )
    RETURNING existing.id
)
INSERT INTO sand_system_menu (parent_id, name, code, slug, type, path, component, icon, sort, is_hidden, status, create_time, update_time)
SELECT permission_menu.parent_id, permission_menu.permission_name, permission_menu.permission_code, permission_menu.slug,
       3, '', '', '', permission_menu.sort, 1, 1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP
FROM permission_menu
WHERE NOT EXISTS (
    SELECT 1 FROM sand_system_menu known WHERE known.code = permission_menu.permission_code
);

INSERT INTO sand_system_role_menu (role_id, menu_id)
SELECT DISTINCT inherited.role_id, permission.id
FROM sand_system_role_menu inherited
JOIN sand_system_menu parent
  ON parent.id = inherited.menu_id
 AND parent.code IN ('SandIAMConnection', 'SandIAMPeopleAccess', 'SandIAMAuditTroubleshooting')
JOIN sand_system_menu permission
  ON permission.parent_id = parent.id
 AND permission.code LIKE 'sand\_iam:%' ESCAPE '\'
 AND permission.code NOT IN (
     'sand_iam:onboarding:preview',
     'sand_iam:onboarding:apply',
     'sand_iam:api_resource:index',
     'sand_iam:api_route_binding:index'
 )
WHERE NOT EXISTS (
    SELECT 1
    FROM sand_system_role_menu existing
    WHERE existing.role_id = inherited.role_id
      AND existing.menu_id = permission.id
);

COMMIT;

-- lifecycle source: migrations/022_model_soft_delete_contract.pgsql
-- Align every AbstractSandIamModel table with the host BaseModel soft-delete contract.
-- Append-only audit_log deliberately uses support\think\Model and is excluded.
BEGIN;

ALTER TABLE sand_iam_application_experience ADD COLUMN IF NOT EXISTS delete_time timestamp(0) without time zone NULL;
ALTER TABLE sand_iam_application_network_policy ADD COLUMN IF NOT EXISTS delete_time timestamp(0) without time zone NULL;
ALTER TABLE sand_iam_audit_archive ADD COLUMN IF NOT EXISTS delete_time timestamp(0) without time zone NULL;
ALTER TABLE sand_iam_audit_retention_policy ADD COLUMN IF NOT EXISTS delete_time timestamp(0) without time zone NULL;
ALTER TABLE sand_iam_cas_login_request ADD COLUMN IF NOT EXISTS delete_time timestamp(0) without time zone NULL;
ALTER TABLE sand_iam_cas_service ADD COLUMN IF NOT EXISTS delete_time timestamp(0) without time zone NULL;
ALTER TABLE sand_iam_cas_ticket ADD COLUMN IF NOT EXISTS delete_time timestamp(0) without time zone NULL;
ALTER TABLE sand_iam_directory_sync_run ADD COLUMN IF NOT EXISTS delete_time timestamp(0) without time zone NULL;
ALTER TABLE sand_iam_federation_handoff ADD COLUMN IF NOT EXISTS delete_time timestamp(0) without time zone NULL;
ALTER TABLE sand_iam_federation_transaction ADD COLUMN IF NOT EXISTS delete_time timestamp(0) without time zone NULL;
ALTER TABLE sand_iam_identity_group ADD COLUMN IF NOT EXISTS delete_time timestamp(0) without time zone NULL;
ALTER TABLE sand_iam_identity_group_member ADD COLUMN IF NOT EXISTS delete_time timestamp(0) without time zone NULL;
ALTER TABLE sand_iam_identity_import_job ADD COLUMN IF NOT EXISTS delete_time timestamp(0) without time zone NULL;
ALTER TABLE sand_iam_identity_import_row ADD COLUMN IF NOT EXISTS delete_time timestamp(0) without time zone NULL;
ALTER TABLE sand_iam_identity_invitation ADD COLUMN IF NOT EXISTS delete_time timestamp(0) without time zone NULL;
ALTER TABLE sand_iam_identity_provider_application ADD COLUMN IF NOT EXISTS delete_time timestamp(0) without time zone NULL;
ALTER TABLE sand_iam_initialization_binding ADD COLUMN IF NOT EXISTS delete_time timestamp(0) without time zone NULL;
ALTER TABLE sand_iam_initialization_run ADD COLUMN IF NOT EXISTS delete_time timestamp(0) without time zone NULL;
ALTER TABLE sand_iam_message_provider ADD COLUMN IF NOT EXISTS delete_time timestamp(0) without time zone NULL;
ALTER TABLE sand_iam_message_provider_application ADD COLUMN IF NOT EXISTS delete_time timestamp(0) without time zone NULL;
ALTER TABLE sand_iam_oauth_registration_token ADD COLUMN IF NOT EXISTS delete_time timestamp(0) without time zone NULL;
ALTER TABLE sand_iam_oidc_logout_delivery ADD COLUMN IF NOT EXISTS delete_time timestamp(0) without time zone NULL;
ALTER TABLE sand_iam_oidc_signing_key ADD COLUMN IF NOT EXISTS delete_time timestamp(0) without time zone NULL;
ALTER TABLE sand_iam_provisioning_event ADD COLUMN IF NOT EXISTS delete_time timestamp(0) without time zone NULL;
ALTER TABLE sand_iam_radius_accounting_event ADD COLUMN IF NOT EXISTS delete_time timestamp(0) without time zone NULL;
ALTER TABLE sand_iam_radius_accounting_session ADD COLUMN IF NOT EXISTS delete_time timestamp(0) without time zone NULL;
ALTER TABLE sand_iam_radius_nas ADD COLUMN IF NOT EXISTS delete_time timestamp(0) without time zone NULL;
ALTER TABLE sand_iam_radius_replay ADD COLUMN IF NOT EXISTS delete_time timestamp(0) without time zone NULL;
ALTER TABLE sand_iam_scim_group ADD COLUMN IF NOT EXISTS delete_time timestamp(0) without time zone NULL;
ALTER TABLE sand_iam_scim_group_member ADD COLUMN IF NOT EXISTS delete_time timestamp(0) without time zone NULL;
ALTER TABLE sand_iam_scim_resource ADD COLUMN IF NOT EXISTS delete_time timestamp(0) without time zone NULL;
ALTER TABLE sand_iam_security_alert ADD COLUMN IF NOT EXISTS delete_time timestamp(0) without time zone NULL;
ALTER TABLE sand_iam_sync_connector ADD COLUMN IF NOT EXISTS delete_time timestamp(0) without time zone NULL;
ALTER TABLE sand_iam_sync_outbox ADD COLUMN IF NOT EXISTS delete_time timestamp(0) without time zone NULL;
ALTER TABLE sand_iam_sync_resource ADD COLUMN IF NOT EXISTS delete_time timestamp(0) without time zone NULL;
ALTER TABLE sand_iam_sync_run ADD COLUMN IF NOT EXISTS delete_time timestamp(0) without time zone NULL;

COMMIT;

-- lifecycle source: migrations/023_federation_protocol_constraint_alignment.pgsql
-- Align database protocol constraints with the supported federation services.
BEGIN;

ALTER TABLE sand_iam_identity_provider
    DROP CONSTRAINT IF EXISTS ck_sand_iam_identity_provider_type;
ALTER TABLE sand_iam_identity_provider
    ADD CONSTRAINT ck_sand_iam_identity_provider_type
    CHECK (provider_type IN ('local', 'oidc', 'oauth2', 'saml', 'ldap', 'scim', 'kerberos'));

ALTER TABLE sand_iam_federation_transaction
    DROP CONSTRAINT IF EXISTS sand_iam_federation_transaction_protocol_check;
ALTER TABLE sand_iam_federation_transaction
    DROP CONSTRAINT IF EXISTS ck_sand_iam_federation_transaction_protocol;
ALTER TABLE sand_iam_federation_transaction
    ADD CONSTRAINT ck_sand_iam_federation_transaction_protocol
    CHECK (protocol IN ('oidc', 'oauth2', 'saml'));

COMMIT;

-- lifecycle source: migrations/024_scim_group_member_lifecycle.pgsql
-- SandIAM SCIM group member lifecycle contract.
-- Membership removal is reversible: status records the business state while
-- delete_time is managed by the model's soft-delete concern.

ALTER TABLE sand_iam_scim_group_member
    ADD COLUMN IF NOT EXISTS status smallint NOT NULL DEFAULT 1,
    ADD COLUMN IF NOT EXISTS update_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP;

DO $$ BEGIN ALTER TABLE sand_iam_scim_group_member ADD CONSTRAINT ck_sand_iam_scim_group_member_status CHECK (status IN (1, 2)); EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE INDEX IF NOT EXISTS idx_sand_iam_scim_group_member_group_status
    ON sand_iam_scim_group_member (group_id, status);

-- lifecycle source: migrations/025_message_provider_mount_scope_integrity.pgsql
-- SandIAM message provider mount scope integrity.
-- A mount may only connect an application and provider owned by the same
-- organization. Controller validation is not a substitute for database
-- isolation because imports and future workers can also write this table.

DO $$ BEGIN ALTER TABLE sand_iam_message_provider ADD CONSTRAINT uk_sand_iam_message_provider_id_organization UNIQUE (id, organization_id); EXCEPTION WHEN duplicate_object OR duplicate_table THEN NULL; END $$;

DO $$ BEGIN ALTER TABLE sand_iam_message_provider_application ADD CONSTRAINT fk_sand_iam_message_mount_provider_organization FOREIGN KEY (message_provider_id, organization_id) REFERENCES sand_iam_message_provider(id, organization_id) ON DELETE RESTRICT; EXCEPTION WHEN duplicate_object OR duplicate_table THEN NULL; END $$;

DO $$ BEGIN ALTER TABLE sand_iam_message_provider_application ADD CONSTRAINT fk_sand_iam_message_mount_application_organization FOREIGN KEY (application_id, organization_id) REFERENCES sand_iam_application(id, organization_id) ON DELETE RESTRICT; EXCEPTION WHEN duplicate_object OR duplicate_table THEN NULL; END $$;

-- lifecycle source: migrations/026_sync_connector_scope_integrity.pgsql
-- SandIAM sync connector scope integrity.
-- The connector's organization is denormalized for administration and audit,
-- but it must always match the owning application's organization.

DO $$ BEGIN ALTER TABLE sand_iam_sync_connector ADD CONSTRAINT fk_sand_iam_sync_connector_application_organization FOREIGN KEY (application_id, organization_id) REFERENCES sand_iam_application(id, organization_id) ON DELETE RESTRICT; EXCEPTION WHEN duplicate_object OR duplicate_table THEN NULL; END $$;

-- lifecycle source: migrations/027_security_operation_idempotency.pgsql
CREATE TABLE IF NOT EXISTS sand_iam_security_operation (
    id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    actor_type varchar(32) NOT NULL,
    actor_ref varchar(128) NOT NULL,
    operation varchar(96) NOT NULL,
    request_id varchar(96) NOT NULL,
    request_fingerprint char(64) NOT NULL,
    resource_type varchar(64) NOT NULL,
    resource_id bigint NULL,
    state varchar(16) NOT NULL,
    result jsonb NOT NULL DEFAULT '{}'::jsonb,
    create_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uk_sand_iam_security_operation_actor_request UNIQUE (actor_type, actor_ref, operation, request_id),
    CONSTRAINT ck_sand_iam_security_operation_state CHECK (state IN ('pending', 'succeeded')),
    CONSTRAINT ck_sand_iam_security_operation_fingerprint CHECK (request_fingerprint ~ '^[0-9a-f]{64}$')
);

ALTER TABLE sand_iam_security_operation ADD COLUMN IF NOT EXISTS actor_type varchar(32);
ALTER TABLE sand_iam_security_operation ADD COLUMN IF NOT EXISTS actor_ref varchar(128);
ALTER TABLE sand_iam_security_operation ADD COLUMN IF NOT EXISTS operation varchar(96);
ALTER TABLE sand_iam_security_operation ADD COLUMN IF NOT EXISTS request_id varchar(96);
ALTER TABLE sand_iam_security_operation ADD COLUMN IF NOT EXISTS request_fingerprint char(64);
ALTER TABLE sand_iam_security_operation ADD COLUMN IF NOT EXISTS resource_type varchar(64);
ALTER TABLE sand_iam_security_operation ADD COLUMN IF NOT EXISTS resource_id bigint NULL;
ALTER TABLE sand_iam_security_operation ADD COLUMN IF NOT EXISTS state varchar(16);
ALTER TABLE sand_iam_security_operation ADD COLUMN IF NOT EXISTS result jsonb NOT NULL DEFAULT '{}'::jsonb;
ALTER TABLE sand_iam_security_operation ADD COLUMN IF NOT EXISTS create_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE sand_iam_security_operation ADD COLUMN IF NOT EXISTS update_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP;

DO $$ BEGIN IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'uk_sand_iam_security_operation_actor_request' AND conrelid = 'sand_iam_security_operation'::regclass) THEN ALTER TABLE sand_iam_security_operation ADD CONSTRAINT uk_sand_iam_security_operation_actor_request UNIQUE (actor_type, actor_ref, operation, request_id); END IF; IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'ck_sand_iam_security_operation_state' AND conrelid = 'sand_iam_security_operation'::regclass) THEN ALTER TABLE sand_iam_security_operation ADD CONSTRAINT ck_sand_iam_security_operation_state CHECK (state IN ('pending', 'succeeded')); END IF; IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'ck_sand_iam_security_operation_fingerprint' AND conrelid = 'sand_iam_security_operation'::regclass) THEN ALTER TABLE sand_iam_security_operation ADD CONSTRAINT ck_sand_iam_security_operation_fingerprint CHECK (request_fingerprint ~ '^[0-9a-f]{64}$'); END IF; END $$;

CREATE INDEX IF NOT EXISTS idx_sand_iam_security_operation_resource ON sand_iam_security_operation (resource_type, resource_id);
CREATE INDEX IF NOT EXISTS idx_sand_iam_security_operation_create_time ON sand_iam_security_operation (create_time);

-- lifecycle source: migrations/028_application_business_action.pgsql
-- Application-owned business-action vocabulary.
--
-- Compatibility policy: deliberately do not backfill sand_iam_api_resource.action
-- or sand_iam_policy.action. Existing free strings are not evidence of a valid
-- declaration; the management API exposes them as pending_claim records for a
-- human operator to review and claim explicitly.
-- This table is intentionally unrelated to sand_iam_service_action.

CREATE TABLE IF NOT EXISTS sand_iam_application_business_action (
    id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    application_id bigint NOT NULL REFERENCES sand_iam_application(id) ON DELETE RESTRICT,
    code varchar(96) NOT NULL,
    name varchar(128) NOT NULL,
    description varchar(500) NOT NULL DEFAULT '',
    state varchar(16) NOT NULL DEFAULT 'draft',
    status smallint NOT NULL DEFAULT 1,
    create_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    delete_time timestamp(0) without time zone NULL
);

DO $$ BEGIN IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conrelid = 'sand_iam_application_business_action'::regclass AND conname = 'sand_iam_application_business_action_code_check') THEN ALTER TABLE sand_iam_application_business_action ADD CONSTRAINT sand_iam_application_business_action_code_check CHECK (code ~ '^[a-z][a-z0-9_.:-]{1,95}$'); END IF; IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conrelid = 'sand_iam_application_business_action'::regclass AND conname = 'sand_iam_application_business_action_state_check') THEN ALTER TABLE sand_iam_application_business_action ADD CONSTRAINT sand_iam_application_business_action_state_check CHECK (state IN ('draft', 'published')); END IF; IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conrelid = 'sand_iam_application_business_action'::regclass AND conname = 'sand_iam_application_business_action_status_check') THEN ALTER TABLE sand_iam_application_business_action ADD CONSTRAINT sand_iam_application_business_action_status_check CHECK (status IN (1, 2)); END IF; IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conrelid = 'sand_iam_application_business_action'::regclass AND conname = 'sand_iam_application_business_action_application_code_unique') THEN ALTER TABLE sand_iam_application_business_action ADD CONSTRAINT sand_iam_application_business_action_application_code_unique UNIQUE (application_id, code); END IF; END $$;

CREATE INDEX IF NOT EXISTS sand_iam_application_business_action_application_status_idx
    ON sand_iam_application_business_action (application_id, status);

COMMENT ON TABLE sand_iam_application_business_action IS 'Application-owned declared business actions; never service integration actions.';
COMMENT ON COLUMN sand_iam_application_business_action.code IS 'Stable action code. Management API never updates code after creation; published declarations are immutable by contract.';

-- lifecycle source: migrations/029_policy_versioning.pgsql
-- Immutable published policy snapshots. Runtime uses published_version_id only.
CREATE TABLE IF NOT EXISTS sand_iam_policy_version (
    id bigserial PRIMARY KEY,
    policy_id bigint NOT NULL REFERENCES sand_iam_policy(id) ON DELETE CASCADE,
    application_id bigint NOT NULL REFERENCES sand_iam_application(id) ON DELETE CASCADE,
    version_no integer NOT NULL,
    snapshot jsonb NOT NULL,
    snapshot_hash varchar(64) NOT NULL,
    rollback_of_version_id bigint NULL REFERENCES sand_iam_policy_version(id) ON DELETE RESTRICT,
    operation varchar(16) NOT NULL DEFAULT 'publish',
    request_id varchar(96) NOT NULL,
    request_fingerprint varchar(64) NOT NULL DEFAULT '',
    create_time timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uk_sand_iam_policy_version_no UNIQUE (policy_id, version_no),
    CONSTRAINT uk_sand_iam_policy_version_request UNIQUE (policy_id, request_id)
);
ALTER TABLE sand_iam_policy ADD COLUMN IF NOT EXISTS published_version_id bigint NULL;
ALTER TABLE sand_iam_policy_version ADD COLUMN IF NOT EXISTS operation varchar(16) NOT NULL DEFAULT 'publish';
ALTER TABLE sand_iam_policy_version ADD COLUMN IF NOT EXISTS request_fingerprint varchar(64) NOT NULL DEFAULT '';
DO $$ BEGIN IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'fk_sand_iam_policy_published_version') THEN ALTER TABLE sand_iam_policy ADD CONSTRAINT fk_sand_iam_policy_published_version FOREIGN KEY (published_version_id) REFERENCES sand_iam_policy_version(id) ON DELETE RESTRICT; END IF; END $$;
CREATE INDEX IF NOT EXISTS idx_sand_iam_policy_version_application ON sand_iam_policy_version(application_id, policy_id, version_no DESC);
CREATE INDEX IF NOT EXISTS idx_sand_iam_policy_published_version ON sand_iam_policy(published_version_id);

-- lifecycle source: migrations/030_service_grant_invocation_control.pgsql
BEGIN;

DO $$ BEGIN IF NOT EXISTS ( SELECT 1 FROM pg_constraint WHERE conname = 'ck_sand_iam_service_grant_data_class' AND conrelid = 'sand_iam_service_grant'::regclass ) THEN ALTER TABLE sand_iam_service_grant ADD CONSTRAINT ck_sand_iam_service_grant_data_class CHECK (data_class IS NULL OR data_class ~ '^[a-z0-9][a-z0-9._-]{1,31}$') NOT VALID; END IF; IF NOT EXISTS ( SELECT 1 FROM pg_constraint WHERE conname = 'ck_sand_iam_service_grant_quota_object' AND conrelid = 'sand_iam_service_grant'::regclass ) THEN ALTER TABLE sand_iam_service_grant ADD CONSTRAINT ck_sand_iam_service_grant_quota_object CHECK (quota_policy IS NULL OR jsonb_typeof(quota_policy) = 'object') NOT VALID; END IF; END $$;

CREATE TABLE IF NOT EXISTS sand_iam_service_invocation_operation (
    id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    workload_client_id bigint NOT NULL REFERENCES sand_iam_workload_client(id) ON DELETE RESTRICT,
    credential_id bigint NOT NULL REFERENCES sand_iam_credential(id) ON DELETE RESTRICT,
    organization_id bigint NOT NULL REFERENCES sand_iam_organization(id) ON DELETE RESTRICT,
    application_id bigint NOT NULL REFERENCES sand_iam_application(id) ON DELETE RESTRICT,
    environment_id bigint NOT NULL REFERENCES sand_iam_environment(id) ON DELETE RESTRICT,
    grant_id bigint NOT NULL REFERENCES sand_iam_service_grant(id) ON DELETE RESTRICT,
    operation_id varchar(96) NOT NULL,
    request_fingerprint varchar(64) NOT NULL,
    context_id varchar(64) NOT NULL,
    service_code varchar(64) NOT NULL,
    action_code varchar(96) NOT NULL,
    audience varchar(128) NOT NULL,
    data_class varchar(32) NULL,
    resource_type varchar(64) NOT NULL,
    resource_ref varchar(128) NOT NULL,
    outcome varchar(16) NOT NULL DEFAULT 'pending',
    error_code varchar(96) NULL,
    request_id varchar(96) NOT NULL,
    quota_window_start timestamp(0) without time zone NULL,
    quota_used bigint NULL,
    create_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uk_sand_iam_invocation_operation_client_operation UNIQUE (workload_client_id, operation_id),
    CONSTRAINT ck_sand_iam_invocation_operation_outcome CHECK (outcome IN ('pending', 'allowed', 'denied')),
    CONSTRAINT ck_sand_iam_invocation_operation_quota_used CHECK (quota_used IS NULL OR quota_used > 0)
);

CREATE INDEX IF NOT EXISTS idx_sand_iam_invocation_operation_grant_time
    ON sand_iam_service_invocation_operation (grant_id, create_time DESC);
CREATE INDEX IF NOT EXISTS idx_sand_iam_invocation_operation_context
    ON sand_iam_service_invocation_operation (context_id);

CREATE TABLE IF NOT EXISTS sand_iam_service_quota_bucket (
    id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    grant_id bigint NOT NULL REFERENCES sand_iam_service_grant(id) ON DELETE RESTRICT,
    window_seconds integer NOT NULL,
    window_start timestamp(0) without time zone NOT NULL,
    used bigint NOT NULL DEFAULT 0,
    create_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uk_sand_iam_service_quota_bucket UNIQUE (grant_id, window_seconds, window_start),
    CONSTRAINT ck_sand_iam_service_quota_bucket_window CHECK (window_seconds > 0 AND window_seconds <= 31536000),
    CONSTRAINT ck_sand_iam_service_quota_bucket_used CHECK (used >= 0)
);

CREATE INDEX IF NOT EXISTS idx_sand_iam_service_quota_bucket_window
    ON sand_iam_service_quota_bucket (window_start DESC);

COMMIT;

-- lifecycle source: migrations/031_oidc_signing_key_rotation.pgsql
-- IAM-T12-031 BEGIN
-- OIDC has one public issuer and therefore one signing owner. OAuth clients
-- are application scoped but do not carry an environment selector; per-app or
-- per-environment signing keys would be unverifiable at this issuer-wide JWKS.
BEGIN;

ALTER TABLE sand_iam_oidc_signing_key
    ADD COLUMN IF NOT EXISTS encrypted_private_key text NULL,
    ADD COLUMN IF NOT EXISTS encryption_version varchar(32) NULL,
    ADD COLUMN IF NOT EXISTS algorithm varchar(16) NOT NULL DEFAULT 'RS256';

COMMENT ON COLUMN sand_iam_oidc_signing_key.encrypted_private_key IS 'Write-only versioned private-key envelope; NULL only when no private signing material is stored.';
COMMENT ON COLUMN sand_iam_oidc_signing_key.encryption_version IS 'Key-encryption version for encrypted_private_key; NULL when no private signing material is stored.';

DO $$ BEGIN IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'ck_sand_iam_oidc_signing_key_algorithm') THEN ALTER TABLE sand_iam_oidc_signing_key ADD CONSTRAINT ck_sand_iam_oidc_signing_key_algorithm CHECK (algorithm = 'RS256') NOT VALID; END IF; END $$;
DO $$ BEGIN IF EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'ck_sand_iam_oidc_signing_key_algorithm' AND NOT convalidated) THEN ALTER TABLE sand_iam_oidc_signing_key VALIDATE CONSTRAINT ck_sand_iam_oidc_signing_key_algorithm; END IF; END $$;

-- One active database signer prevents concurrent rotations from producing two
-- valid signing authorities. Existing verify_only rows remain verification
-- history and are intentionally not affected by this invariant.
CREATE UNIQUE INDEX IF NOT EXISTS uk_sand_iam_oidc_signing_key_one_active
    ON sand_iam_oidc_signing_key ((1))
    WHERE state = 'active';

COMMIT;
-- IAM-T12-031 END

-- lifecycle source: migrations/032_initialization_binding_application_business_action.pgsql
-- Existing installations already have 020's original checks. Replacing those
-- checks here keeps upgrades compatible with application-owned action bindings.
BEGIN;

ALTER TABLE sand_iam_initialization_binding
    DROP CONSTRAINT IF EXISTS ck_sand_iam_initialization_binding_type;
ALTER TABLE sand_iam_initialization_binding
    DROP CONSTRAINT IF EXISTS ck_sand_iam_initialization_binding_table;

ALTER TABLE sand_iam_initialization_binding
    ADD CONSTRAINT ck_sand_iam_initialization_binding_type
    CHECK (object_type IN ('application', 'role', 'user_type', 'resource', 'identity_provider', 'policy', 'application_business_action'));
ALTER TABLE sand_iam_initialization_binding
    ADD CONSTRAINT ck_sand_iam_initialization_binding_table
    CHECK (table_name IN ('sand_iam_application', 'sand_iam_role', 'sand_iam_user_type', 'sand_iam_resource', 'sand_iam_identity_provider', 'sand_iam_policy', 'sand_iam_application_business_action'));

COMMIT;

-- lifecycle source: migrations/033_identity_group_role.pgsql
-- IAM-T11: role grants inherited through active user-group membership.
-- The application is the authoritative organization boundary: both referenced
-- records must carry the same application_id, which belongs to exactly one
-- SandIAM organization.

BEGIN;

CREATE UNIQUE INDEX IF NOT EXISTS ux_sand_iam_role_id_application
    ON sand_iam_role (id, application_id);

CREATE TABLE IF NOT EXISTS sand_iam_identity_group_role (
    id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    identity_group_id bigint NOT NULL,
    role_id bigint NOT NULL,
    application_id bigint NOT NULL REFERENCES sand_iam_application(id) ON DELETE RESTRICT,
    status smallint NOT NULL DEFAULT 1 CHECK (status IN (1, 2)),
    created_by bigint NULL,
    updated_by bigint NULL,
    create_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    delete_time timestamp(0) without time zone NULL,
    CONSTRAINT uk_sand_iam_identity_group_role UNIQUE (identity_group_id, role_id),
    CONSTRAINT fk_sand_iam_group_role_group_app FOREIGN KEY (identity_group_id, application_id)
        REFERENCES sand_iam_identity_group(id, application_id) ON DELETE RESTRICT,
    CONSTRAINT fk_sand_iam_group_role_role_app FOREIGN KEY (role_id, application_id)
        REFERENCES sand_iam_role(id, application_id) ON DELETE RESTRICT
);

CREATE INDEX IF NOT EXISTS idx_sand_iam_identity_group_role_role
    ON sand_iam_identity_group_role (application_id, role_id, status);

COMMIT;

-- lifecycle source: migrations/034_identity_group_role_permission_catalog.pgsql
-- SandIAM 0.7.0: catalog only the user-group role administration permissions.
-- The published 0.6.0 migration 021 is immutable. These permissions are not
-- inherited by existing roles because granting or revoking group roles changes
-- effective authorization and requires an explicit administrator decision.
BEGIN;

DO $$ DECLARE parent_menu_id bigint; BEGIN SELECT id INTO parent_menu_id FROM sand_system_menu WHERE code = 'SandIAMPeopleAccess' ORDER BY id LIMIT 1; IF parent_menu_id IS NULL THEN RAISE EXCEPTION 'SandIAM 0.7.0 cannot add identity-group-role permissions: parent menu SandIAMPeopleAccess is missing'; END IF; END $$;

WITH desired(code, name, sort) AS (
    VALUES
        ('sand_iam:identity_group_role:index', '查看用户组角色', 1871),
        ('sand_iam:identity_group_role:grant', '授予用户组角色', 1872),
        ('sand_iam:identity_group_role:revoke', '撤销用户组角色', 1873)
), parent AS (
    SELECT id
    FROM sand_system_menu
    WHERE code = 'SandIAMPeopleAccess'
    ORDER BY id
    LIMIT 1
), refresh_existing AS (
    UPDATE sand_system_menu existing
    SET parent_id = parent.id,
        name = desired.name,
        slug = desired.code,
        type = 3,
        path = '',
        component = '',
        icon = '',
        sort = desired.sort,
        is_hidden = 1,
        status = 1,
        update_time = CURRENT_TIMESTAMP
    FROM desired
    CROSS JOIN parent
    WHERE existing.code = desired.code
      AND (
          existing.parent_id IS DISTINCT FROM parent.id
          OR existing.name IS DISTINCT FROM desired.name
          OR existing.slug IS DISTINCT FROM desired.code
          OR existing.type IS DISTINCT FROM 3
          OR existing.path IS DISTINCT FROM ''
          OR existing.component IS DISTINCT FROM ''
          OR existing.icon IS DISTINCT FROM ''
          OR existing.sort IS DISTINCT FROM desired.sort
          OR existing.is_hidden IS DISTINCT FROM 1
          OR existing.status IS DISTINCT FROM 1
      )
    RETURNING existing.id
)
INSERT INTO sand_system_menu (parent_id, name, code, slug, type, path, component, icon, sort, is_hidden, status, create_time, update_time)
SELECT parent.id, desired.name, desired.code, desired.code,
       3, '', '', '', desired.sort, 1, 1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP
FROM desired
CROSS JOIN parent
WHERE NOT EXISTS (
    SELECT 1
    FROM sand_system_menu existing
    WHERE existing.code = desired.code
);

COMMIT;

-- lifecycle source: migrations/035_schema_migration_ledger.pgsql
-- SandIAM 0.7.0 migration ledger.
-- There was no database migration ledger in the published 0.6.0 package. The
-- first run therefore adopts its known baseline only after checking the
-- structural version sentinels below; it never treats an empty ledger alone as
-- evidence that a database is compatible.
BEGIN;

CREATE TABLE IF NOT EXISTS sand_iam_schema_migration (
    migration_file varchar(160) PRIMARY KEY,
    revision smallint NOT NULL,
    checksum char(64) NOT NULL,
    package_version varchar(32) NOT NULL,
    executed_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT ck_sand_iam_schema_migration_revision CHECK (revision BETWEEN 1 AND 999),
    CONSTRAINT ck_sand_iam_schema_migration_checksum CHECK (checksum ~ '^[0-9a-f]{64}$')
);

DO $$ DECLARE required_columns integer; matched_columns integer; base_tables text[] := ARRAY['sand_iam_admin_application_grant','sand_iam_admin_organization_grant','sand_iam_api_resource','sand_iam_api_route_binding','sand_iam_application','sand_iam_application_business_action','sand_iam_application_experience','sand_iam_application_network_policy','sand_iam_audit_archive','sand_iam_audit_log','sand_iam_audit_retention_policy','sand_iam_auth_challenge','sand_iam_auth_policy','sand_iam_auth_rate_limit','sand_iam_auth_refresh_token','sand_iam_auth_session','sand_iam_auth_verification','sand_iam_authorization_code','sand_iam_cas_login_request','sand_iam_cas_service','sand_iam_cas_ticket','sand_iam_credential','sand_iam_directory_sync_run','sand_iam_environment','sand_iam_federation_handoff','sand_iam_federation_transaction','sand_iam_identity','sand_iam_identity_auth','sand_iam_identity_binding','sand_iam_identity_group','sand_iam_identity_group_member','sand_iam_identity_import_job','sand_iam_identity_import_row','sand_iam_identity_invitation','sand_iam_identity_provider','sand_iam_identity_provider_application','sand_iam_identity_role','sand_iam_identity_user_type','sand_iam_initialization_binding','sand_iam_initialization_run','sand_iam_message_provider','sand_iam_message_provider_application','sand_iam_mfa_factor','sand_iam_mfa_recovery_code','sand_iam_oauth_authorization_request','sand_iam_oauth_client','sand_iam_oauth_consent','sand_iam_oauth_grant','sand_iam_oauth_registration_token','sand_iam_oauth_token','sand_iam_oidc_logout_delivery','sand_iam_oidc_signing_key','sand_iam_organization','sand_iam_policy','sand_iam_policy_version','sand_iam_provisioning_event','sand_iam_radius_accounting_event','sand_iam_radius_accounting_session','sand_iam_radius_nas','sand_iam_radius_replay','sand_iam_resource','sand_iam_role','sand_iam_scim_group','sand_iam_scim_group_member','sand_iam_scim_resource','sand_iam_scim_token','sand_iam_security_alert','sand_iam_security_operation','sand_iam_service','sand_iam_service_action','sand_iam_service_grant','sand_iam_service_invocation_operation','sand_iam_service_quota_bucket','sand_iam_sync_connector','sand_iam_sync_outbox','sand_iam_sync_resource','sand_iam_sync_run','sand_iam_user_type','sand_iam_webauthn_credential','sand_iam_webhook_delivery','sand_iam_webhook_endpoint','sand_iam_workload_client']; ledger_columns integer; matched_ledger_columns integer; expected_rows integer; recorded_rows integer; total_recorded_rows integer; BEGIN SELECT count(*) INTO total_recorded_rows FROM sand_iam_schema_migration; IF cardinality(base_tables) <> 82 OR EXISTS (SELECT unnest(base_tables) EXCEPT SELECT relation_class.relname FROM pg_class relation_class JOIN pg_namespace relation_namespace ON relation_namespace.oid = relation_class.relnamespace WHERE relation_namespace.nspname = current_schema() AND relation_class.relkind IN ('r', 'p') AND relation_class.relname LIKE 'sand_iam_%' AND relation_class.relname <> 'sand_iam_schema_migration') OR ( total_recorded_rows = 0 AND ( (SELECT count(*) FROM pg_class relation_class JOIN pg_namespace relation_namespace ON relation_namespace.oid = relation_class.relnamespace WHERE relation_namespace.nspname = current_schema() AND relation_class.relkind IN ('r', 'p') AND relation_class.relname LIKE 'sand_iam_%' AND relation_class.relname <> 'sand_iam_schema_migration') <> 83 OR EXISTS (SELECT relation_class.relname FROM pg_class relation_class JOIN pg_namespace relation_namespace ON relation_namespace.oid = relation_class.relnamespace WHERE relation_namespace.nspname = current_schema() AND relation_class.relkind IN ('r', 'p') AND relation_class.relname LIKE 'sand_iam_%' AND relation_class.relname <> 'sand_iam_schema_migration' EXCEPT (SELECT unnest(base_tables) UNION SELECT 'sand_iam_identity_group_role')) ) ) OR ( total_recorded_rows > 0 AND ( (SELECT count(*) FROM pg_class relation_class JOIN pg_namespace relation_namespace ON relation_namespace.oid = relation_class.relnamespace WHERE relation_namespace.nspname = current_schema() AND relation_class.relkind IN ('r', 'p') AND relation_class.relname LIKE 'sand_iam_%' AND relation_class.relname <> 'sand_iam_schema_migration') <> 85 OR EXISTS (SELECT relation_class.relname FROM pg_class relation_class JOIN pg_namespace relation_namespace ON relation_namespace.oid = relation_class.relnamespace WHERE relation_namespace.nspname = current_schema() AND relation_class.relkind IN ('r', 'p') AND relation_class.relname LIKE 'sand_iam_%' AND relation_class.relname <> 'sand_iam_schema_migration' EXCEPT (SELECT unnest(base_tables) UNION SELECT 'sand_iam_identity_group_role' UNION SELECT 'sand_iam_initialization_draft' UNION SELECT 'sand_iam_initialization_draft_revision')) ) ) THEN RAISE EXCEPTION 'SandIAM migration ledger refuses schema adoption: exact legacy or ledger-backed relation fingerprint is incompatible'; END IF; WITH required_baseline_column(table_name, column_name, data_type, is_nullable, requires_default) AS ( VALUES ('sand_iam_identity_provider', 'application_id', 'bigint', 'YES', false), ('sand_iam_identity_provider', 'provider_type', 'character varying', 'NO', false), ('sand_iam_identity_binding', 'identity_provider_id', 'bigint', 'NO', false), ('sand_iam_identity_binding', 'application_id', 'bigint', 'NO', false), ('sand_iam_identity_binding', 'source_state', 'character varying', 'NO', true), ('sand_iam_identity_provider', 'config_version', 'bigint', 'NO', true), ('sand_iam_federation_transaction', 'provider_config_version', 'bigint', 'NO', true), ('sand_iam_directory_sync_run', 'provider_config_version', 'bigint', 'NO', true), ('sand_iam_auth_session', 'identity_binding_id', 'bigint', 'YES', false), ('sand_iam_scim_group_member', 'status', 'smallint', 'NO', true), ('sand_iam_scim_group_member', 'update_time', 'timestamp without time zone', 'NO', true), ('sand_iam_security_operation', 'request_id', 'character varying', 'NO', false), ('sand_iam_security_operation', 'request_fingerprint', 'character', 'NO', false), ('sand_iam_security_operation', 'result', 'jsonb', 'NO', true), ('sand_iam_initialization_binding', 'object_type', 'character varying', 'NO', false), ('sand_iam_initialization_binding', 'table_name', 'character varying', 'NO', false), ('sand_iam_identity_group_role', 'status', 'smallint', 'NO', true), ('sand_iam_identity_group_role', 'create_time', 'timestamp without time zone', 'NO', true), ('sand_iam_identity_group_role', 'update_time', 'timestamp without time zone', 'NO', true), ('sand_iam_identity_group_role', 'delete_time', 'timestamp without time zone', 'YES', false), ('sand_iam_application_experience', 'delete_time', 'timestamp without time zone', 'YES', false), ('sand_iam_application_network_policy', 'delete_time', 'timestamp without time zone', 'YES', false), ('sand_iam_audit_archive', 'delete_time', 'timestamp without time zone', 'YES', false), ('sand_iam_audit_retention_policy', 'delete_time', 'timestamp without time zone', 'YES', false), ('sand_iam_cas_login_request', 'delete_time', 'timestamp without time zone', 'YES', false), ('sand_iam_cas_service', 'delete_time', 'timestamp without time zone', 'YES', false), ('sand_iam_cas_ticket', 'delete_time', 'timestamp without time zone', 'YES', false), ('sand_iam_directory_sync_run', 'delete_time', 'timestamp without time zone', 'YES', false), ('sand_iam_federation_handoff', 'delete_time', 'timestamp without time zone', 'YES', false), ('sand_iam_federation_transaction', 'delete_time', 'timestamp without time zone', 'YES', false), ('sand_iam_identity_group', 'delete_time', 'timestamp without time zone', 'YES', false), ('sand_iam_identity_group_member', 'delete_time', 'timestamp without time zone', 'YES', false), ('sand_iam_identity_import_job', 'delete_time', 'timestamp without time zone', 'YES', false), ('sand_iam_identity_import_row', 'delete_time', 'timestamp without time zone', 'YES', false), ('sand_iam_identity_invitation', 'delete_time', 'timestamp without time zone', 'YES', false), ('sand_iam_identity_provider_application', 'delete_time', 'timestamp without time zone', 'YES', false), ('sand_iam_initialization_binding', 'delete_time', 'timestamp without time zone', 'YES', false), ('sand_iam_initialization_run', 'delete_time', 'timestamp without time zone', 'YES', false), ('sand_iam_message_provider', 'delete_time', 'timestamp without time zone', 'YES', false), ('sand_iam_message_provider_application', 'delete_time', 'timestamp without time zone', 'YES', false), ('sand_iam_oauth_registration_token', 'delete_time', 'timestamp without time zone', 'YES', false), ('sand_iam_oidc_logout_delivery', 'delete_time', 'timestamp without time zone', 'YES', false), ('sand_iam_oidc_signing_key', 'delete_time', 'timestamp without time zone', 'YES', false), ('sand_iam_provisioning_event', 'delete_time', 'timestamp without time zone', 'YES', false), ('sand_iam_radius_accounting_event', 'delete_time', 'timestamp without time zone', 'YES', false), ('sand_iam_radius_accounting_session', 'delete_time', 'timestamp without time zone', 'YES', false), ('sand_iam_radius_nas', 'delete_time', 'timestamp without time zone', 'YES', false), ('sand_iam_radius_replay', 'delete_time', 'timestamp without time zone', 'YES', false), ('sand_iam_scim_group', 'delete_time', 'timestamp without time zone', 'YES', false), ('sand_iam_scim_group_member', 'delete_time', 'timestamp without time zone', 'YES', false), ('sand_iam_scim_resource', 'delete_time', 'timestamp without time zone', 'YES', false), ('sand_iam_security_alert', 'delete_time', 'timestamp without time zone', 'YES', false), ('sand_iam_sync_connector', 'delete_time', 'timestamp without time zone', 'YES', false), ('sand_iam_sync_outbox', 'delete_time', 'timestamp without time zone', 'YES', false), ('sand_iam_sync_resource', 'delete_time', 'timestamp without time zone', 'YES', false), ('sand_iam_sync_run', 'delete_time', 'timestamp without time zone', 'YES', false) ) SELECT count(*) INTO matched_columns FROM required_baseline_column expected JOIN information_schema.columns column_info ON column_info.table_schema = current_schema() AND column_info.table_name = expected.table_name AND column_info.column_name = expected.column_name AND column_info.data_type = expected.data_type AND column_info.is_nullable = expected.is_nullable AND (NOT expected.requires_default OR column_info.column_default IS NOT NULL); IF matched_columns <> 56 THEN RAISE EXCEPTION 'SandIAM migration ledger refuses baseline adoption: key 002/006/022/024/027/032 column fingerprint is incompatible'; END IF; WITH required_constraint(table_name, constraint_name, constraint_type, definition_token, normalized_check_definition) AS ( VALUES ('sand_iam_identity_provider', 'uk_sand_iam_identity_provider_application_code', 'u', 'UNIQUE (application_id, code)', NULL), ('sand_iam_identity_provider', 'uk_sand_iam_identity_provider_id_application', 'u', 'UNIQUE (id, application_id)', NULL), ('sand_iam_identity_binding', 'fk_sand_iam_identity_binding_identity_application', 'f', 'FOREIGN KEY (identity_id, application_id) REFERENCES sand_iam_identity(id, application_id) ON DELETE RESTRICT', NULL), ('sand_iam_identity_binding', 'fk_sand_iam_identity_binding_provider_application', 'f', 'FOREIGN KEY (identity_provider_id, application_id) REFERENCES sand_iam_identity_provider_application(identity_provider_id, application_id) ON DELETE RESTRICT', NULL), ('sand_iam_identity_binding', 'uk_sand_iam_identity_binding_provider_application_subject', 'u', 'UNIQUE (identity_provider_id, application_id, subject)', NULL), ('sand_iam_identity_binding', 'ck_sand_iam_identity_binding_source_state', 'c', NULL, 'checksource_state=anyarray[''active'',''disabled'',''deleted'']'), ('sand_iam_identity_provider', 'ck_sand_iam_identity_provider_type', 'c', NULL, 'checkprovider_type=anyarray[''local'',''oidc'',''oauth2'',''saml'',''ldap'',''scim'',''kerberos'']'), ('sand_iam_identity_provider', 'ck_sand_iam_identity_provider_scope', 'c', NULL, 'checkscope_type=''application''andapplication_idisnotnullorscope_type=''organization''andapplication_idisnull'), ('sand_iam_federation_transaction', 'fk_sand_iam_federation_transaction_provider_application', 'f', 'FOREIGN KEY (identity_provider_id, application_id) REFERENCES sand_iam_identity_provider_application(identity_provider_id, application_id) ON DELETE RESTRICT', NULL), ('sand_iam_federation_transaction', 'ck_sand_iam_federation_transaction_protocol', 'c', NULL, 'checkprotocol=anyarray[''oidc'',''oauth2'',''saml'']'), ('sand_iam_auth_session', 'fk_sand_iam_auth_session_federation_binding', 'f', 'FOREIGN KEY (identity_binding_id, application_id, identity_id) REFERENCES sand_iam_identity_binding(id, application_id, identity_id)', NULL), ('sand_iam_auth_session', 'ck_sand_iam_auth_session_federation_method', 'c', NULL, 'checkauth_method=''local_password''andidentity_binding_idisnullorauth_method=''federation''andidentity_binding_idisnotnull'), ('sand_iam_scim_group_member', 'ck_sand_iam_scim_group_member_status', 'c', NULL, 'checkstatus=anyarray[1,2]'), ('sand_iam_message_provider', 'uk_sand_iam_message_provider_id_organization', 'u', 'UNIQUE (id, organization_id)', NULL), ('sand_iam_message_provider_application', 'fk_sand_iam_message_mount_provider_organization', 'f', 'FOREIGN KEY (message_provider_id, organization_id) REFERENCES sand_iam_message_provider(id, organization_id) ON DELETE RESTRICT', NULL), ('sand_iam_message_provider_application', 'fk_sand_iam_message_mount_application_organization', 'f', 'FOREIGN KEY (application_id, organization_id) REFERENCES sand_iam_application(id, organization_id) ON DELETE RESTRICT', NULL), ('sand_iam_sync_connector', 'fk_sand_iam_sync_connector_application_organization', 'f', 'FOREIGN KEY (application_id, organization_id) REFERENCES sand_iam_application(id, organization_id) ON DELETE RESTRICT', NULL), ('sand_iam_security_operation', 'uk_sand_iam_security_operation_actor_request', 'u', 'UNIQUE (actor_type, actor_ref, operation, request_id)', NULL), ('sand_iam_security_operation', 'ck_sand_iam_security_operation_state', 'c', NULL, 'checkstate=anyarray[''pending'',''succeeded'']'), ('sand_iam_security_operation', 'ck_sand_iam_security_operation_fingerprint', 'c', NULL, 'checkrequest_fingerprint~''^[0-9a-f]{64}$'''), ('sand_iam_service_grant', 'ck_sand_iam_service_grant_data_class', 'c', NULL, 'checkdata_classisnullordata_class~''^[a-z0-9][a-z0-9._-]{1,31}$'''), ('sand_iam_service_grant', 'ck_sand_iam_service_grant_quota_object', 'c', NULL, 'checkquota_policyisnullorjsonb_typeofquota_policy=''object'''), ('sand_iam_service_invocation_operation', 'uk_sand_iam_invocation_operation_client_operation', 'u', 'UNIQUE (workload_client_id, operation_id)', NULL), ('sand_iam_service_quota_bucket', 'uk_sand_iam_service_quota_bucket', 'u', 'UNIQUE (grant_id, window_seconds, window_start)', NULL), ('sand_iam_initialization_binding', 'ck_sand_iam_initialization_binding_type', 'c', NULL, 'checkobject_type=anyarray[''application'',''role'',''user_type'',''resource'',''identity_provider'',''policy'',''application_business_action'']'), ('sand_iam_initialization_binding', 'ck_sand_iam_initialization_binding_table', 'c', NULL, 'checktable_name=anyarray[''sand_iam_application'',''sand_iam_role'',''sand_iam_user_type'',''sand_iam_resource'',''sand_iam_identity_provider'',''sand_iam_policy'',''sand_iam_application_business_action'']'), ('sand_iam_identity_group_role', 'sand_iam_identity_group_role_pkey', 'p', 'PRIMARY KEY (id)', NULL), ('sand_iam_identity_group_role', 'uk_sand_iam_identity_group_role', 'u', 'UNIQUE (identity_group_id, role_id)', NULL), ('sand_iam_identity_group_role', 'fk_sand_iam_group_role_group_app', 'f', 'FOREIGN KEY (identity_group_id, application_id) REFERENCES sand_iam_identity_group(id, application_id) ON DELETE RESTRICT', NULL), ('sand_iam_identity_group_role', 'fk_sand_iam_group_role_role_app', 'f', 'FOREIGN KEY (role_id, application_id) REFERENCES sand_iam_role(id, application_id) ON DELETE RESTRICT', NULL) ) SELECT count(*) INTO matched_columns FROM required_constraint expected JOIN pg_constraint actual_constraint ON actual_constraint.conname = expected.constraint_name AND actual_constraint.contype = expected.constraint_type JOIN pg_class actual_table ON actual_table.oid = actual_constraint.conrelid JOIN pg_namespace actual_schema ON actual_schema.oid = actual_table.relnamespace WHERE actual_schema.nspname = current_schema() AND actual_table.relname = expected.table_name AND actual_constraint.convalidated = CASE WHEN expected.constraint_name IN ('ck_sand_iam_service_grant_data_class', 'ck_sand_iam_service_grant_quota_object') THEN false ELSE true END AND ( (expected.constraint_type <> 'c' AND pg_get_constraintdef(actual_constraint.oid, true) = expected.definition_token) OR (expected.constraint_type = 'c' AND regexp_replace(regexp_replace(regexp_replace(regexp_replace(lower(pg_get_constraintdef(actual_constraint.oid, true)), E'\\s+not\\s+valid$', '', 'g'), E'::[a-z_][a-z0-9_]*(\\s+varying)?(\\[\\])?', '', 'g'), E'\\s+', '', 'g'), '[()]', '', 'g') = expected.normalized_check_definition) ); IF matched_columns <> 30 THEN RAISE EXCEPTION 'SandIAM migration ledger refuses baseline adoption: scoped constraint definition fingerprint is incompatible (matched %/30)', matched_columns; END IF; WITH required_ledger_column(column_name, data_type, character_maximum_length, is_nullable, requires_default) AS ( VALUES ('migration_file', 'character varying', 160, 'NO', false), ('revision', 'smallint', NULL, 'NO', false), ('checksum', 'character', 64, 'NO', false), ('package_version', 'character varying', 32, 'NO', false), ('executed_time', 'timestamp without time zone', NULL, 'NO', true) ) SELECT count(*), count(column_info.column_name) INTO ledger_columns, matched_ledger_columns FROM required_ledger_column expected LEFT JOIN information_schema.columns column_info ON column_info.table_schema = current_schema() AND column_info.table_name = 'sand_iam_schema_migration' AND column_info.column_name = expected.column_name AND column_info.data_type = expected.data_type AND column_info.character_maximum_length IS NOT DISTINCT FROM expected.character_maximum_length AND column_info.is_nullable = expected.is_nullable AND (NOT expected.requires_default OR column_info.column_default IS NOT NULL); IF matched_ledger_columns <> ledger_columns OR NOT EXISTS ( SELECT 1 FROM pg_constraint ledger_pk JOIN pg_class ledger_table ON ledger_table.oid = ledger_pk.conrelid JOIN pg_namespace ledger_schema ON ledger_schema.oid = ledger_table.relnamespace WHERE ledger_schema.nspname = current_schema() AND ledger_table.relname = 'sand_iam_schema_migration' AND ledger_pk.contype = 'p' AND pg_get_constraintdef(ledger_pk.oid, true) = 'PRIMARY KEY (migration_file)' ) OR NOT EXISTS ( SELECT 1 FROM pg_constraint ledger_revision JOIN pg_class ledger_table ON ledger_table.oid = ledger_revision.conrelid JOIN pg_namespace ledger_schema ON ledger_schema.oid = ledger_table.relnamespace WHERE ledger_schema.nspname = current_schema() AND ledger_table.relname = 'sand_iam_schema_migration' AND ledger_revision.conname = 'ck_sand_iam_schema_migration_revision' AND ledger_revision.contype = 'c' AND ledger_revision.convalidated AND regexp_replace(regexp_replace(regexp_replace(lower(pg_get_constraintdef(ledger_revision.oid, true)), E'::[a-z_][a-z0-9_]*(\\s+varying)?(\\[\\])?', '', 'g'), E'\\s+', '', 'g'), '[()]', '', 'g') = 'checkrevision>=1andrevision<=999' ) OR NOT EXISTS ( SELECT 1 FROM pg_constraint ledger_checksum JOIN pg_class ledger_table ON ledger_table.oid = ledger_checksum.conrelid JOIN pg_namespace ledger_schema ON ledger_schema.oid = ledger_table.relnamespace WHERE ledger_schema.nspname = current_schema() AND ledger_table.relname = 'sand_iam_schema_migration' AND ledger_checksum.conname = 'ck_sand_iam_schema_migration_checksum' AND ledger_checksum.contype = 'c' AND ledger_checksum.convalidated AND regexp_replace(regexp_replace(regexp_replace(lower(pg_get_constraintdef(ledger_checksum.oid, true)), E'::[a-z_][a-z0-9_]*(\\s+varying)?(\\[\\])?', '', 'g'), E'\\s+', '', 'g'), '[()]', '', 'g') = 'checkchecksum~''^[0-9a-f]{64}$''' ) THEN RAISE EXCEPTION 'SandIAM migration ledger table definition is incompatible'; END IF; IF EXISTS ( WITH required_group_role_permission(code) AS ( VALUES ('sand_iam:identity_group_role:index'), ('sand_iam:identity_group_role:grant'), ('sand_iam:identity_group_role:revoke') ) SELECT required.code FROM required_group_role_permission required LEFT JOIN sand_system_menu permission_menu ON permission_menu.code = required.code LEFT JOIN sand_system_menu parent_menu ON parent_menu.id = permission_menu.parent_id GROUP BY required.code HAVING count(permission_menu.id) <> 1 OR bool_or(parent_menu.code IS DISTINCT FROM 'SandIAMPeopleAccess' OR permission_menu.slug IS DISTINCT FROM required.code OR permission_menu.type IS DISTINCT FROM 3) ) THEN RAISE EXCEPTION 'SandIAM migration ledger refuses baseline adoption: 034 permission catalog fingerprint is incompatible'; END IF; WITH frozen_permission_group(resource_code, actions) AS ( VALUES ('admin_application_grant', ARRAY['index','read','save','update','disable']::text[]), ('application_experience', ARRAY['index','read','save','update','disable']::text[]), ('message_provider', ARRAY['index','read','save','update','configure','test','disable']::text[]), ('message_provider_mount', ARRAY['index','save','disable']::text[]), ('initialization', ARRAY['index','read','preview','apply','rollback','export']::text[]), ('onboarding', ARRAY['preview','apply']::text[]), ('api_resource', ARRAY['index','read','save','update','disable']::text[]), ('api_route_binding', ARRAY['index','read','save','update','disable']::text[]), ('cas_service', ARRAY['index','read','save','update','disable']::text[]), ('identity', ARRAY['enable','delete','restore']::text[]), ('identity_export', ARRAY['masked','sensitive']::text[]), ('identity_group', ARRAY['index','read','save','update','disable']::text[]), ('identity_group_member', ARRAY['index','add','remove']::text[]), ('identity_import', ARRAY['index','read','preview','confirm']::text[]), ('identity_invitation', ARRAY['index','read','send','resend','revoke']::text[]), ('oauth_registration_token', ARRAY['index','issue','revoke']::text[]), ('radius_nas', ARRAY['index','read','save','update','configure','disable']::text[]), ('sync_connector', ARRAY['index','read','save','update','configure','test','disable']::text[]), ('sync_run', ARRAY['index','run']::text[]), ('audit', ARRAY['export']::text[]), ('application_network_policy', ARRAY['index','read','save','update','disable']::text[]), ('audit_retention_policy', ARRAY['index','read','save','update','disable']::text[]), ('developer', ARRAY['openapi','events']::text[]), ('security_alert', ARRAY['index','read','resolve']::text[]), ('webhook', ARRAY['index','read','save','update','disable']::text[]), ('webhook_delivery', ARRAY['index','read','retry']::text[]) ), frozen_permission_code(code) AS ( SELECT 'sand_iam:' || permission_group.resource_code || ':' || action.code FROM frozen_permission_group permission_group CROSS JOIN LATERAL unnest(permission_group.actions) AS action(code) ) SELECT count(*) INTO matched_columns FROM frozen_permission_code expected JOIN sand_system_menu actual ON actual.code = expected.code AND actual.type = 3; IF matched_columns <> 107 OR EXISTS ( WITH frozen_permission_group(resource_code, actions) AS ( VALUES ('admin_application_grant', ARRAY['index','read','save','update','disable']::text[]), ('application_experience', ARRAY['index','read','save','update','disable']::text[]), ('message_provider', ARRAY['index','read','save','update','configure','test','disable']::text[]), ('message_provider_mount', ARRAY['index','save','disable']::text[]), ('initialization', ARRAY['index','read','preview','apply','rollback','export']::text[]), ('onboarding', ARRAY['preview','apply']::text[]), ('api_resource', ARRAY['index','read','save','update','disable']::text[]), ('api_route_binding', ARRAY['index','read','save','update','disable']::text[]), ('cas_service', ARRAY['index','read','save','update','disable']::text[]), ('identity', ARRAY['enable','delete','restore']::text[]), ('identity_export', ARRAY['masked','sensitive']::text[]), ('identity_group', ARRAY['index','read','save','update','disable']::text[]), ('identity_group_member', ARRAY['index','add','remove']::text[]), ('identity_import', ARRAY['index','read','preview','confirm']::text[]), ('identity_invitation', ARRAY['index','read','send','resend','revoke']::text[]), ('oauth_registration_token', ARRAY['index','issue','revoke']::text[]), ('radius_nas', ARRAY['index','read','save','update','configure','disable']::text[]), ('sync_connector', ARRAY['index','read','save','update','configure','test','disable']::text[]), ('sync_run', ARRAY['index','run']::text[]), ('audit', ARRAY['export']::text[]), ('application_network_policy', ARRAY['index','read','save','update','disable']::text[]), ('audit_retention_policy', ARRAY['index','read','save','update','disable']::text[]), ('developer', ARRAY['openapi','events']::text[]), ('security_alert', ARRAY['index','read','resolve']::text[]), ('webhook', ARRAY['index','read','save','update','disable']::text[]), ('webhook_delivery', ARRAY['index','read','retry']::text[]) ), frozen_permission_code(code) AS ( SELECT 'sand_iam:' || permission_group.resource_code || ':' || action.code FROM frozen_permission_group permission_group CROSS JOIN LATERAL unnest(permission_group.actions) AS action(code) ) SELECT expected.code FROM frozen_permission_code expected LEFT JOIN sand_system_menu actual ON actual.code = expected.code AND actual.type = 3 GROUP BY expected.code HAVING count(actual.id) <> 1 ) THEN RAISE EXCEPTION 'SandIAM migration ledger refuses baseline adoption: immutable 021 permission code set is absent or not unique'; END IF; IF NOT EXISTS ( SELECT 1 FROM pg_constraint baseline_constraint JOIN pg_class baseline_table ON baseline_table.oid = baseline_constraint.conrelid JOIN pg_namespace baseline_schema ON baseline_schema.oid = baseline_table.relnamespace WHERE baseline_schema.nspname = current_schema() AND baseline_table.relname = 'sand_iam_identity_group_role' AND baseline_constraint.conname = 'uk_sand_iam_identity_group_role' AND baseline_constraint.contype = 'u' AND pg_get_constraintdef(baseline_constraint.oid, true) = 'UNIQUE (identity_group_id, role_id)' ) OR NOT EXISTS ( SELECT 1 FROM pg_index baseline_index JOIN pg_class index_relation ON index_relation.oid = baseline_index.indexrelid JOIN pg_class indexed_table ON indexed_table.oid = baseline_index.indrelid JOIN pg_namespace indexed_schema ON indexed_schema.oid = indexed_table.relnamespace WHERE indexed_schema.nspname = current_schema() AND indexed_table.relname = 'sand_iam_role' AND index_relation.relname = 'ux_sand_iam_role_id_application' AND baseline_index.indisunique AND baseline_index.indisvalid AND baseline_index.indisready AND pg_get_indexdef(baseline_index.indexrelid, 1, true) = 'id' AND pg_get_indexdef(baseline_index.indexrelid, 2, true) = 'application_id' ) THEN RAISE EXCEPTION 'SandIAM migration ledger refuses baseline adoption: constraint or index definition fingerprint is incompatible'; END IF; CREATE TEMPORARY TABLE IF NOT EXISTS sand_iam_schema_migration_expected ( migration_file varchar(160) PRIMARY KEY, revision smallint NOT NULL, checksum char(64) NOT NULL, package_version varchar(32) NOT NULL ) ON COMMIT DROP; WITH self_checksum(checksum) AS (VALUES ('7365abe0bbaa0134c018a291a65a4a420b2b145e0c7c3d184ac0123405ae0e12')), expected(migration_file, revision, checksum, package_version) AS ( VALUES ('001_iam04_admin_organization_grant.pgsql', 1, 'd214397c680631150f4cc1199d0af27063e968211b13b24a1e857ec9f0ceb5f6', '0.6.0'), ('002_identity_provider_scope.pgsql', 2, '92e2623876d251b8720303f573a88931765bc14db6c2f12a983fbb0d0084150a', '0.6.0'), ('003_human_auth_core.pgsql', 3, 'c75be4675a56dfe628a69ba7b2188450c1db88d0770672df0e6ddc1645e8ea50', '0.6.0'), ('004_mfa_passkey.pgsql', 4, 'e4c2a2b10650cc02d8b654746e4520912326609fad9675d93c6222de09accce3', '0.6.0'), ('005_oauth_oidc.pgsql', 5, 'de3e4f34a6e78b73179d62036788c1022c5557b08ca9671b2389a3ea1755ea62', '0.6.0'), ('006_federation_directory_scim.pgsql', 6, '94fea592ac863ff133d61da2cb9b015b00410a8487053858cc8481d2bec6e709', '0.6.0'), ('006_federation_integrity.pgsql', 6, '14095610942f64ee2aa463d1673550596d2df489ec3f0dd0d48ace6041396081', '0.6.0'), ('007_federation_handoff.pgsql', 7, 'f729fcae6da3effc2ebf41d8ddccc7b71251730be770d2f879d101d23f44a481', '0.6.0'), ('008_api_governance.pgsql', 8, 'cc16eee10ad09b1049f4d2e2e128665295fd2f64b26c8a727d4e082bb641f008', '0.6.0'), ('009_admin_application_grant.pgsql', 9, '6dda3f9466f51008e405877b2ad47b646891d312808dbfe9c9ab496299e8e34f', '0.6.0'), ('010_webhook_delivery.pgsql', 10, 'fce2c626b7ca1f69e250a0fc3c6cc8450d18a183f837f14d21adab695791f4b1', '0.6.0'), ('011_application_experience_message_provider.pgsql', 11, '46a087d79e14965a16421990cf888d80e097f1eecbc090f3aea658ae418a203a', '0.6.0'), ('012_identity_lifecycle_group.pgsql', 12, '7b44c4d2d9005c72af2922330d74ae8b50bd17a9392fc229063e427f8abf8299', '0.6.0'), ('013_identity_invitation.pgsql', 13, 'd9fd0740ace8a2be088f200942db8a1c49a1a114013c786415d8bdd7a40b8643', '0.6.0'), ('014_identity_import_export.pgsql', 14, '038b35c57d375a1d083b733915da68386b2b4f97d83224382b203b80f2ae587b', '0.6.0'), ('015_identity_sync_connector.pgsql', 15, '3219bd7db6b6f596d0b0c1169350f26d21f82f16f58960527e4eb382c16f6bfd', '0.6.0'), ('016_oauth_dynamic_registration_logout.pgsql', 16, '6d510349490eb8135c8fb02b30df8c0abcfc98b57ba4545ce115d0752c4d05bd', '0.6.0'), ('017_cas_protocol.pgsql', 17, '6ded442269d9d22721d78e5ca340cc9b08efddcdadfbd2efd01b76a0319df2f6', '0.6.0'), ('018_radius_server.pgsql', 18, '5517787fe08af96a90b125ec72a77179a7f0b6fa575b6fb59009a1ce6f22532c', '0.6.0'), ('019_security_operations.pgsql', 19, 'c800d667cc2efc733822970e176b3727d7be2600207137fc080112c161f035a3', '0.6.0'), ('020_initialization_package.pgsql', 20, '54abcaebca1ef4c7dc8747bf0f0bf84ca9bda5fc3227eb2d5415767277a0f3f2', '0.6.0'), ('021_admin_permission_catalog.pgsql', 21, 'f263ec1450bbd15d883c1d5b0f3a0fcfd15db602df9d120b1049a0c4cc428db9', '0.6.0'), ('022_model_soft_delete_contract.pgsql', 22, 'cf9e02c62b19d7115d2b1c7418f7555abfc9f5d8438be485431f6b9b1ac90d0e', '0.6.0'), ('023_federation_protocol_constraint_alignment.pgsql', 23, 'c88792bb4732c9c9c7aae641619416db765239122d5237ca97b991b722df78fa', '0.6.0'), ('024_scim_group_member_lifecycle.pgsql', 24, 'b178d81ff2b8820b3255a4e74127dbca3dbd59ae38573eeeefd8e0d688df1342', '0.6.0'), ('025_message_provider_mount_scope_integrity.pgsql', 25, 'dcd3c5e360566bae1cbdce7a2f5b0307ac05a36b41ae136e1fb8123bbb166f03', '0.6.0'), ('026_sync_connector_scope_integrity.pgsql', 26, 'b052b80e781b439781251bee7064f7dde7cada40dd67169ed19c93b42a3e70ce', '0.6.0'), ('027_security_operation_idempotency.pgsql', 27, 'c0c9b57cef2ed4c4d0d61be923124363f728beda27b3b2863ffae11a8f47d128', '0.6.0'), ('028_application_business_action.pgsql', 28, 'cb14e237f3052bb8ab200bf7e59f3d9a3b186ca2d79cdfa686af5c3b5e81329a', '0.6.0'), ('029_policy_versioning.pgsql', 29, '53b27e150c504600a53357c020de602819fcc8d6d9f2ff1e67820ef6b36e3c12', '0.6.0'), ('030_service_grant_invocation_control.pgsql', 30, '9fa587065ae878777d191db10f62d2e6e0dd33a97d90edcee883b709081602bc', '0.6.0'), ('031_oidc_signing_key_rotation.pgsql', 31, '7ce71dca33ee220faf2ca12812c0d132dd4190ed4c3094eb69e10bf8fdb31f14', '0.6.0'), ('032_initialization_binding_application_business_action.pgsql', 32, '5d3f6f7893356167f51eac62fa667990dcae2aebc4f12c11c3ac8e88f87353cb', '0.6.0'), ('033_identity_group_role.pgsql', 33, '161352617d1e46205a2abbf3b074ab7276e9dd691d151b61a2d8d146de26fd68', '0.7.0'), ('034_identity_group_role_permission_catalog.pgsql', 34, '97ab44356d905eb0e1c13ca3101a3dd0b8a4af3264cecb81310e1f522dfc2485', '0.7.0'), ('036_acceptance_fixture_support.pgsql', 36, '403f0fbadaf54436b81d8ff9d9eb2c14cbe83b5a26c3d13594241f2b40e17a3b', '0.7.0'), ('037_initialization_draft.pgsql', 37, 'cf7013ee42f9bd6319e8c23524f274e382901af7fbb32fa947732cd8beeb640c', '0.7.0'), ('038_auth_rate_limit_retention.pgsql', 38, '2765bed31eb3a8c5e894c0758e80120f6926f90b4f5a1a9ea39609dd608fe2c3', '0.7.0') UNION ALL SELECT '035_schema_migration_ledger.pgsql', 35, self_checksum.checksum, '0.7.0' FROM self_checksum ) INSERT INTO pg_temp.sand_iam_schema_migration_expected (migration_file, revision, checksum, package_version) SELECT migration_file, revision, checksum, package_version FROM expected ON CONFLICT (migration_file) DO NOTHING; SELECT count(*) INTO expected_rows FROM pg_temp.sand_iam_schema_migration_expected; IF EXISTS ( SELECT 1 FROM sand_iam_schema_migration recorded LEFT JOIN pg_temp.sand_iam_schema_migration_expected expected ON expected.migration_file = recorded.migration_file WHERE expected.migration_file IS NULL ) THEN RAISE EXCEPTION 'SandIAM migration ledger contains an unknown migration filename; refusing to continue'; END IF; IF EXISTS ( SELECT 1 FROM sand_iam_schema_migration recorded JOIN pg_temp.sand_iam_schema_migration_expected expected ON expected.migration_file = recorded.migration_file WHERE recorded.revision <> expected.revision OR recorded.checksum <> expected.checksum OR recorded.package_version <> expected.package_version ) THEN RAISE EXCEPTION 'SandIAM migration ledger checksum or package-version conflict; refusing to continue'; END IF; SELECT count(*) INTO recorded_rows FROM sand_iam_schema_migration recorded JOIN pg_temp.sand_iam_schema_migration_expected expected ON expected.migration_file = recorded.migration_file; IF recorded_rows = 0 THEN INSERT INTO sand_iam_schema_migration (migration_file, revision, checksum, package_version, executed_time) SELECT migration_file, revision, checksum, package_version, CURRENT_TIMESTAMP FROM pg_temp.sand_iam_schema_migration_expected WHERE revision <= 35; ELSIF NOT ( (recorded_rows = expected_rows AND total_recorded_rows = expected_rows) OR ( recorded_rows = expected_rows - 1 AND total_recorded_rows = expected_rows - 1 AND NOT EXISTS ( SELECT 1 FROM pg_temp.sand_iam_schema_migration_expected expected LEFT JOIN sand_iam_schema_migration recorded ON recorded.migration_file = expected.migration_file WHERE expected.revision <= 35 AND recorded.migration_file IS NULL ) AND EXISTS (SELECT 1 FROM sand_iam_schema_migration WHERE revision = 37) AND NOT EXISTS (SELECT 1 FROM sand_iam_schema_migration WHERE revision = 38) ) OR ( recorded_rows = expected_rows - 2 AND total_recorded_rows = expected_rows - 2 AND NOT EXISTS ( SELECT 1 FROM pg_temp.sand_iam_schema_migration_expected expected LEFT JOIN sand_iam_schema_migration recorded ON recorded.migration_file = expected.migration_file WHERE expected.revision <= 35 AND recorded.migration_file IS NULL ) AND EXISTS (SELECT 1 FROM sand_iam_schema_migration WHERE revision = 36) AND NOT EXISTS (SELECT 1 FROM sand_iam_schema_migration WHERE revision IN (37, 38)) ) OR ( recorded_rows = expected_rows - 3 AND total_recorded_rows = expected_rows - 3 AND NOT EXISTS ( SELECT 1 FROM pg_temp.sand_iam_schema_migration_expected expected LEFT JOIN sand_iam_schema_migration recorded ON recorded.migration_file = expected.migration_file WHERE expected.revision <= 35 AND recorded.migration_file IS NULL ) AND NOT EXISTS (SELECT 1 FROM sand_iam_schema_migration WHERE revision IN (36, 37, 38)) ) ) THEN RAISE EXCEPTION 'SandIAM migration ledger is partial; refusing to adopt or overwrite missing baseline records'; END IF; END $$;

COMMIT;

-- lifecycle source: migrations/036_acceptance_fixture_support.pgsql
-- SandIAM 0.7.0: controlled acceptance-fixture cleanup support.
-- This migration does not grant either permission to an existing role. It
-- also keeps audit rows while allowing their fixture parents to be purged.
BEGIN;

DO $$ DECLARE nullable_columns integer; organization_fk text; application_fk text; ledger_rows integer; migration_row record; BEGIN SELECT count(*) INTO nullable_columns FROM information_schema.columns WHERE table_schema = current_schema() AND table_name = 'sand_iam_audit_log' AND column_name IN ('organization_id', 'application_id') AND data_type = 'bigint' AND is_nullable = 'YES'; IF nullable_columns <> 2 THEN RAISE EXCEPTION 'SandIAM 0.7.0 cannot enable acceptance cleanup: nullable audit ownership columns are incompatible'; END IF; SELECT pg_get_constraintdef(constraint_row.oid, true) INTO organization_fk FROM pg_constraint constraint_row JOIN pg_class table_row ON table_row.oid = constraint_row.conrelid JOIN pg_namespace schema_row ON schema_row.oid = table_row.relnamespace WHERE schema_row.nspname = current_schema() AND table_row.relname = 'sand_iam_audit_log' AND constraint_row.conname = 'sand_iam_audit_log_organization_id_fkey' AND constraint_row.contype = 'f'; SELECT pg_get_constraintdef(constraint_row.oid, true) INTO application_fk FROM pg_constraint constraint_row JOIN pg_class table_row ON table_row.oid = constraint_row.conrelid JOIN pg_namespace schema_row ON schema_row.oid = table_row.relnamespace WHERE schema_row.nspname = current_schema() AND table_row.relname = 'sand_iam_audit_log' AND constraint_row.conname = 'sand_iam_audit_log_application_id_fkey' AND constraint_row.contype = 'f'; IF organization_fk NOT IN ( 'FOREIGN KEY (organization_id) REFERENCES sand_iam_organization(id) ON DELETE RESTRICT', 'FOREIGN KEY (organization_id) REFERENCES sand_iam_organization(id) ON DELETE SET NULL' ) OR application_fk NOT IN ( 'FOREIGN KEY (application_id) REFERENCES sand_iam_application(id) ON DELETE RESTRICT', 'FOREIGN KEY (application_id) REFERENCES sand_iam_application(id) ON DELETE SET NULL' ) THEN RAISE EXCEPTION 'SandIAM 0.7.0 cannot enable acceptance cleanup: audit ownership foreign-key fingerprint is incompatible'; END IF; SELECT count(*) INTO ledger_rows FROM sand_iam_schema_migration; IF ledger_rows NOT IN (36, 37, 38) THEN RAISE EXCEPTION 'SandIAM 0.7.0 acceptance cleanup requires the exact migration 001-035 ledger prefix'; END IF; SELECT migration_file, revision, package_version INTO migration_row FROM sand_iam_schema_migration WHERE migration_file = '035_schema_migration_ledger.pgsql'; IF migration_row.migration_file IS NULL OR migration_row.revision <> 35 OR migration_row.package_version <> '0.7.0' THEN RAISE EXCEPTION 'SandIAM 0.7.0 acceptance cleanup requires the verified migration 035 ledger'; END IF; END $$;

DO $$ DECLARE organization_fk text; application_fk text; BEGIN SELECT pg_get_constraintdef(constraint_row.oid, true) INTO organization_fk FROM pg_constraint constraint_row JOIN pg_class table_row ON table_row.oid = constraint_row.conrelid JOIN pg_namespace schema_row ON schema_row.oid = table_row.relnamespace WHERE schema_row.nspname = current_schema() AND table_row.relname = 'sand_iam_audit_log' AND constraint_row.conname = 'sand_iam_audit_log_organization_id_fkey'; IF organization_fk = 'FOREIGN KEY (organization_id) REFERENCES sand_iam_organization(id) ON DELETE RESTRICT' THEN ALTER TABLE sand_iam_audit_log DROP CONSTRAINT sand_iam_audit_log_organization_id_fkey; ALTER TABLE sand_iam_audit_log ADD CONSTRAINT sand_iam_audit_log_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES sand_iam_organization(id) ON DELETE SET NULL; END IF; SELECT pg_get_constraintdef(constraint_row.oid, true) INTO application_fk FROM pg_constraint constraint_row JOIN pg_class table_row ON table_row.oid = constraint_row.conrelid JOIN pg_namespace schema_row ON schema_row.oid = table_row.relnamespace WHERE schema_row.nspname = current_schema() AND table_row.relname = 'sand_iam_audit_log' AND constraint_row.conname = 'sand_iam_audit_log_application_id_fkey'; IF application_fk = 'FOREIGN KEY (application_id) REFERENCES sand_iam_application(id) ON DELETE RESTRICT' THEN ALTER TABLE sand_iam_audit_log DROP CONSTRAINT sand_iam_audit_log_application_id_fkey; ALTER TABLE sand_iam_audit_log ADD CONSTRAINT sand_iam_audit_log_application_id_fkey FOREIGN KEY (application_id) REFERENCES sand_iam_application(id) ON DELETE SET NULL; END IF; END $$;

DO $$ DECLARE root_menu_id bigint; root_menu_count integer; developer_menu_id bigint; developer_parent_id bigint; developer_menu_count integer; BEGIN SELECT count(*), min(id) INTO root_menu_count, root_menu_id FROM sand_system_menu WHERE code = 'SandIAM'; IF root_menu_count <> 1 THEN RAISE EXCEPTION 'SandIAM 0.7.0 cannot add developer access: root menu SandIAM must be unique'; END IF; SELECT count(*), min(id), min(parent_id) INTO developer_menu_count, developer_menu_id, developer_parent_id FROM sand_system_menu WHERE code = 'SandIAMDeveloperDocs'; IF developer_menu_count > 1 THEN RAISE EXCEPTION 'SandIAM 0.7.0 cannot add developer access: menu SandIAMDeveloperDocs is duplicated'; END IF; IF developer_menu_count = 1 AND developer_parent_id IS DISTINCT FROM root_menu_id THEN RAISE EXCEPTION 'SandIAM 0.7.0 cannot add developer access: menu SandIAMDeveloperDocs has incompatible ownership'; END IF; IF developer_menu_count = 0 THEN INSERT INTO sand_system_menu (parent_id, name, code, slug, type, path, component, icon, sort, is_hidden, status, create_time, update_time) VALUES (root_menu_id, '开发者接入', 'SandIAMDeveloperDocs', '', 2, 'developer-docs', '/plugin/sand-iam/developer-docs/index', '', 56, 1, 1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP); ELSE UPDATE sand_system_menu SET name = '开发者接入', slug = '', type = 2, path = 'developer-docs', component = '/plugin/sand-iam/developer-docs/index', icon = '', sort = 56, is_hidden = 1, status = 1, update_time = CURRENT_TIMESTAMP WHERE id = developer_menu_id; END IF; END $$;

DO $$ DECLARE parent_menu_id bigint; BEGIN SELECT id INTO parent_menu_id FROM sand_system_menu WHERE code = 'SandIAMDeveloperDocs' ORDER BY id LIMIT 1; IF parent_menu_id IS NULL THEN RAISE EXCEPTION 'SandIAM 0.7.0 cannot add acceptance-fixture permissions: parent menu SandIAMDeveloperDocs is missing'; END IF; END $$;

WITH desired(code, name, sort) AS (
    VALUES
        ('sand_iam:acceptance_fixture:cleanup', '清理验收数据', 1881),
        ('sand_iam:acceptance_fixture:read', '查看验收数据状态', 1882)
), parent AS (
    SELECT id
    FROM sand_system_menu
    WHERE code = 'SandIAMDeveloperDocs'
    ORDER BY id
    LIMIT 1
), refresh_existing AS (
    UPDATE sand_system_menu existing
    SET parent_id = parent.id,
        name = desired.name,
        slug = desired.code,
        type = 3,
        path = '',
        component = '',
        icon = '',
        sort = desired.sort,
        is_hidden = 1,
        status = 1,
        update_time = CURRENT_TIMESTAMP
    FROM desired
    CROSS JOIN parent
    WHERE existing.code = desired.code
      AND (
          existing.parent_id IS DISTINCT FROM parent.id
          OR existing.name IS DISTINCT FROM desired.name
          OR existing.slug IS DISTINCT FROM desired.code
          OR existing.type IS DISTINCT FROM 3
          OR existing.path IS DISTINCT FROM ''
          OR existing.component IS DISTINCT FROM ''
          OR existing.icon IS DISTINCT FROM ''
          OR existing.sort IS DISTINCT FROM desired.sort
          OR existing.is_hidden IS DISTINCT FROM 1
          OR existing.status IS DISTINCT FROM 1
      )
    RETURNING existing.id
)
INSERT INTO sand_system_menu (parent_id, name, code, slug, type, path, component, icon, sort, is_hidden, status, create_time, update_time)
SELECT parent.id, desired.name, desired.code, desired.code,
       3, '', '', '', desired.sort, 1, 1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP
FROM desired
CROSS JOIN parent
WHERE NOT EXISTS (
    SELECT 1
    FROM sand_system_menu existing
    WHERE existing.code = desired.code
);

DO $$ DECLARE matched_permissions integer; BEGIN WITH desired(code, name, sort) AS ( VALUES ('sand_iam:acceptance_fixture:cleanup', '清理验收数据', 1881), ('sand_iam:acceptance_fixture:read', '查看验收数据状态', 1882) ), parent AS ( SELECT id FROM sand_system_menu WHERE code = 'SandIAMDeveloperDocs' ORDER BY id LIMIT 1 ) SELECT count(*) INTO matched_permissions FROM desired CROSS JOIN parent JOIN sand_system_menu actual ON actual.code = desired.code AND actual.parent_id = parent.id AND actual.name = desired.name AND actual.slug = desired.code AND actual.type = 3 AND actual.path = '' AND actual.component = '' AND actual.icon = '' AND actual.sort = desired.sort AND actual.is_hidden = 1 AND actual.status = 1; IF matched_permissions <> 2 OR EXISTS ( SELECT required.code FROM (VALUES ('sand_iam:acceptance_fixture:cleanup'), ('sand_iam:acceptance_fixture:read') ) AS required(code) LEFT JOIN sand_system_menu actual ON actual.code = required.code GROUP BY required.code HAVING count(actual.id) <> 1 ) THEN RAISE EXCEPTION 'SandIAM 0.7.0 acceptance-fixture permission fingerprint is incompatible'; END IF; IF EXISTS ( SELECT 1 FROM pg_constraint constraint_row JOIN pg_class table_row ON table_row.oid = constraint_row.conrelid JOIN pg_namespace schema_row ON schema_row.oid = table_row.relnamespace WHERE schema_row.nspname = current_schema() AND table_row.relname = 'sand_iam_audit_log' AND constraint_row.conname IN ( 'sand_iam_audit_log_organization_id_fkey', 'sand_iam_audit_log_application_id_fkey' ) AND pg_get_constraintdef(constraint_row.oid, true) NOT LIKE '% ON DELETE SET NULL' ) THEN RAISE EXCEPTION 'SandIAM 0.7.0 acceptance cleanup did not preserve audit rows with nullable ownership links'; END IF; END $$;

DO $$ DECLARE recorded record; BEGIN SELECT revision, checksum, package_version INTO recorded FROM sand_iam_schema_migration WHERE migration_file = '036_acceptance_fixture_support.pgsql'; IF recorded.revision IS NOT NULL AND ( recorded.revision <> 36 OR recorded.checksum <> '403f0fbadaf54436b81d8ff9d9eb2c14cbe83b5a26c3d13594241f2b40e17a3b' OR recorded.package_version <> '0.7.0' ) THEN RAISE EXCEPTION 'SandIAM migration 036 ledger identity conflicts with the controlled acceptance-fixture support'; END IF; END $$;

WITH self_checksum(checksum) AS (VALUES ('403f0fbadaf54436b81d8ff9d9eb2c14cbe83b5a26c3d13594241f2b40e17a3b'))
INSERT INTO sand_iam_schema_migration (migration_file, revision, checksum, package_version, executed_time)
SELECT '036_acceptance_fixture_support.pgsql', 36, self_checksum.checksum, '0.7.0', CURRENT_TIMESTAMP
FROM self_checksum
ON CONFLICT (migration_file) DO NOTHING;

DO $$ DECLARE recorded_rows integer; BEGIN SELECT count(*) INTO recorded_rows FROM sand_iam_schema_migration WHERE migration_file = '036_acceptance_fixture_support.pgsql' AND revision = 36 AND checksum = '403f0fbadaf54436b81d8ff9d9eb2c14cbe83b5a26c3d13594241f2b40e17a3b' AND package_version = '0.7.0'; IF recorded_rows <> 1 OR (SELECT count(*) FROM sand_iam_schema_migration) NOT IN (37, 38) THEN RAISE EXCEPTION 'SandIAM migration 036 did not close the exact 001-036 ledger'; END IF; END $$;

COMMIT;

-- lifecycle source: migrations/037_initialization_draft.pgsql
-- SandIAM 0.7.0: editable, secret-free initialization drafts.
-- Applied initialization runs remain immutable rollback evidence.
-- These permissions are cataloged only. Existing roles are never granted them
-- automatically because initialization changes require an explicit administrator decision.
BEGIN;

DO $$ DECLARE application_ownership_key text; BEGIN SELECT pg_get_constraintdef(constraint_row.oid, true) INTO application_ownership_key FROM pg_constraint constraint_row JOIN pg_class table_row ON table_row.oid = constraint_row.conrelid JOIN pg_namespace schema_row ON schema_row.oid = table_row.relnamespace WHERE schema_row.nspname = current_schema() AND table_row.relname = 'sand_iam_application' AND constraint_row.conname = 'uk_sand_iam_application_id_organization' AND constraint_row.contype = 'u'; IF application_ownership_key IS DISTINCT FROM 'UNIQUE (id, organization_id)' THEN RAISE EXCEPTION 'SandIAM initialization drafts require the exact sand_iam_application ownership key'; END IF; END $$;

CREATE TABLE IF NOT EXISTS sand_iam_initialization_draft (
    id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    organization_id bigint NOT NULL REFERENCES sand_iam_organization(id) ON DELETE RESTRICT,
    application_id bigint NULL,
    package_code varchar(64) NOT NULL,
    manifest jsonb NOT NULL,
    manifest_hash char(64) NOT NULL,
    revision integer NOT NULL DEFAULT 1,
    status smallint NOT NULL DEFAULT 1,
    created_by bigint NOT NULL,
    updated_by bigint NOT NULL,
    disabled_by bigint NULL,
    disabled_time timestamp(0) without time zone NULL,
    create_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_sand_iam_initialization_draft_application_organization
        FOREIGN KEY (application_id, organization_id)
        REFERENCES sand_iam_application(id, organization_id) ON DELETE RESTRICT,
    CONSTRAINT uk_sand_iam_initialization_draft_organization_package UNIQUE (organization_id, package_code),
    CONSTRAINT ck_sand_iam_initialization_draft_code CHECK (package_code ~ '^[a-z0-9][a-z0-9_-]{1,63}$'),
    CONSTRAINT ck_sand_iam_initialization_draft_hash CHECK (manifest_hash ~ '^[a-f0-9]{64}$'),
    CONSTRAINT ck_sand_iam_initialization_draft_revision CHECK (revision >= 1),
    CONSTRAINT ck_sand_iam_initialization_draft_status CHECK (status IN (1, 2))
);

CREATE INDEX IF NOT EXISTS idx_sand_iam_initialization_draft_application
    ON sand_iam_initialization_draft(organization_id, application_id, status, update_time DESC);
CREATE INDEX IF NOT EXISTS idx_sand_iam_initialization_draft_organization
    ON sand_iam_initialization_draft(organization_id, status, update_time DESC);

CREATE TABLE IF NOT EXISTS sand_iam_initialization_draft_revision (
    id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    draft_id bigint NOT NULL REFERENCES sand_iam_initialization_draft(id) ON DELETE RESTRICT,
    revision integer NOT NULL,
    manifest jsonb NOT NULL,
    manifest_hash char(64) NOT NULL,
    status smallint NOT NULL,
    action varchar(16) NOT NULL,
    actor_id bigint NOT NULL,
    request_id varchar(96) NOT NULL,
    create_time timestamp(0) without time zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uk_sand_iam_initialization_draft_revision UNIQUE (draft_id, revision),
    CONSTRAINT ck_sand_iam_initialization_draft_revision_number CHECK (revision >= 1),
    CONSTRAINT ck_sand_iam_initialization_draft_revision_hash CHECK (manifest_hash ~ '^[a-f0-9]{64}$'),
    CONSTRAINT ck_sand_iam_initialization_draft_revision_status CHECK (status IN (1, 2)),
    CONSTRAINT ck_sand_iam_initialization_draft_revision_action CHECK (action IN ('created', 'updated', 'disabled', 'restored')),
    CONSTRAINT ck_sand_iam_initialization_draft_revision_request CHECK (request_id ~ '^[A-Za-z0-9][A-Za-z0-9_.:-]{7,95}$')
);

CREATE INDEX IF NOT EXISTS idx_sand_iam_initialization_draft_revision_history
    ON sand_iam_initialization_draft_revision(draft_id, create_time DESC);

DO $$ DECLARE actual_columns integer; matched_columns integer; matched_constraints integer; matched_indexes integer; index_evidence text; BEGIN SELECT count(*) INTO actual_columns FROM information_schema.columns WHERE table_schema = current_schema() AND table_name IN ('sand_iam_initialization_draft', 'sand_iam_initialization_draft_revision'); WITH required_column(table_name, column_name, data_type, character_maximum_length, is_nullable, requires_default) AS ( VALUES ('sand_iam_initialization_draft', 'id', 'bigint', NULL::integer, 'NO', false), ('sand_iam_initialization_draft', 'organization_id', 'bigint', NULL, 'NO', false), ('sand_iam_initialization_draft', 'application_id', 'bigint', NULL, 'YES', false), ('sand_iam_initialization_draft', 'package_code', 'character varying', 64, 'NO', false), ('sand_iam_initialization_draft', 'manifest', 'jsonb', NULL, 'NO', false), ('sand_iam_initialization_draft', 'manifest_hash', 'character', 64, 'NO', false), ('sand_iam_initialization_draft', 'revision', 'integer', NULL, 'NO', true), ('sand_iam_initialization_draft', 'status', 'smallint', NULL, 'NO', true), ('sand_iam_initialization_draft', 'created_by', 'bigint', NULL, 'NO', false), ('sand_iam_initialization_draft', 'updated_by', 'bigint', NULL, 'NO', false), ('sand_iam_initialization_draft', 'disabled_by', 'bigint', NULL, 'YES', false), ('sand_iam_initialization_draft', 'disabled_time', 'timestamp without time zone', NULL, 'YES', false), ('sand_iam_initialization_draft', 'create_time', 'timestamp without time zone', NULL, 'NO', true), ('sand_iam_initialization_draft', 'update_time', 'timestamp without time zone', NULL, 'NO', true), ('sand_iam_initialization_draft_revision', 'id', 'bigint', NULL, 'NO', false), ('sand_iam_initialization_draft_revision', 'draft_id', 'bigint', NULL, 'NO', false), ('sand_iam_initialization_draft_revision', 'revision', 'integer', NULL, 'NO', false), ('sand_iam_initialization_draft_revision', 'manifest', 'jsonb', NULL, 'NO', false), ('sand_iam_initialization_draft_revision', 'manifest_hash', 'character', 64, 'NO', false), ('sand_iam_initialization_draft_revision', 'status', 'smallint', NULL, 'NO', false), ('sand_iam_initialization_draft_revision', 'action', 'character varying', 16, 'NO', false), ('sand_iam_initialization_draft_revision', 'actor_id', 'bigint', NULL, 'NO', false), ('sand_iam_initialization_draft_revision', 'request_id', 'character varying', 96, 'NO', false), ('sand_iam_initialization_draft_revision', 'create_time', 'timestamp without time zone', NULL, 'NO', true) ) SELECT count(*) INTO matched_columns FROM required_column expected JOIN information_schema.columns actual ON actual.table_schema = current_schema() AND actual.table_name = expected.table_name AND actual.column_name = expected.column_name AND actual.data_type = expected.data_type AND actual.character_maximum_length IS NOT DISTINCT FROM expected.character_maximum_length AND actual.is_nullable = expected.is_nullable AND (NOT expected.requires_default OR actual.column_default IS NOT NULL); IF actual_columns <> 24 OR matched_columns <> 24 OR (SELECT count(*) FROM information_schema.columns WHERE table_schema = current_schema() AND table_name IN ('sand_iam_initialization_draft', 'sand_iam_initialization_draft_revision') AND column_name = 'id' AND is_identity = 'YES') <> 2 THEN RAISE EXCEPTION 'SandIAM initialization-draft column fingerprint is incompatible'; END IF; WITH required_constraint(table_name, constraint_name, constraint_type, definition_token, normalized_check_definition) AS ( VALUES ('sand_iam_initialization_draft', 'sand_iam_initialization_draft_pkey', 'p', 'PRIMARY KEY (id)', NULL), ('sand_iam_initialization_draft', 'sand_iam_initialization_draft_organization_id_fkey', 'f', 'FOREIGN KEY (organization_id) REFERENCES sand_iam_organization(id) ON DELETE RESTRICT', NULL), ('sand_iam_initialization_draft', 'fk_sand_iam_initialization_draft_application_organization', 'f', 'FOREIGN KEY (application_id, organization_id) REFERENCES sand_iam_application(id, organization_id) ON DELETE RESTRICT', NULL), ('sand_iam_initialization_draft', 'uk_sand_iam_initialization_draft_organization_package', 'u', 'UNIQUE (organization_id, package_code)', NULL), ('sand_iam_initialization_draft', 'ck_sand_iam_initialization_draft_code', 'c', NULL, 'checkpackage_code~''^[a-z0-9][a-z0-9_-]{1,63}$'''), ('sand_iam_initialization_draft', 'ck_sand_iam_initialization_draft_hash', 'c', NULL, 'checkmanifest_hash~''^[a-f0-9]{64}$'''), ('sand_iam_initialization_draft', 'ck_sand_iam_initialization_draft_revision', 'c', NULL, 'checkrevision>=1'), ('sand_iam_initialization_draft', 'ck_sand_iam_initialization_draft_status', 'c', NULL, 'checkstatus=anyarray[1,2]'), ('sand_iam_initialization_draft_revision', 'sand_iam_initialization_draft_revision_pkey', 'p', 'PRIMARY KEY (id)', NULL), ('sand_iam_initialization_draft_revision', 'sand_iam_initialization_draft_revision_draft_id_fkey', 'f', 'FOREIGN KEY (draft_id) REFERENCES sand_iam_initialization_draft(id) ON DELETE RESTRICT', NULL), ('sand_iam_initialization_draft_revision', 'uk_sand_iam_initialization_draft_revision', 'u', 'UNIQUE (draft_id, revision)', NULL), ('sand_iam_initialization_draft_revision', 'ck_sand_iam_initialization_draft_revision_number', 'c', NULL, 'checkrevision>=1'), ('sand_iam_initialization_draft_revision', 'ck_sand_iam_initialization_draft_revision_hash', 'c', NULL, 'checkmanifest_hash~''^[a-f0-9]{64}$'''), ('sand_iam_initialization_draft_revision', 'ck_sand_iam_initialization_draft_revision_status', 'c', NULL, 'checkstatus=anyarray[1,2]'), ('sand_iam_initialization_draft_revision', 'ck_sand_iam_initialization_draft_revision_action', 'c', NULL, 'checkaction=anyarray[''created'',''updated'',''disabled'',''restored'']'), ('sand_iam_initialization_draft_revision', 'ck_sand_iam_initialization_draft_revision_request', 'c', NULL, 'checkrequest_id~''^[a-za-z0-9][a-za-z0-9_.:-]{7,95}$''') ) SELECT count(*) INTO matched_constraints FROM required_constraint expected JOIN pg_constraint actual_constraint ON actual_constraint.conname = expected.constraint_name AND actual_constraint.contype = expected.constraint_type JOIN pg_class actual_table ON actual_table.oid = actual_constraint.conrelid JOIN pg_namespace actual_schema ON actual_schema.oid = actual_table.relnamespace WHERE actual_schema.nspname = current_schema() AND actual_table.relname = expected.table_name AND actual_constraint.convalidated AND ( (expected.constraint_type <> 'c' AND pg_get_constraintdef(actual_constraint.oid, true) = expected.definition_token) OR (expected.constraint_type = 'c' AND regexp_replace(regexp_replace(regexp_replace(lower(pg_get_constraintdef(actual_constraint.oid, true)), E'::[a-z_][a-z0-9_]*(\\s+varying)?(\\[\\])?', '', 'g'), E'\\s+', '', 'g'), '[()]', '', 'g') = expected.normalized_check_definition) ); IF matched_constraints <> 16 OR (SELECT count(*) FROM pg_constraint actual_constraint JOIN pg_class actual_table ON actual_table.oid = actual_constraint.conrelid JOIN pg_namespace actual_schema ON actual_schema.oid = actual_table.relnamespace WHERE actual_schema.nspname = current_schema() AND actual_table.relname IN ('sand_iam_initialization_draft', 'sand_iam_initialization_draft_revision') AND actual_constraint.contype IN ('p', 'f', 'u', 'c')) <> 16 THEN RAISE EXCEPTION 'SandIAM initialization-draft constraint fingerprint is incompatible (matched %/16)', matched_constraints; END IF; WITH required_index(table_name, index_name, first_key, second_key, third_key, fourth_key, index_options) AS ( VALUES ('sand_iam_initialization_draft', 'idx_sand_iam_initialization_draft_application', 'organization_id', 'application_id', 'status', 'update_time', '0 0 0 3'), ('sand_iam_initialization_draft', 'idx_sand_iam_initialization_draft_organization', 'organization_id', 'status', 'update_time', '', '0 0 3'), ('sand_iam_initialization_draft_revision', 'idx_sand_iam_initialization_draft_revision_history', 'draft_id', 'create_time', '', '', '0 3') ) SELECT count(*) INTO matched_indexes FROM required_index expected JOIN pg_class actual_table ON actual_table.relname = expected.table_name JOIN pg_namespace actual_schema ON actual_schema.oid = actual_table.relnamespace AND actual_schema.nspname = current_schema() JOIN pg_index actual_index ON actual_index.indrelid = actual_table.oid JOIN pg_class index_relation ON index_relation.oid = actual_index.indexrelid AND index_relation.relname = expected.index_name WHERE NOT actual_index.indisunique AND actual_index.indisvalid AND actual_index.indisready AND pg_get_indexdef(actual_index.indexrelid, 1, true) = expected.first_key AND pg_get_indexdef(actual_index.indexrelid, 2, true) = expected.second_key AND pg_get_indexdef(actual_index.indexrelid, 3, true) IS NOT DISTINCT FROM expected.third_key AND pg_get_indexdef(actual_index.indexrelid, 4, true) IS NOT DISTINCT FROM expected.fourth_key AND actual_index.indoption::text = expected.index_options; IF matched_indexes <> 3 THEN SELECT string_agg(index_relation.relname || '=' || coalesce(pg_get_indexdef(actual_index.indexrelid, 1, true), '<null>') || '|' || coalesce(pg_get_indexdef(actual_index.indexrelid, 2, true), '<null>') || '|' || coalesce(pg_get_indexdef(actual_index.indexrelid, 3, true), '<null>') || '|' || coalesce(pg_get_indexdef(actual_index.indexrelid, 4, true), '<null>'), ';' ORDER BY index_relation.relname) INTO index_evidence FROM pg_index actual_index JOIN pg_class actual_table ON actual_table.oid = actual_index.indrelid JOIN pg_namespace actual_schema ON actual_schema.oid = actual_table.relnamespace JOIN pg_class index_relation ON index_relation.oid = actual_index.indexrelid WHERE actual_schema.nspname = current_schema() AND index_relation.relname IN ('idx_sand_iam_initialization_draft_application', 'idx_sand_iam_initialization_draft_organization', 'idx_sand_iam_initialization_draft_revision_history'); RAISE EXCEPTION 'SandIAM initialization-draft index fingerprint is incompatible (matched %/3; actual %)', matched_indexes, index_evidence; END IF; END $$;

DO $$ DECLARE parent_menu_id bigint; BEGIN SELECT id INTO parent_menu_id FROM sand_system_menu WHERE code = 'SandIAMConnection' ORDER BY id LIMIT 1; IF parent_menu_id IS NULL THEN RAISE EXCEPTION 'SandIAM 0.7.0 cannot add initialization-draft permissions: parent menu SandIAMConnection is missing'; END IF; END $$;

WITH desired(code, name, sort) AS (
    VALUES
        ('sand_iam:initialization:save', '应用初始化方案新建草稿', 2027),
        ('sand_iam:initialization:update', '应用初始化方案编辑草稿', 2028),
        ('sand_iam:initialization:disable', '应用初始化方案停用草稿', 2029)
), parent AS (
    SELECT id FROM sand_system_menu WHERE code = 'SandIAMConnection' ORDER BY id LIMIT 1
), refresh_existing AS (
    UPDATE sand_system_menu existing
    SET parent_id = parent.id,
        name = desired.name,
        slug = desired.code,
        type = 3,
        path = '',
        component = '',
        icon = '',
        sort = desired.sort,
        is_hidden = 1,
        status = 1,
        update_time = CURRENT_TIMESTAMP
    FROM desired CROSS JOIN parent
    WHERE existing.code = desired.code
    RETURNING existing.id
)
INSERT INTO sand_system_menu (parent_id, name, code, slug, type, path, component, icon, sort, is_hidden, status, create_time, update_time)
SELECT parent.id, desired.name, desired.code, desired.code, 3, '', '', '', desired.sort, 1, 1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP
FROM desired CROSS JOIN parent
WHERE NOT EXISTS (SELECT 1 FROM sand_system_menu existing WHERE existing.code = desired.code);

DO $$ DECLARE matched_permissions integer; BEGIN WITH desired(code, name, sort) AS ( VALUES ('sand_iam:initialization:save', '应用初始化方案新建草稿', 2027), ('sand_iam:initialization:update', '应用初始化方案编辑草稿', 2028), ('sand_iam:initialization:disable', '应用初始化方案停用草稿', 2029) ), parent AS ( SELECT id FROM sand_system_menu WHERE code = 'SandIAMConnection' ORDER BY id LIMIT 1 ) SELECT count(*) INTO matched_permissions FROM desired CROSS JOIN parent JOIN sand_system_menu actual ON actual.code = desired.code AND actual.parent_id = parent.id AND actual.name = desired.name AND actual.slug = desired.code AND actual.type = 3 AND actual.path = '' AND actual.component = '' AND actual.icon = '' AND actual.sort = desired.sort AND actual.is_hidden = 1 AND actual.status = 1; IF matched_permissions <> 3 OR EXISTS ( SELECT required.code FROM (VALUES ('sand_iam:initialization:save'), ('sand_iam:initialization:update'), ('sand_iam:initialization:disable') ) AS required(code) LEFT JOIN sand_system_menu actual ON actual.code = required.code GROUP BY required.code HAVING count(actual.id) <> 1 ) THEN RAISE EXCEPTION 'SandIAM 0.7.0 initialization-draft permission fingerprint is incompatible'; END IF; END $$;

DO $$ DECLARE recorded record; BEGIN SELECT revision, checksum, package_version INTO recorded FROM sand_iam_schema_migration WHERE migration_file = '037_initialization_draft.pgsql'; IF recorded.revision IS NOT NULL AND ( recorded.revision <> 37 OR recorded.checksum <> 'cf7013ee42f9bd6319e8c23524f274e382901af7fbb32fa947732cd8beeb640c' OR recorded.package_version <> '0.7.0' ) THEN RAISE EXCEPTION 'SandIAM migration 037 ledger identity conflicts with initialization drafts'; END IF; END $$;

WITH self_checksum(checksum) AS (VALUES ('cf7013ee42f9bd6319e8c23524f274e382901af7fbb32fa947732cd8beeb640c'))
INSERT INTO sand_iam_schema_migration (migration_file, revision, checksum, package_version, executed_time)
SELECT '037_initialization_draft.pgsql', 37, self_checksum.checksum, '0.7.0', CURRENT_TIMESTAMP
FROM self_checksum
ON CONFLICT (migration_file) DO NOTHING;

DO $$ DECLARE recorded_rows integer; BEGIN SELECT count(*) INTO recorded_rows FROM sand_iam_schema_migration WHERE migration_file = '037_initialization_draft.pgsql' AND revision = 37 AND checksum = 'cf7013ee42f9bd6319e8c23524f274e382901af7fbb32fa947732cd8beeb640c' AND package_version = '0.7.0'; IF recorded_rows <> 1 OR (SELECT count(*) FROM sand_iam_schema_migration) <> 38 THEN RAISE EXCEPTION 'SandIAM migration 037 did not close the exact 001-037 ledger'; END IF; END $$;

COMMIT;

-- lifecycle source: migrations/038_auth_rate_limit_retention.pgsql
-- SandIAM 0.7.0: bounded cleanup access path for expired authentication
-- throttling state. The cleanup worker remains deployment opt-in.
BEGIN;

DO $$ DECLARE matched_columns integer; BEGIN WITH required_column(column_name, data_type, character_maximum_length, is_nullable) AS ( VALUES ('id', 'bigint', NULL::integer, 'NO'), ('window_start', 'timestamp without time zone', NULL, 'NO') ) SELECT count(*) INTO matched_columns FROM required_column expected JOIN information_schema.columns actual ON actual.table_schema = current_schema() AND actual.table_name = 'sand_iam_auth_rate_limit' AND actual.column_name = expected.column_name AND actual.data_type = expected.data_type AND actual.character_maximum_length IS NOT DISTINCT FROM expected.character_maximum_length AND actual.is_nullable = expected.is_nullable; IF matched_columns <> 2 THEN RAISE EXCEPTION 'SandIAM auth-rate-limit retention requires the exact id and window_start columns'; END IF; END $$;

CREATE INDEX IF NOT EXISTS idx_sand_iam_auth_rate_limit_retention
    ON sand_iam_auth_rate_limit(window_start, id);

DO $$ DECLARE matched_indexes integer; index_evidence text; BEGIN SELECT count(*) INTO matched_indexes FROM pg_index actual_index JOIN pg_class actual_table ON actual_table.oid = actual_index.indrelid JOIN pg_namespace actual_schema ON actual_schema.oid = actual_table.relnamespace JOIN pg_class index_relation ON index_relation.oid = actual_index.indexrelid WHERE actual_schema.nspname = current_schema() AND actual_table.relname = 'sand_iam_auth_rate_limit' AND index_relation.relname = 'idx_sand_iam_auth_rate_limit_retention' AND NOT actual_index.indisunique AND actual_index.indisvalid AND actual_index.indisready AND actual_index.indoption::text = '0 0' AND pg_get_indexdef(actual_index.indexrelid, 1, true) = 'window_start' AND pg_get_indexdef(actual_index.indexrelid, 2, true) = 'id' AND actual_index.indnatts = 2 AND actual_index.indnkeyatts = 2; IF matched_indexes <> 1 THEN SELECT pg_get_indexdef(actual_index.indexrelid) INTO index_evidence FROM pg_index actual_index JOIN pg_class index_relation ON index_relation.oid = actual_index.indexrelid JOIN pg_namespace actual_schema ON actual_schema.oid = index_relation.relnamespace WHERE actual_schema.nspname = current_schema() AND index_relation.relname = 'idx_sand_iam_auth_rate_limit_retention'; RAISE EXCEPTION 'SandIAM auth-rate-limit retention index fingerprint is incompatible (actual %)', index_evidence; END IF; END $$;

DO $$ DECLARE recorded record; BEGIN SELECT revision, checksum, package_version INTO recorded FROM sand_iam_schema_migration WHERE migration_file = '038_auth_rate_limit_retention.pgsql'; IF recorded.revision IS NOT NULL AND ( recorded.revision <> 38 OR recorded.checksum <> '2765bed31eb3a8c5e894c0758e80120f6926f90b4f5a1a9ea39609dd608fe2c3' OR recorded.package_version <> '0.7.0' ) THEN RAISE EXCEPTION 'SandIAM migration 038 ledger identity conflicts with auth-rate-limit retention'; END IF; END $$;

WITH self_checksum(checksum) AS (VALUES ('2765bed31eb3a8c5e894c0758e80120f6926f90b4f5a1a9ea39609dd608fe2c3'))
INSERT INTO sand_iam_schema_migration (migration_file, revision, checksum, package_version, executed_time)
SELECT '038_auth_rate_limit_retention.pgsql', 38, self_checksum.checksum, '0.7.0', CURRENT_TIMESTAMP
FROM self_checksum
ON CONFLICT (migration_file) DO NOTHING;

DO $$ DECLARE recorded_rows integer; BEGIN SELECT count(*) INTO recorded_rows FROM sand_iam_schema_migration WHERE migration_file = '038_auth_rate_limit_retention.pgsql' AND revision = 38 AND checksum = '2765bed31eb3a8c5e894c0758e80120f6926f90b4f5a1a9ea39609dd608fe2c3' AND package_version = '0.7.0'; IF recorded_rows <> 1 OR (SELECT count(*) FROM sand_iam_schema_migration) <> 39 THEN RAISE EXCEPTION 'SandIAM migration 038 did not close the exact 001-038 ledger'; END IF; END $$;

COMMIT;

-- lifecycle source: migrations/039_service_grant_nullable_data_class.pgsql
-- SandIAM 0.7.2: align the persisted service-grant data class with the
-- public contract, where a null value means that the grant does not impose
-- an additional data classification constraint.
BEGIN;

DO $$ DECLARE matched_columns integer; BEGIN SELECT count(*) INTO matched_columns FROM information_schema.columns WHERE table_schema = current_schema() AND table_name = 'sand_iam_service_grant' AND column_name = 'data_class' AND data_type = 'character varying' AND character_maximum_length = 32 AND is_nullable IN ('YES', 'NO') AND column_default = '''internal''::character varying'; IF matched_columns <> 1 THEN RAISE EXCEPTION 'SandIAM service-grant data-class migration requires the exact varchar(32) column with the internal default'; END IF; END $$;

ALTER TABLE sand_iam_service_grant
    ALTER COLUMN data_class DROP NOT NULL;

DO $$ DECLARE matched_columns integer; BEGIN SELECT count(*) INTO matched_columns FROM information_schema.columns WHERE table_schema = current_schema() AND table_name = 'sand_iam_service_grant' AND column_name = 'data_class' AND data_type = 'character varying' AND character_maximum_length = 32 AND is_nullable = 'YES' AND column_default = '''internal''::character varying'; IF matched_columns <> 1 THEN RAISE EXCEPTION 'SandIAM service-grant data-class migration did not preserve the nullable varchar(32) column and internal default'; END IF; END $$;

DO $$ DECLARE recorded record; BEGIN SELECT revision, checksum, package_version INTO recorded FROM sand_iam_schema_migration WHERE migration_file = '039_service_grant_nullable_data_class.pgsql'; IF recorded.revision IS NOT NULL AND ( recorded.revision <> 39 OR recorded.checksum <> 'c6b0c315da73bb6e5e6596c00f09e8c4494db07c790a40f70c5882c0fff3ad53' OR recorded.package_version <> '0.7.2' ) THEN RAISE EXCEPTION 'SandIAM migration 039 ledger identity conflicts with nullable service-grant data class'; END IF; END $$;

WITH self_checksum(checksum) AS (VALUES ('c6b0c315da73bb6e5e6596c00f09e8c4494db07c790a40f70c5882c0fff3ad53'))
INSERT INTO sand_iam_schema_migration (migration_file, revision, checksum, package_version, executed_time)
SELECT '039_service_grant_nullable_data_class.pgsql', 39, self_checksum.checksum, '0.7.2', CURRENT_TIMESTAMP
FROM self_checksum
ON CONFLICT (migration_file) DO NOTHING;

DO $$ DECLARE recorded_rows integer; BEGIN SELECT count(*) INTO recorded_rows FROM sand_iam_schema_migration WHERE migration_file = '039_service_grant_nullable_data_class.pgsql' AND revision = 39 AND checksum = 'c6b0c315da73bb6e5e6596c00f09e8c4494db07c790a40f70c5882c0fff3ad53' AND package_version = '0.7.2'; IF recorded_rows <> 1 OR (SELECT count(*) FROM sand_iam_schema_migration) <> 40 THEN RAISE EXCEPTION 'SandIAM migration 039 did not close the exact 001-039 ledger'; END IF; END $$;

COMMIT;

-- lifecycle source: migrations/040_passkey_auth_challenge_identity.pgsql
-- SandIAM 0.7.2: an anonymous passkey challenge starts without an identity,
-- then binds the verified identity after a successful assertion. Other
-- challenge purposes remain identity-bound for their entire lifetime.
BEGIN;

DO $$ DECLARE matched_constraints integer; BEGIN SELECT count(*) INTO matched_constraints FROM pg_constraint actual JOIN pg_class table_row ON table_row.oid = actual.conrelid JOIN pg_namespace schema_row ON schema_row.oid = table_row.relnamespace WHERE schema_row.nspname = current_schema() AND table_row.relname = 'sand_iam_auth_challenge' AND actual.conname = 'ck_sand_iam_auth_challenge_identity' AND actual.contype = 'c' AND regexp_replace( regexp_replace( regexp_replace( lower(pg_get_constraintdef(actual.oid, true)), E'::[a-z_][a-z0-9_]*(\\s+varying)?', '', 'g' ), E'\\s+', '', 'g' ), '[()]', '', 'g' ) IN ( 'checkpurpose=''webauthn_auth''andidentity_idisnullorpurpose<>''webauthn_auth''andidentity_idisnotnull', 'checkpurpose=''webauthn_auth''oridentity_idisnotnull' ); IF matched_constraints <> 1 THEN RAISE EXCEPTION 'SandIAM passkey challenge identity migration requires the exact old or target identity constraint'; END IF; END $$;

ALTER TABLE sand_iam_auth_challenge
    DROP CONSTRAINT ck_sand_iam_auth_challenge_identity;

ALTER TABLE sand_iam_auth_challenge
    ADD CONSTRAINT ck_sand_iam_auth_challenge_identity
    CHECK (purpose = 'webauthn_auth' OR identity_id IS NOT NULL);

DO $$ DECLARE matched_constraints integer; BEGIN SELECT count(*) INTO matched_constraints FROM pg_constraint actual JOIN pg_class table_row ON table_row.oid = actual.conrelid JOIN pg_namespace schema_row ON schema_row.oid = table_row.relnamespace WHERE schema_row.nspname = current_schema() AND table_row.relname = 'sand_iam_auth_challenge' AND actual.conname = 'ck_sand_iam_auth_challenge_identity' AND actual.contype = 'c' AND regexp_replace( regexp_replace( regexp_replace( lower(pg_get_constraintdef(actual.oid, true)), E'::[a-z_][a-z0-9_]*(\\s+varying)?', '', 'g' ), E'\\s+', '', 'g' ), '[()]', '', 'g' ) = 'checkpurpose=''webauthn_auth''oridentity_idisnotnull'; IF matched_constraints <> 1 THEN RAISE EXCEPTION 'SandIAM passkey challenge identity migration did not install the target constraint'; END IF; END $$;

DO $$ DECLARE recorded record; BEGIN SELECT revision, checksum, package_version INTO recorded FROM sand_iam_schema_migration WHERE migration_file = '040_passkey_auth_challenge_identity.pgsql'; IF recorded.revision IS NOT NULL AND ( recorded.revision <> 40 OR recorded.checksum <> 'b83ec813f6405914338b7573fe6d56fe0d7d749516eda1d439bb72beb0212327' OR recorded.package_version <> '0.7.2' ) THEN RAISE EXCEPTION 'SandIAM migration 040 ledger identity conflicts with passkey challenge identity binding'; END IF; END $$;

WITH self_checksum(checksum) AS (VALUES ('b83ec813f6405914338b7573fe6d56fe0d7d749516eda1d439bb72beb0212327'))
INSERT INTO sand_iam_schema_migration (migration_file, revision, checksum, package_version, executed_time)
SELECT '040_passkey_auth_challenge_identity.pgsql', 40, self_checksum.checksum, '0.7.2', CURRENT_TIMESTAMP
FROM self_checksum
ON CONFLICT (migration_file) DO NOTHING;

DO $$ DECLARE recorded_rows integer; BEGIN SELECT count(*) INTO recorded_rows FROM sand_iam_schema_migration WHERE migration_file = '040_passkey_auth_challenge_identity.pgsql' AND revision = 40 AND checksum = 'b83ec813f6405914338b7573fe6d56fe0d7d749516eda1d439bb72beb0212327' AND package_version = '0.7.2'; IF recorded_rows <> 1 OR (SELECT count(*) FROM sand_iam_schema_migration) <> 41 THEN RAISE EXCEPTION 'SandIAM migration 040 did not close the exact 001-040 ledger'; END IF; END $$;

COMMIT;

-- lifecycle source: migrations/041_authorization_scope_integrity.pgsql
-- SandIAM 0.7.3: close database-level application ownership gaps in direct
-- identity grants and policy publication, and align policy action width with
-- the 96-character application action contract.
BEGIN;

LOCK TABLE
    sand_iam_identity,
    sand_iam_role,
    sand_iam_user_type,
    sand_iam_resource,
    sand_iam_identity_role,
    sand_iam_identity_user_type,
    sand_iam_policy,
    sand_iam_policy_version
IN SHARE ROW EXCLUSIVE MODE;

DO $$ DECLARE conflict_count bigint; BEGIN SELECT count(*) INTO conflict_count FROM sand_iam_identity_role relation JOIN sand_iam_identity identity_row ON identity_row.id = relation.identity_id JOIN sand_iam_role role_row ON role_row.id = relation.role_id WHERE identity_row.application_id IS DISTINCT FROM role_row.application_id; IF conflict_count <> 0 THEN RAISE EXCEPTION 'SandIAM 0.7.3 refuses % cross-application identity-role rows', conflict_count; END IF; SELECT count(*) INTO conflict_count FROM sand_iam_identity_user_type relation JOIN sand_iam_identity identity_row ON identity_row.id = relation.identity_id JOIN sand_iam_user_type type_row ON type_row.id = relation.user_type_id WHERE identity_row.application_id IS DISTINCT FROM type_row.application_id; IF conflict_count <> 0 THEN RAISE EXCEPTION 'SandIAM 0.7.3 refuses % cross-application identity-user-type rows', conflict_count; END IF; SELECT count(*) INTO conflict_count FROM sand_iam_policy policy_row JOIN sand_iam_resource resource_row ON resource_row.id = policy_row.resource_id LEFT JOIN sand_iam_role role_row ON role_row.id = policy_row.role_id LEFT JOIN sand_iam_identity identity_row ON identity_row.id = policy_row.identity_id WHERE resource_row.application_id IS DISTINCT FROM policy_row.application_id OR (policy_row.role_id IS NOT NULL AND role_row.application_id IS DISTINCT FROM policy_row.application_id) OR (policy_row.identity_id IS NOT NULL AND identity_row.application_id IS DISTINCT FROM policy_row.application_id); IF conflict_count <> 0 THEN RAISE EXCEPTION 'SandIAM 0.7.3 refuses % policy rows with cross-application targets', conflict_count; END IF; SELECT count(*) INTO conflict_count FROM sand_iam_policy_version version_row JOIN sand_iam_policy policy_row ON policy_row.id = version_row.policy_id WHERE version_row.application_id IS DISTINCT FROM policy_row.application_id; IF conflict_count <> 0 THEN RAISE EXCEPTION 'SandIAM 0.7.3 refuses % policy versions with a foreign application', conflict_count; END IF; SELECT count(*) INTO conflict_count FROM sand_iam_policy_version version_row JOIN sand_iam_policy_version rollback_row ON rollback_row.id = version_row.rollback_of_version_id WHERE rollback_row.policy_id IS DISTINCT FROM version_row.policy_id OR rollback_row.application_id IS DISTINCT FROM version_row.application_id; IF conflict_count <> 0 THEN RAISE EXCEPTION 'SandIAM 0.7.3 refuses % rollback pointers outside their policy', conflict_count; END IF; SELECT count(*) INTO conflict_count FROM sand_iam_policy policy_row JOIN sand_iam_policy_version version_row ON version_row.id = policy_row.published_version_id WHERE version_row.policy_id IS DISTINCT FROM policy_row.id OR version_row.application_id IS DISTINCT FROM policy_row.application_id; IF conflict_count <> 0 THEN RAISE EXCEPTION 'SandIAM 0.7.3 refuses % published pointers outside their policy', conflict_count; END IF; SELECT count(*) INTO conflict_count FROM sand_iam_policy_version WHERE version_no <= 0 OR jsonb_typeof(snapshot) IS DISTINCT FROM 'object' OR snapshot_hash !~ '^[0-9a-f]{64}$'; IF conflict_count <> 0 THEN RAISE EXCEPTION 'SandIAM 0.7.3 refuses % malformed policy-version rows', conflict_count; END IF; END $$;

ALTER TABLE sand_iam_identity_role ADD COLUMN application_id bigint NULL;
ALTER TABLE sand_iam_identity_user_type ADD COLUMN application_id bigint NULL;

UPDATE sand_iam_identity_role relation
SET application_id = identity_row.application_id
FROM sand_iam_identity identity_row
WHERE identity_row.id = relation.identity_id;

UPDATE sand_iam_identity_user_type relation
SET application_id = identity_row.application_id
FROM sand_iam_identity identity_row
WHERE identity_row.id = relation.identity_id;

ALTER TABLE sand_iam_identity_role ALTER COLUMN application_id SET NOT NULL;
ALTER TABLE sand_iam_identity_user_type ALTER COLUMN application_id SET NOT NULL;
ALTER TABLE sand_iam_policy ALTER COLUMN action TYPE varchar(96);

ALTER TABLE sand_iam_user_type
    ADD CONSTRAINT uk_sand_iam_user_type_id_application UNIQUE (id, application_id);
ALTER TABLE sand_iam_policy
    ADD CONSTRAINT uk_sand_iam_policy_id_application UNIQUE (id, application_id);
ALTER TABLE sand_iam_policy_version
    ADD CONSTRAINT uk_sand_iam_policy_version_owner UNIQUE (id, policy_id, application_id);

ALTER TABLE sand_iam_identity_role
    ADD CONSTRAINT fk_sand_iam_identity_role_identity_application
        FOREIGN KEY (identity_id, application_id)
        REFERENCES sand_iam_identity(id, application_id) ON DELETE RESTRICT,
    ADD CONSTRAINT fk_sand_iam_identity_role_role_application
        FOREIGN KEY (role_id, application_id)
        REFERENCES sand_iam_role(id, application_id) ON DELETE RESTRICT;

ALTER TABLE sand_iam_identity_user_type
    ADD CONSTRAINT fk_sand_iam_identity_user_type_identity_application
        FOREIGN KEY (identity_id, application_id)
        REFERENCES sand_iam_identity(id, application_id) ON DELETE RESTRICT,
    ADD CONSTRAINT fk_sand_iam_identity_user_type_type_application
        FOREIGN KEY (user_type_id, application_id)
        REFERENCES sand_iam_user_type(id, application_id) ON DELETE RESTRICT;

ALTER TABLE sand_iam_policy
    ADD CONSTRAINT fk_sand_iam_policy_resource_application
        FOREIGN KEY (resource_id, application_id)
        REFERENCES sand_iam_resource(id, application_id) ON DELETE RESTRICT,
    ADD CONSTRAINT fk_sand_iam_policy_role_application
        FOREIGN KEY (role_id, application_id)
        REFERENCES sand_iam_role(id, application_id) ON DELETE RESTRICT,
    ADD CONSTRAINT fk_sand_iam_policy_identity_application
        FOREIGN KEY (identity_id, application_id)
        REFERENCES sand_iam_identity(id, application_id) ON DELETE RESTRICT;

ALTER TABLE sand_iam_policy_version
    ADD CONSTRAINT fk_sand_iam_policy_version_policy_application
        FOREIGN KEY (policy_id, application_id)
        REFERENCES sand_iam_policy(id, application_id) ON DELETE CASCADE,
    ADD CONSTRAINT fk_sand_iam_policy_version_rollback_owner
        FOREIGN KEY (rollback_of_version_id, policy_id, application_id)
        REFERENCES sand_iam_policy_version(id, policy_id, application_id) ON DELETE RESTRICT,
    ADD CONSTRAINT ck_sand_iam_policy_version_number CHECK (version_no > 0),
    ADD CONSTRAINT ck_sand_iam_policy_version_snapshot_object CHECK (jsonb_typeof(snapshot) = 'object'),
    ADD CONSTRAINT ck_sand_iam_policy_version_snapshot_hash CHECK (snapshot_hash ~ '^[0-9a-f]{64}$');

ALTER TABLE sand_iam_policy
    ADD CONSTRAINT fk_sand_iam_policy_published_version_owner
        FOREIGN KEY (published_version_id, id, application_id)
        REFERENCES sand_iam_policy_version(id, policy_id, application_id) ON DELETE RESTRICT;

ALTER TABLE sand_iam_identity_role
    DROP CONSTRAINT sand_iam_identity_role_identity_id_fkey,
    DROP CONSTRAINT sand_iam_identity_role_role_id_fkey;
ALTER TABLE sand_iam_identity_user_type
    DROP CONSTRAINT sand_iam_identity_user_type_identity_id_fkey,
    DROP CONSTRAINT sand_iam_identity_user_type_user_type_id_fkey;
ALTER TABLE sand_iam_policy
    DROP CONSTRAINT sand_iam_policy_resource_id_fkey,
    DROP CONSTRAINT sand_iam_policy_role_id_fkey,
    DROP CONSTRAINT sand_iam_policy_identity_id_fkey,
    DROP CONSTRAINT fk_sand_iam_policy_published_version;
ALTER TABLE sand_iam_policy_version
    DROP CONSTRAINT sand_iam_policy_version_policy_id_fkey,
    DROP CONSTRAINT sand_iam_policy_version_application_id_fkey,
    DROP CONSTRAINT sand_iam_policy_version_rollback_of_version_id_fkey;

CREATE INDEX idx_sand_iam_identity_role_application_role
    ON sand_iam_identity_role (application_id, role_id, status);
CREATE INDEX idx_sand_iam_identity_user_type_application_type
    ON sand_iam_identity_user_type (application_id, user_type_id, status);

DO $$ DECLARE recorded record; BEGIN SELECT revision, checksum, package_version INTO recorded FROM sand_iam_schema_migration WHERE migration_file = '041_authorization_scope_integrity.pgsql'; IF recorded.revision IS NOT NULL AND ( recorded.revision <> 41 OR recorded.checksum <> 'a06c3c7879e7760fb54dae955c36e6a6aacfa9a6ad36c6e35b5981d00eb43a50' OR recorded.package_version <> '0.7.3' ) THEN RAISE EXCEPTION 'SandIAM migration 041 ledger identity conflicts with authorization scope integrity'; END IF; END $$;

WITH self_checksum(checksum) AS (VALUES ('a06c3c7879e7760fb54dae955c36e6a6aacfa9a6ad36c6e35b5981d00eb43a50'))
INSERT INTO sand_iam_schema_migration (migration_file, revision, checksum, package_version, executed_time)
SELECT '041_authorization_scope_integrity.pgsql', 41, self_checksum.checksum, '0.7.3', CURRENT_TIMESTAMP
FROM self_checksum
ON CONFLICT (migration_file) DO NOTHING;

DO $$ DECLARE recorded_rows integer; BEGIN SELECT count(*) INTO recorded_rows FROM sand_iam_schema_migration WHERE migration_file = '041_authorization_scope_integrity.pgsql' AND revision = 41 AND checksum = 'a06c3c7879e7760fb54dae955c36e6a6aacfa9a6ad36c6e35b5981d00eb43a50' AND package_version = '0.7.3'; IF recorded_rows <> 1 OR (SELECT count(*) FROM sand_iam_schema_migration) <> 42 THEN RAISE EXCEPTION 'SandIAM migration 041 did not close the exact 001-041 ledger'; END IF; END $$;

COMMIT;

-- lifecycle source: migrations/042_permission_menu_hierarchy.pgsql
-- SandIAM 0.7.3: repair the 100 legacy permission leaves created before the
-- task-path menu consolidation. Keep every permission slug and row id stable,
-- so existing role grants remain attached to the same logical permission.
BEGIN;

LOCK TABLE sand_system_menu, sand_system_role_menu IN SHARE ROW EXCLUSIVE MODE;

DO $$ DECLARE desired record; target_permission_id bigint; old_permission_id bigint; old_permission_rows integer; old_permission_status smallint; new_permission_id bigint; new_permission_rows integer; new_permission_status smallint; active_slug_rows integer; target_parent_id bigint; parent_rows integer; conflicting_code_rows integer; matched_permissions integer := 0; role_set_before text; role_set_after text; BEGIN WITH resource_def(resource_code, resource_name, parent_code, actions) AS ( VALUES ('organization', '客户主体', 'SandIAMConnection', ARRAY['index','read','save','update','disable']::text[]), ('application', '接入应用', 'SandIAMConnection', ARRAY['index','read','save','update','disable']::text[]), ('environment', '应用环境', 'SandIAMConnection', ARRAY['index','read','save','update','disable']::text[]), ('client', '服务调用身份', 'SandIAMConnection', ARRAY['index','read','save','update','disable']::text[]), ('grant', '服务授权', 'SandIAMConnection', ARRAY['index','read','save','update','revoke']::text[]), ('credential', '调用凭证', 'SandIAMConnection', ARRAY['index','read','issue','rotate','revoke']::text[]), ('service', '平台服务', 'SandIAMConnection', ARRAY['index','read','save','update','disable']::text[]), ('service_action', '服务动作', 'SandIAMConnection', ARRAY['index','read','save','update','disable']::text[]), ('identity_provider', '身份源', 'SandIAMPeopleAccess', ARRAY['index','read','save','update','disable']::text[]), ('identity', '应用用户', 'SandIAMPeopleAccess', ARRAY['index','read','save','update','disable']::text[]), ('identity_binding', '身份绑定', 'SandIAMPeopleAccess', ARRAY['index','read','save','update','disable']::text[]), ('user_type', '用户类型', 'SandIAMPeopleAccess', ARRAY['index','read','save','update','disable']::text[]), ('role', '角色', 'SandIAMPeopleAccess', ARRAY['index','read','save','update','disable']::text[]), ('identity_user_type', '身份用户类型', 'SandIAMPeopleAccess', ARRAY['index','grant','revoke']::text[]), ('identity_role', '身份角色', 'SandIAMPeopleAccess', ARRAY['index','grant','revoke']::text[]), ('resource', '业务资源', 'SandIAMPeopleAccess', ARRAY['index','read','save','update','disable']::text[]), ('policy', '授权策略', 'SandIAMPeopleAccess', ARRAY['index','read','save','update','disable','publish','revoke']::text[]), ('admin_organization_grant', '客户主体管理委派', 'SandIAMAdminScope', ARRAY['index','read','save','update','disable']::text[]), ('audit', '访问审计', 'SandIAMAuditTroubleshooting', ARRAY['index','read']::text[]), ('auth_policy', '认证策略', 'SandIAMAuthSession', ARRAY['index','read','save','update','disable']::text[]) ), generated_permission AS ( SELECT 'sand_iam:' || resource_def.resource_code || ':' || action.code AS slug, resource_def.parent_code, CASE action.code WHEN 'index' THEN resource_def.resource_name || '列表' WHEN 'read' THEN '查看' || resource_def.resource_name WHEN 'save' THEN '新增' || resource_def.resource_name WHEN 'update' THEN '编辑' || resource_def.resource_name WHEN 'disable' THEN '停用' || resource_def.resource_name WHEN 'revoke' THEN '撤销' || resource_def.resource_name WHEN 'issue' THEN '签发' || resource_def.resource_name WHEN 'rotate' THEN '轮换' || resource_def.resource_name WHEN 'grant' THEN '授予' || resource_def.resource_name WHEN 'publish' THEN '发布' || resource_def.resource_name ELSE NULL END AS permission_name FROM resource_def CROSS JOIN LATERAL unnest(resource_def.actions) AS action(code) ), special_permission(slug, parent_code, permission_name) AS ( VALUES ('sand_iam:federation:create', 'SandIAMFederationConfig', '创建联合身份源'), ('sand_iam:federation:configure', 'SandIAMFederationConfig', '配置联合身份源'), ('sand_iam:federation:mount', 'SandIAMFederationConfig', '挂载联合身份源'), ('sand_iam:federation:sync', 'SandIAMFederationConfig', '同步企业目录'), ('sand_iam:scim:token_issue', 'SandIAMScimTokens', '签发 SCIM 令牌') ), permission_def AS ( SELECT slug, parent_code, permission_name FROM generated_permission UNION ALL SELECT slug, parent_code, permission_name FROM special_permission ) SELECT md5(COALESCE(string_agg(logical_grant.role_id::text || ':' || logical_grant.slug, ',' ORDER BY logical_grant.role_id, logical_grant.slug), '')) INTO role_set_before FROM ( SELECT DISTINCT role_menu.role_id, permission.slug FROM permission_def JOIN sand_system_menu permission ON permission.slug = permission_def.slug JOIN sand_system_role_menu role_menu ON role_menu.menu_id = permission.id ) logical_grant; FOR desired IN WITH resource_def(resource_code, resource_name, parent_code, actions) AS ( VALUES ('organization', '客户主体', 'SandIAMConnection', ARRAY['index','read','save','update','disable']::text[]), ('application', '接入应用', 'SandIAMConnection', ARRAY['index','read','save','update','disable']::text[]), ('environment', '应用环境', 'SandIAMConnection', ARRAY['index','read','save','update','disable']::text[]), ('client', '服务调用身份', 'SandIAMConnection', ARRAY['index','read','save','update','disable']::text[]), ('grant', '服务授权', 'SandIAMConnection', ARRAY['index','read','save','update','revoke']::text[]), ('credential', '调用凭证', 'SandIAMConnection', ARRAY['index','read','issue','rotate','revoke']::text[]), ('service', '平台服务', 'SandIAMConnection', ARRAY['index','read','save','update','disable']::text[]), ('service_action', '服务动作', 'SandIAMConnection', ARRAY['index','read','save','update','disable']::text[]), ('identity_provider', '身份源', 'SandIAMPeopleAccess', ARRAY['index','read','save','update','disable']::text[]), ('identity', '应用用户', 'SandIAMPeopleAccess', ARRAY['index','read','save','update','disable']::text[]), ('identity_binding', '身份绑定', 'SandIAMPeopleAccess', ARRAY['index','read','save','update','disable']::text[]), ('user_type', '用户类型', 'SandIAMPeopleAccess', ARRAY['index','read','save','update','disable']::text[]), ('role', '角色', 'SandIAMPeopleAccess', ARRAY['index','read','save','update','disable']::text[]), ('identity_user_type', '身份用户类型', 'SandIAMPeopleAccess', ARRAY['index','grant','revoke']::text[]), ('identity_role', '身份角色', 'SandIAMPeopleAccess', ARRAY['index','grant','revoke']::text[]), ('resource', '业务资源', 'SandIAMPeopleAccess', ARRAY['index','read','save','update','disable']::text[]), ('policy', '授权策略', 'SandIAMPeopleAccess', ARRAY['index','read','save','update','disable','publish','revoke']::text[]), ('admin_organization_grant', '客户主体管理委派', 'SandIAMAdminScope', ARRAY['index','read','save','update','disable']::text[]), ('audit', '访问审计', 'SandIAMAuditTroubleshooting', ARRAY['index','read']::text[]), ('auth_policy', '认证策略', 'SandIAMAuthSession', ARRAY['index','read','save','update','disable']::text[]) ), generated_permission AS ( SELECT 'sand_iam:' || resource_def.resource_code || ':' || action.code AS slug, resource_def.parent_code, CASE action.code WHEN 'index' THEN resource_def.resource_name || '列表' WHEN 'read' THEN '查看' || resource_def.resource_name WHEN 'save' THEN '新增' || resource_def.resource_name WHEN 'update' THEN '编辑' || resource_def.resource_name WHEN 'disable' THEN '停用' || resource_def.resource_name WHEN 'revoke' THEN '撤销' || resource_def.resource_name WHEN 'issue' THEN '签发' || resource_def.resource_name WHEN 'rotate' THEN '轮换' || resource_def.resource_name WHEN 'grant' THEN '授予' || resource_def.resource_name WHEN 'publish' THEN '发布' || resource_def.resource_name ELSE NULL END AS permission_name FROM resource_def CROSS JOIN LATERAL unnest(resource_def.actions) AS action(code) ), special_permission(slug, parent_code, permission_name) AS ( VALUES ('sand_iam:federation:create', 'SandIAMFederationConfig', '创建联合身份源'), ('sand_iam:federation:configure', 'SandIAMFederationConfig', '配置联合身份源'), ('sand_iam:federation:mount', 'SandIAMFederationConfig', '挂载联合身份源'), ('sand_iam:federation:sync', 'SandIAMFederationConfig', '同步企业目录'), ('sand_iam:scim:token_issue', 'SandIAMScimTokens', '签发 SCIM 令牌') ) SELECT slug, parent_code, permission_name FROM generated_permission UNION ALL SELECT slug, parent_code, permission_name FROM special_permission ORDER BY slug LOOP IF desired.permission_name IS NULL OR desired.permission_name = '' THEN RAISE EXCEPTION 'SandIAM permission hierarchy has no explicit name for %', desired.slug; END IF; SELECT count(*), min(id), min(status) INTO old_permission_rows, old_permission_id, old_permission_status FROM sand_system_menu WHERE slug = desired.slug AND type = 3 AND code = '' AND delete_time IS NULL; SELECT count(*), min(id), min(status) INTO new_permission_rows, new_permission_id, new_permission_status FROM sand_system_menu WHERE slug = desired.slug AND type = 3 AND code = desired.slug AND delete_time IS NULL; SELECT count(*) INTO active_slug_rows FROM sand_system_menu WHERE slug = desired.slug AND delete_time IS NULL; IF active_slug_rows <> old_permission_rows + new_permission_rows THEN RAISE EXCEPTION 'SandIAM permission hierarchy found an unrecognized active row shape for %; active %, legacy %, repaired %', desired.slug, active_slug_rows, old_permission_rows, new_permission_rows; END IF; IF old_permission_rows = 1 AND new_permission_rows = 0 THEN target_permission_id := old_permission_id; ELSIF old_permission_rows = 1 AND new_permission_rows = 1 THEN IF old_permission_status IS DISTINCT FROM new_permission_status THEN RAISE EXCEPTION 'SandIAM permission hierarchy refuses conflicting active status for %', desired.slug; END IF; target_permission_id := old_permission_id; INSERT INTO sand_system_role_menu (role_id, menu_id) SELECT duplicate_role.role_id, target_permission_id FROM sand_system_role_menu duplicate_role WHERE duplicate_role.menu_id = new_permission_id AND NOT EXISTS ( SELECT 1 FROM sand_system_role_menu retained_role WHERE retained_role.role_id = duplicate_role.role_id AND retained_role.menu_id = target_permission_id ); DELETE FROM sand_system_role_menu WHERE menu_id = new_permission_id; DELETE FROM sand_system_menu WHERE id = new_permission_id; ELSIF old_permission_rows = 0 AND new_permission_rows = 1 THEN target_permission_id := new_permission_id; ELSE RAISE EXCEPTION 'SandIAM permission hierarchy requires one legacy row, one repaired row, or one of each for %; found legacy %, repaired %', desired.slug, old_permission_rows, new_permission_rows; END IF; SELECT count(*), min(parent.id) INTO parent_rows, target_parent_id FROM sand_system_menu parent JOIN sand_system_menu root ON root.id = parent.parent_id AND root.code = 'SandIAM' AND root.delete_time IS NULL WHERE parent.code = desired.parent_code AND parent.type IN (1, 2) AND parent.status = 1 AND parent.delete_time IS NULL; IF parent_rows <> 1 THEN RAISE EXCEPTION 'SandIAM permission hierarchy requires exactly one active parent %, found %', desired.parent_code, parent_rows; END IF; SELECT count(*) INTO conflicting_code_rows FROM sand_system_menu WHERE code = desired.slug AND id <> target_permission_id AND delete_time IS NULL; IF conflicting_code_rows <> 0 THEN RAISE EXCEPTION 'SandIAM permission hierarchy found another active code row for %', desired.slug; END IF; UPDATE sand_system_menu SET parent_id = target_parent_id, name = desired.permission_name, code = desired.slug, type = 3, path = '', component = '', icon = '', is_hidden = 1, update_time = CURRENT_TIMESTAMP WHERE id = target_permission_id AND ( sand_system_menu.parent_id IS DISTINCT FROM target_parent_id OR sand_system_menu.name IS DISTINCT FROM desired.permission_name OR sand_system_menu.code IS DISTINCT FROM desired.slug OR sand_system_menu.type IS DISTINCT FROM 3 OR sand_system_menu.path IS DISTINCT FROM '' OR sand_system_menu.component IS DISTINCT FROM '' OR sand_system_menu.icon IS DISTINCT FROM '' OR sand_system_menu.is_hidden IS DISTINCT FROM 1 ); matched_permissions := matched_permissions + 1; END LOOP; IF matched_permissions <> 100 THEN RAISE EXCEPTION 'SandIAM permission hierarchy expected 100 legacy permissions, found %', matched_permissions; END IF; WITH resource_def(resource_code, actions) AS ( VALUES ('organization', ARRAY['index','read','save','update','disable']::text[]), ('application', ARRAY['index','read','save','update','disable']::text[]), ('environment', ARRAY['index','read','save','update','disable']::text[]), ('client', ARRAY['index','read','save','update','disable']::text[]), ('grant', ARRAY['index','read','save','update','revoke']::text[]), ('credential', ARRAY['index','read','issue','rotate','revoke']::text[]), ('service', ARRAY['index','read','save','update','disable']::text[]), ('service_action', ARRAY['index','read','save','update','disable']::text[]), ('identity_provider', ARRAY['index','read','save','update','disable']::text[]), ('identity', ARRAY['index','read','save','update','disable']::text[]), ('identity_binding', ARRAY['index','read','save','update','disable']::text[]), ('user_type', ARRAY['index','read','save','update','disable']::text[]), ('role', ARRAY['index','read','save','update','disable']::text[]), ('identity_user_type', ARRAY['index','grant','revoke']::text[]), ('identity_role', ARRAY['index','grant','revoke']::text[]), ('resource', ARRAY['index','read','save','update','disable']::text[]), ('policy', ARRAY['index','read','save','update','disable','publish','revoke']::text[]), ('admin_organization_grant', ARRAY['index','read','save','update','disable']::text[]), ('audit', ARRAY['index','read']::text[]), ('auth_policy', ARRAY['index','read','save','update','disable']::text[]) ), permission_def(slug) AS ( SELECT 'sand_iam:' || resource_def.resource_code || ':' || action.code FROM resource_def CROSS JOIN LATERAL unnest(resource_def.actions) AS action(code) UNION ALL VALUES ('sand_iam:federation:create'), ('sand_iam:federation:configure'), ('sand_iam:federation:mount'), ('sand_iam:federation:sync'), ('sand_iam:scim:token_issue') ) SELECT md5(COALESCE(string_agg(logical_grant.role_id::text || ':' || logical_grant.slug, ',' ORDER BY logical_grant.role_id, logical_grant.slug), '')) INTO role_set_after FROM ( SELECT DISTINCT role_menu.role_id, permission.slug FROM permission_def JOIN sand_system_menu permission ON permission.slug = permission_def.slug JOIN sand_system_role_menu role_menu ON role_menu.menu_id = permission.id ) logical_grant; IF role_set_after IS DISTINCT FROM role_set_before THEN RAISE EXCEPTION 'SandIAM permission hierarchy changed the logical role-permission set'; END IF; END $$;

DO $$ DECLARE recorded record; BEGIN SELECT revision, checksum, package_version INTO recorded FROM sand_iam_schema_migration WHERE migration_file = '042_permission_menu_hierarchy.pgsql'; IF recorded.revision IS NOT NULL AND ( recorded.revision <> 42 OR recorded.checksum <> '62d79e86170788d40d39b528b604269e439e0d3588c011154c8e12080564fbeb' OR recorded.package_version <> '0.7.3' ) THEN RAISE EXCEPTION 'SandIAM migration 042 ledger identity conflicts with permission menu hierarchy repair'; END IF; END $$;

WITH self_checksum(checksum) AS (VALUES ('62d79e86170788d40d39b528b604269e439e0d3588c011154c8e12080564fbeb'))
INSERT INTO sand_iam_schema_migration (migration_file, revision, checksum, package_version, executed_time)
SELECT '042_permission_menu_hierarchy.pgsql', 42, self_checksum.checksum, '0.7.3', CURRENT_TIMESTAMP
FROM self_checksum
ON CONFLICT (migration_file) DO NOTHING;

DO $$ DECLARE recorded_rows integer; BEGIN SELECT count(*) INTO recorded_rows FROM sand_iam_schema_migration WHERE migration_file = '042_permission_menu_hierarchy.pgsql' AND revision = 42 AND checksum = '62d79e86170788d40d39b528b604269e439e0d3588c011154c8e12080564fbeb' AND package_version = '0.7.3'; IF recorded_rows <> 1 OR (SELECT count(*) FROM sand_iam_schema_migration) <> 43 THEN RAISE EXCEPTION 'SandIAM migration 042 did not close the exact 001-042 ledger'; END IF; END $$;

COMMIT;
