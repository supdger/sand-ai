<?php

return [
    'admin' => [],
    'api' => [],
];
