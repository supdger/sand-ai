-- SandIAM uninstall lifecycle for the release package.
-- SandIAM PostgreSQL uninstall.
-- Drops only SandIAM-owned objects, from dependent to principal tables.
BEGIN;
DROP TABLE IF EXISTS sand_iam_schema_migration;
ALTER TABLE IF EXISTS sand_iam_oauth_client DROP CONSTRAINT IF EXISTS fk_sand_iam_oauth_client_dcr_token;
ALTER TABLE IF EXISTS sand_iam_auth_session DROP CONSTRAINT IF EXISTS fk_sand_iam_auth_session_federation_binding;
ALTER TABLE IF EXISTS sand_iam_auth_session DROP CONSTRAINT IF EXISTS fk_sand_iam_auth_session_identity_binding;
-- policy is the principal table, but its selected published snapshot points
-- back to sand_iam_policy_version. Remove that reverse dependency before the
-- snapshot table so uninstall remains explicit and never needs CASCADE.
ALTER TABLE IF EXISTS sand_iam_policy DROP CONSTRAINT IF EXISTS fk_sand_iam_policy_published_version;
ALTER TABLE IF EXISTS sand_iam_policy DROP CONSTRAINT IF EXISTS fk_sand_iam_policy_published_version_owner;

DROP TABLE IF EXISTS sand_iam_initialization_draft_revision;
DROP TABLE IF EXISTS sand_iam_initialization_draft;
DROP TABLE IF EXISTS sand_iam_initialization_binding;
DROP TABLE IF EXISTS sand_iam_initialization_run;

DROP TABLE IF EXISTS sand_iam_security_alert;
DROP TABLE IF EXISTS sand_iam_security_operation;
DROP TABLE IF EXISTS sand_iam_audit_archive;
DROP TABLE IF EXISTS sand_iam_audit_retention_policy;
DROP TABLE IF EXISTS sand_iam_application_network_policy;

DROP TABLE IF EXISTS sand_iam_radius_accounting_event;
DROP TABLE IF EXISTS sand_iam_radius_accounting_session;
DROP TABLE IF EXISTS sand_iam_radius_replay;
DROP TABLE IF EXISTS sand_iam_radius_nas;

DROP TABLE IF EXISTS sand_iam_cas_ticket;
DROP TABLE IF EXISTS sand_iam_cas_login_request;
DROP TABLE IF EXISTS sand_iam_cas_service;

DROP TABLE IF EXISTS sand_iam_oidc_logout_delivery;
DROP TABLE IF EXISTS sand_iam_oauth_registration_token;

DROP TABLE IF EXISTS sand_iam_sync_outbox;
DROP TABLE IF EXISTS sand_iam_sync_resource;
DROP TABLE IF EXISTS sand_iam_sync_run;
DROP TABLE IF EXISTS sand_iam_sync_connector;

DROP TABLE IF EXISTS sand_iam_identity_import_row;
DROP TABLE IF EXISTS sand_iam_identity_import_job;
DROP TABLE IF EXISTS sand_iam_identity_invitation;
DROP TABLE IF EXISTS sand_iam_identity_group_member;
DROP TABLE IF EXISTS sand_iam_identity_group_role;
DROP TABLE IF EXISTS sand_iam_identity_group;

DROP TABLE IF EXISTS sand_iam_message_provider_application;
DROP TABLE IF EXISTS sand_iam_application_experience;
DROP TABLE IF EXISTS sand_iam_message_provider;

DROP TABLE IF EXISTS sand_iam_webhook_delivery;
DROP TABLE IF EXISTS sand_iam_webhook_endpoint;
DROP TABLE IF EXISTS sand_iam_admin_application_grant;
DROP TABLE IF EXISTS sand_iam_api_route_binding;
DROP TABLE IF EXISTS sand_iam_api_resource;
DROP TABLE IF EXISTS sand_iam_application_business_action;
DROP TABLE IF EXISTS sand_iam_federation_handoff;

DROP TABLE IF EXISTS sand_iam_provisioning_event;
DROP TABLE IF EXISTS sand_iam_scim_resource;
DROP TABLE IF EXISTS sand_iam_scim_group_member;
DROP TABLE IF EXISTS sand_iam_scim_group;
DROP TABLE IF EXISTS sand_iam_scim_token;
DROP TABLE IF EXISTS sand_iam_directory_sync_run;
DROP TABLE IF EXISTS sand_iam_federation_transaction;
DROP TABLE IF EXISTS sand_iam_identity_binding;
DROP TABLE IF EXISTS sand_iam_identity_provider_application;
-- Includes enveloped OIDC private signing material introduced by migration 031.
DROP TABLE IF EXISTS sand_iam_oidc_signing_key;
DROP TABLE IF EXISTS sand_iam_oauth_token;
DROP TABLE IF EXISTS sand_iam_authorization_code;
DROP TABLE IF EXISTS sand_iam_oauth_grant;
DROP TABLE IF EXISTS sand_iam_oauth_authorization_request;
DROP TABLE IF EXISTS sand_iam_oauth_consent;
DROP TABLE IF EXISTS sand_iam_oauth_client;

DROP TABLE IF EXISTS sand_iam_mfa_recovery_code;
DROP TABLE IF EXISTS sand_iam_auth_challenge;
DROP TABLE IF EXISTS sand_iam_mfa_challenge;
DROP TABLE IF EXISTS sand_iam_webauthn_credential;
DROP TABLE IF EXISTS sand_iam_mfa_factor;

DROP TABLE IF EXISTS sand_iam_auth_refresh_token;
DROP TABLE IF EXISTS sand_iam_auth_session;
DROP TABLE IF EXISTS sand_iam_auth_verification;
DROP TABLE IF EXISTS sand_iam_auth_rate_limit;
DROP TABLE IF EXISTS sand_iam_auth_policy;
DROP TABLE IF EXISTS sand_iam_identity_auth;

DROP TABLE IF EXISTS sand_iam_admin_organization_grant;

DROP TABLE IF EXISTS sand_iam_audit_log;
DROP TABLE IF EXISTS sand_iam_service_invocation_operation;
DROP TABLE IF EXISTS sand_iam_service_quota_bucket;
DROP TABLE IF EXISTS sand_iam_policy_version;
DROP TABLE IF EXISTS sand_iam_policy;
DROP TABLE IF EXISTS sand_iam_resource;
DROP TABLE IF EXISTS sand_iam_identity_role;
DROP TABLE IF EXISTS sand_iam_role;
DROP TABLE IF EXISTS sand_iam_identity_user_type;
DROP TABLE IF EXISTS sand_iam_user_type;
DROP TABLE IF EXISTS sand_iam_identity_binding;
DROP TABLE IF EXISTS sand_iam_identity_provider;
DROP TABLE IF EXISTS sand_iam_identity;
DROP TABLE IF EXISTS sand_iam_service_grant;
DROP TABLE IF EXISTS sand_iam_service_action;
DROP TABLE IF EXISTS sand_iam_service;
DROP TABLE IF EXISTS sand_iam_credential;
DROP TABLE IF EXISTS sand_iam_workload_client;
DROP TABLE IF EXISTS sand_iam_environment;
DROP TABLE IF EXISTS sand_iam_application;
DROP TABLE IF EXISTS sand_iam_organization;

DELETE FROM sand_system_role_menu
WHERE menu_id IN (
    SELECT id
    FROM sand_system_menu
    WHERE code = 'SandIAM'
       OR code LIKE 'SandIAM%'
       OR code LIKE 'sand\_iam:%' ESCAPE '\'
);

DELETE FROM sand_system_menu
WHERE code = 'SandIAM'
   OR code LIKE 'SandIAM%'
   OR code LIKE 'sand\_iam:%' ESCAPE '\';

COMMIT;
